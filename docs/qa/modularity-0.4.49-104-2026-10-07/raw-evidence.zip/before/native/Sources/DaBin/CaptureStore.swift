import Foundation
import Combine
import UniformTypeIdentifiers

/// Undo owns one exact reply, never a snapshot of the whole conversation.
/// Binding the receipt to its capture prevents restoring it into another card.
struct CaptureCommentRemovalReceipt: Equatable, Sendable {
    let captureID: UUID
    let entry: CaptureCommentEntry
}

@MainActor final class CaptureStore: ObservableObject {
    @Published private(set) var captures: [Capture] = []
    @Published private(set) var trashedCaptures: [Capture] = []
    @Published var error: String?
    let root: URL
    private let repository: CaptureRepository
    private let archive: DailyArchive
    private let projectArchive: ProjectFileArchive
    private var lastArchiveWarning: String?
    private var archiveFailures: [UUID: String] = [:]
    var failureInjector: ((ImportCheckpoint) throws -> Void)?
    var removalFailureInjector: ((RemovalCheckpoint) throws -> Void)?
    var backupFailureInjector: ((ArchiveRestoreCheckpoint) throws -> Void)?
    private var pendingRemovalIDs: Set<UUID> = []
    private var archiveRepairTask: Task<Void, Never>?
    private var archiveRepairGeneration: UInt = 0
    private var archiveRepairIDs: [UUID] = []
    private var pendingArchiveRepairIDs: Set<UUID> = []
    var pendingArchiveRepairCount: Int { pendingArchiveRepairIDs.count }

    init(root requestedRoot: URL? = nil, repairArchiveOnOpen: Bool = true) throws {
        let manager = FileManager.default
        let base = try requestedRoot ?? manager.url(for: .applicationSupportDirectory, in: .userDomainMask,
                                                    appropriateFor: nil, create: true).appendingPathComponent("DaBin", isDirectory: true)
        try OriginalFileStorage.ensurePrivateDirectory(base)
        self.root = base.standardizedFileURL.resolvingSymlinksInPath()
        for directory in ["Originals", "Staging", "Imports", "Deletions"] {
            let url = self.root.appendingPathComponent(directory, isDirectory: true)
            try OriginalFileStorage.ensurePrivateDirectory(url, withIntermediateDirectories: false)
        }
        self.repository = try CaptureRepository(root: self.root)
        self.archive = DailyArchive(root: self.root)
        self.projectArchive = ProjectFileArchive(root: self.root)
        try refresh()
        try recoverPendingRemovals()
        try recoverInterruptedImports()
        try refresh()
        if repairArchiveOnOpen {
            synchronizeArchive(captures + trashedCaptures)
        } else {
            let records = captures + trashedCaptures
            archiveRepairIDs = records.reversed().map(\.id)
            pendingArchiveRepairIDs = Set(archiveRepairIDs)
        }
    }

    /// Metadata and original files are ready before this maintenance begins.
    /// Each short slice uses the current record so UI edits, trash, and deletion
    /// cannot be overwritten by a stale launch snapshot.
    func startArchiveRepair() {
        guard archiveRepairTask == nil, !pendingArchiveRepairIDs.isEmpty else { return }
        archiveRepairGeneration &+= 1
        let generation = archiveRepairGeneration
        archiveRepairTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                // Let the first window present, then leave time for interaction
                // between individual folders instead of blocking on the archive.
                do { try await Task.sleep(for: .milliseconds(20)) }
                catch { break }
                guard !Task.isCancelled, let self, self.archiveRepairGeneration == generation else { break }
                guard self.repairNextArchiveFolder() else { break }
            }
            guard let self, self.archiveRepairGeneration == generation else { return }
            self.archiveRepairTask = nil
        }
    }

    func cancelArchiveRepair() {
        archiveRepairGeneration &+= 1
        archiveRepairTask?.cancel()
        archiveRepairTask = nil
    }

    /// Tests and explicit maintenance can wait without blocking the main actor.
    func waitForArchiveRepair() async { await archiveRepairTask?.value }

    private func repairNextArchiveFolder() -> Bool {
        while let id = archiveRepairIDs.popLast() {
            guard pendingArchiveRepairIDs.remove(id) != nil else { continue }
            guard !pendingRemovalIDs.contains(id),
                  let capture = captures.first(where: { $0.id == id }) ?? trashedCaptures.first(where: { $0.id == id }) else { continue }
            synchronizeArchive([capture])
            return true
        }
        return false
    }

    func capture(text: String, at: Date = Date(), timeZone: TimeZone = .current,
                 source: CaptureSource = .unknown,
                 receipt: CaptureReceiptContext = .manual, projectName: String? = nil,
                 parentTask: Capture? = nil,
                 commitGuard: () -> Bool = { true }) throws -> [Capture] {
        try requireAttachmentParent(parentTask)
        let effectiveProject: String?
        if let parentTask { effectiveProject = normalizedProjectName(parentTask.projectName) }
        else { effectiveProject = normalizedProjectName(projectName) }
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw CaptureStoreError.emptyInput }
        let nonemptyLines = text.components(separatedBy: .newlines).filter {
            !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        let originals = nonemptyLines.count > 1 && nonemptyLines.allSatisfy({ CaptureClassifier.textKind($0) == .link })
            ? nonemptyLines : [text]
        let newCaptures = originals.map { original -> Capture in
            let value = original.trimmingCharacters(in: .whitespacesAndNewlines)
            let kind = CaptureClassifier.textKind(original)
            let title = kind == .link ? (URL(string: value)?.host ?? value) : String(value.prefix(100))
            let capture = Capture(capturedAt: at, timeZone: timeZone, kind: kind,
                                  originalURL: kind == .link ? value : nil, originalText: original, title: title,
                                  sourceFilePath: source.filePath, sourceURL: source.url, receipt: receipt,
                                  parentTaskID: parentTask?.id)
            capture.projectName = effectiveProject
            // Plain text is already its own preview. Commit that state with
            // the original instead of making the preview service save twice.
            if kind == .text { capture.previewState = "ready" }
            return capture
        }
        // URL-only multiline pastes commit as one transaction. Mixed prose remains one exact text original.
        guard commitGuard() else { throw CaptureStoreError.captureCancelled }
        try requireAttachmentParent(parentTask)
        try failureInjector?(.beforeMetadataSave)
        try repository.save(newCaptures)
        insertCommittedCaptures(newCaptures)
        synchronizeArchive(newCaptures)
        return newCaptures
    }

    func importFile(_ source: URL, at: Date = Date(), timeZone: TimeZone = .current,
                    originalName: String? = nil, source provenance: CaptureSource? = nil,
                    receipt: CaptureReceiptContext = .manual, projectName: String? = nil,
                    parentTask: Capture? = nil,
                    commitGuard: @escaping () -> Bool = { true }) async throws -> Capture {
        let access = source.startAccessingSecurityScopedResource()
        defer { if access { source.stopAccessingSecurityScopedResource() } }
        // Scope failure alone does not mean unreadable; resources already in the container need no grant.
        try OriginalFileStorage.validateRegularFile(source)
        let filename = originalName ?? source.lastPathComponent
        let type = (try? source.resourceValues(forKeys: [.contentTypeKey]).contentType) ?? UTType(filenameExtension: source.pathExtension)
        let origin = provenance ?? CaptureSource(filePath: source.standardizedFileURL.path)
        return try await importOriginal(filename: filename, contentType: type, at: at, timeZone: timeZone,
                                        source: origin, receipt: receipt, projectName: projectName,
                                        parentTask: parentTask, commitGuard: commitGuard) { destination in
            try FileManager.default.copyItem(at: source, to: destination)
        }
    }

    /// Authored notes remain one exact text original even when every line is a URL.
    func createNote(text: String, at: Date = Date(), projectName: String? = nil) throws -> Capture {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw CaptureStoreError.emptyInput }
        let note = Capture(capturedAt: at, kind: .text, originalText: text, title: String(trimmed.prefix(100)))
        note.projectName = normalizedProjectName(projectName)
        note.previewState = "ready"
        try failureInjector?(.beforeMetadataSave)
        try persist(note)
        captures.append(note)
        captures.sort { $0.capturedAt == $1.capturedAt ? $0.id.uuidString < $1.id.uuidString : $0.capturedAt > $1.capturedAt }
        return note
    }

    func createTask(text: String, reminderAt: Date? = nil, reminderTimeZoneID: String? = nil,
                    at: Date = Date(), timeZone: TimeZone = .current, planning: TaskPlanning? = nil,
                    projectName: String? = nil) throws -> Capture {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw CaptureStoreError.emptyInput }
        if let reminderAt, reminderAt <= Date() { throw CaptureStoreError.reminderNotFuture }
        guard planning?.isValid ?? true else { throw CaptureStoreError.invalidOriginal("Check the task dates, estimate, and checklist before saving.") }
        let task = Capture(capturedAt: at, timeZone: timeZone, kind: .task,
                           originalText: trimmed, title: String(trimmed.prefix(100)))
        task.reminderAt = reminderAt
        task.reminderTimeZoneID = reminderAt == nil ? nil : (reminderTimeZoneID ?? timeZone.identifier)
        task.reminderRevision = reminderAt == nil ? 0 : 1
        task.notificationState = reminderAt == nil ? "none" : "pending"
        task.projectName = normalizedProjectName(projectName)
        task.previewState = "ready"
        if let planning { task.setTaskPlanning(normalizedPlanning(planning, for: task)) }
        // The task and desired reminder are committed together before becoming visible.
        try failureInjector?(.beforeMetadataSave)
        try persist(task)
        captures.append(task)
        captures.sort { $0.capturedAt == $1.capturedAt ? $0.id.uuidString < $1.id.uuidString : $0.capturedAt > $1.capturedAt }
        return task
    }

    /// Converts in place. Content type and receipt identity stay immutable, so
    /// previews, originals, clipboard copies and reminders retain their meaning.
    func convertToTask(_ capture: Capture) throws {
        try requireCurrent(capture)
        guard !capture.isTask else { return }
        let previous = (capture.convertedToTask, capture.isCompleted, capture.updatedAt, capture.parentTaskID)
        // Promoting an attached item makes it independently actionable; nesting tasks is not supported.
        capture.setParentTaskID(nil)
        capture.setConvertedToTask(true)
        capture.isCompleted = false
        capture.updatedAt = Date()
        do {
            try failureInjector?(.beforeMetadataSave)
            try persist(capture)
            objectWillChange.send()
        } catch {
            capture.setConvertedToTask(previous.0)
            capture.isCompleted = previous.1
            capture.updatedAt = previous.2
            capture.setParentTaskID(previous.3)
            throw error
        }
    }

    @discardableResult
    func setTaskCompleted(_ capture: Capture, completed: Bool, at now: Date = Date()) throws -> Capture? {
        guard capture.isTask, capture.isCompleted != completed else { return nil }
        try requireCurrent(capture)
        let old = (capture.isCompleted, capture.reminderRevision, capture.notificationState, capture.updatedAt, capture.taskPlanning)
        let successor = completed ? recurrenceSuccessor(for: capture, at: now) : nil
        var planning = capture.taskPlanning ?? TaskPlanning()
        planning.completedAt = completed ? now : nil
        if completed { planning.focusSession = planning.focusSession?.paused(at: now) }
        if let successor { planning.nextOccurrenceID = successor.id }
        capture.setTaskPlanning(planning)
        capture.isCompleted = completed
        // Invalidate an in-flight schedule even when its reminder date is unchanged.
        capture.reminderRevision += 1
        capture.notificationState = completed ? "completed" : (capture.reminderAt == nil ? "none" : "pending")
        capture.updatedAt = now
        do {
            try failureInjector?(.beforeMetadataSave)
            let changed = [capture] + (successor.map { [$0] } ?? [])
            // Completion and its next occurrence are one transaction. A failed
            // write can never leave a completed routine without its next task.
            try repository.save(changed)
            if let successor {
                captures.append(successor)
                captures.sort { $0.capturedAt == $1.capturedAt ? $0.id.uuidString < $1.id.uuidString : $0.capturedAt > $1.capturedAt }
            }
            synchronizeArchive(changed)
            objectWillChange.send()
            return successor
        }
        catch {
            capture.isCompleted = old.0; capture.reminderRevision = old.1
            capture.notificationState = old.2; capture.updatedAt = old.3
            capture.setTaskPlanning(old.4)
            throw error
        }
    }

    /// Change the work plan without changing receipt dates, originals, or reminders.
    func setTaskPlanning(_ capture: Capture, planning: TaskPlanning) throws {
        try requireCurrent(capture)
        guard capture.isTask, planning.isValid else {
            throw CaptureStoreError.invalidOriginal("Check the task dates, estimate, and checklist before saving.")
        }
        var value = normalizedPlanning(planning, for: capture)
        // Completion history and occurrence identity are store-owned, not editable fields.
        value.completedAt = capture.taskPlanning?.completedAt
        value.previousOccurrenceID = capture.taskPlanning?.previousOccurrenceID
        value.nextOccurrenceID = capture.taskPlanning?.nextOccurrenceID
        // A stale form may not restart or overwrite a separately committed timer.
        value.focusSession = capture.taskPlanning?.focusSession
        guard capture.taskPlanning != value else { return }
        let old = (capture.taskPlanning, capture.updatedAt)
        capture.setTaskPlanning(value)
        capture.updatedAt = Date()
        do { try failureInjector?(.beforeMetadataSave); try persist(capture); objectWillChange.send() }
        catch { capture.setTaskPlanning(old.0); capture.updatedAt = old.1; throw error }
    }

    func planTask(_ capture: Capture, on day: String?, time: String? = nil) throws {
        var planning = capture.taskPlanning ?? TaskPlanning()
        planning.plannedDay = day
        planning.plannedTime = day == nil ? nil : time
        planning.order = nil
        try setTaskPlanning(capture, planning: planning)
    }

    /// Timer mutations are independent transactions and never touch reminders.
    func setTaskFocus(_ capture: Capture, session: TaskFocusSession?, durationMinutes: Int? = nil) throws {
        try requireCurrent(capture)
        var planning = capture.taskPlanning ?? TaskPlanning()
        if let durationMinutes { planning.effortMinutes = durationMinutes }
        planning.focusSession = session
        guard capture.isTask, planning.isValid,
              !capture.isCompleted || session?.isRunning != true else {
            throw CaptureStoreError.invalidOriginal("Choose a duration from 1 minute to 168 hours for an open task.")
        }
        guard planning != capture.taskPlanning else { return }
        let old = (capture.taskPlanning, capture.updatedAt)
        capture.setTaskPlanning(planning); capture.updatedAt = Date()
        do { try failureInjector?(.beforeMetadataSave); try persist(capture); objectWillChange.send() }
        catch { capture.setTaskPlanning(old.0); capture.updatedAt = old.1; throw error }
    }

    /// Only reverses the promotion flag and its former attachment relationship.
    /// Later annotations, project choices and provenance remain untouched.
    func undoTaskConversion(_ capture: Capture, previousParentID: UUID?) throws {
        try requireCurrent(capture)
        guard capture.convertedToTask, capture.kind != .task, !capture.isCompleted,
              (capture.taskPlanning == nil || capture.taskPlanning == TaskPlanning()), attachments(for: capture).isEmpty else {
            throw CaptureStoreError.invalidOriginal("This task has new planning or attachments. Keep it as a task to preserve that work.")
        }
        if let id = previousParentID {
            guard captures.contains(where: { $0.id == id && $0.isTask }) else {
                throw CaptureStoreError.invalidOriginal("The original parent task is unavailable.")
            }
        }
        let old = (capture.updatedAt, capture.parentTaskID, capture.taskPlanning)
        capture.setConvertedToTask(false); capture.setParentTaskID(previousParentID); capture.setTaskPlanning(nil); capture.updatedAt = Date()
        do { try failureInjector?(.beforeMetadataSave); try persist(capture); objectWillChange.send() }
        catch { capture.setConvertedToTask(true); capture.setParentTaskID(old.1); capture.setTaskPlanning(old.2); capture.updatedAt = old.0; throw error }
    }

    /// A project-filtered reorder preserves the positions of other projects.
    func reorderTasks(_ tasks: [Capture], on day: String) throws {
        guard TaskPlanningPolicy.date(for: day) != nil,
              Set(tasks.map(\.id)).count == tasks.count else {
            throw CaptureStoreError.invalidOriginal("The task order could not be saved.")
        }
        for task in tasks {
            try requireCurrent(task)
            guard TaskPlanningPolicy.isPlanned(task, for: day) else {
                throw CaptureStoreError.invalidOriginal("Only open tasks planned for this day can be reordered.")
            }
        }
        guard !tasks.isEmpty else { return }
        let ids = Set(tasks.map(\.id))
        var ordered = tasks.makeIterator()
        let all = TaskPlanningPolicy.sorted(captures.filter { TaskPlanningPolicy.isPlanned($0, for: day) })
            .map { ids.contains($0.id) ? ordered.next()! : $0 }
        let previous = all.map { ($0, $0.taskPlanning, $0.updatedAt) }
        for (index, task) in all.enumerated() {
            var planning = task.taskPlanning ?? TaskPlanning()
            planning.order = index
            task.setTaskPlanning(planning)
            task.updatedAt = Date()
        }
        do {
            try failureInjector?(.beforeMetadataSave)
            try repository.save(all)
            synchronizeArchive(all)
            objectWillChange.send()
        } catch {
            for (task, planning, updatedAt) in previous { task.setTaskPlanning(planning); task.updatedAt = updatedAt }
            throw error
        }
    }

    private func recurrenceSuccessor(for capture: Capture, at now: Date) -> Capture? {
        guard let previous = capture.taskPlanning, previous.recurrence != .none,
              previous.nextOccurrenceID == nil else { return nil }
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: capture.captureTimeZoneID) ?? .current
        let plannedDate = previous.plannedDay.flatMap { TaskPlanningPolicy.date(for: $0, calendar: calendar) }
        let currentAnchor = plannedDate
            ?? previous.deadline ?? capture.reminderAt ?? capture.capturedAt
        let anchor = previous.recurrenceAnchor ?? currentAnchor
        // A completed occurrence represents its entire planned day. An afternoon
        // cadence must not recreate that same day when the user finishes at noon.
        let occurrenceEnd = plannedDate.flatMap {
            calendar.date(byAdding: .day, value: 1, to: calendar.startOfDay(for: $0))?.addingTimeInterval(-0.001)
        } ?? currentAnchor
        guard let nextDate = previous.recurrence.nextDate(after: anchor, notBefore: max(now, occurrenceEnd), calendar: calendar) else { return nil }
        let dayOffset = calendar.dateComponents([.day], from: calendar.startOfDay(for: currentAnchor),
                                                to: calendar.startOfDay(for: nextDate)).day ?? 1
        func shifted(_ date: Date?) -> Date? { date.flatMap { calendar.date(byAdding: .day, value: dayOffset, to: $0) } }
        var next = previous
        next.plannedDay = CaptureCalendar.dayString(nextDate, timeZone: calendar.timeZone)
        next.deadline = shifted(previous.deadline)
        next.order = nil
        next.completedAt = nil
        next.focusSession = nil
        next.previousOccurrenceID = capture.id
        next.nextOccurrenceID = nil
        next.recurrenceAnchor = anchor
        next.checklist = previous.checklist.map { TaskChecklistItem(text: $0.text) }
        // The next occurrence reuses known content provenance, but is a new
        // manual task, never another automatic capture or a duplicated file.
        let receipt = CaptureReceiptContext(origin: .manual, automaticActionID: nil,
            sourceApplicationName: capture.sourceApplicationName,
            sourceApplicationBundleIdentifier: capture.sourceApplicationBundleIdentifier)
        let successor = Capture(capturedAt: now, timeZone: calendar.timeZone, kind: .task,
                                originalURL: capture.originalURL,
                                originalText: capture.originalText ?? capture.title, title: capture.title,
                                sourceFilePath: capture.sourceFilePath, sourceURL: capture.sourceURL,
                                receipt: receipt)
        successor.previewState = "ready"
        successor.comment = capture.comment
        successor.setCommentEntries(capture.commentThread)
        successor.projectName = capture.projectName
        successor.setTaskPlanning(next)
        let reminder = shifted(capture.reminderAt)
        successor.reminderAt = reminder.flatMap { $0 > now ? $0 : nil }
        successor.reminderTimeZoneID = successor.reminderAt == nil ? nil : capture.reminderTimeZoneID
        successor.reminderRevision = successor.reminderAt == nil ? 0 : 1
        successor.notificationState = successor.reminderAt == nil ? "none" : "pending"
        return successor
    }

    private func normalizedPlanning(_ planning: TaskPlanning, for capture: Capture) -> TaskPlanning {
        var value = planning
        if value.recurrence == .none { value.recurrenceAnchor = nil }
        else if capture.taskPlanning?.recurrence != value.recurrence
            || capture.taskPlanning?.plannedDay != value.plannedDay
            || capture.taskPlanning?.recurrenceAnchor == nil {
            var calendar = Calendar(identifier: .gregorian)
            calendar.timeZone = TimeZone(identifier: capture.captureTimeZoneID) ?? .current
            value.recurrenceAnchor = value.plannedDay.flatMap { TaskPlanningPolicy.date(for: $0, calendar: calendar) }
                ?? value.deadline ?? capture.reminderAt ?? capture.capturedAt
        } else { value.recurrenceAnchor = capture.taskPlanning?.recurrenceAnchor }
        return value
    }

    func setMinimized(_ capture: Capture, minimized: Bool) throws {
        try requireCurrent(capture)
        guard capture.isMinimized != minimized else { return }
        let previous = (capture.isMinimized, capture.updatedAt)
        capture.isMinimized = minimized
        capture.updatedAt = Date()
        do { try failureInjector?(.beforeMetadataSave); try persist(capture); objectWillChange.send() }
        catch {
            capture.isMinimized = previous.0
            capture.updatedAt = previous.1
            throw error
        }
    }

    func setOrganization(_ capture: Capture, pinned: Bool, projectName: String?) throws {
        try requireCurrent(capture)
        let project = normalizedProjectName(projectName)
        guard capture.isPinned != pinned || capture.projectName != project else { return }
        let old = (capture.isPinned, capture.projectName, capture.updatedAt)
        capture.isPinned = pinned
        capture.projectName = project
        capture.updatedAt = Date()
        do {
            try failureInjector?(.beforeMetadataSave)
            try persist(capture)
            objectWillChange.send()
        } catch {
            capture.isPinned = old.0
            capture.projectName = old.1
            capture.updatedAt = old.2
            throw error
        }
    }

    private func normalizedProjectName(_ name: String?) -> String? {
        let trimmed = name?.trimmingCharacters(in: .whitespacesAndNewlines).precomposedStringWithCanonicalMapping ?? ""
        return trimmed.isEmpty ? nil : String(trimmed.prefix(180))
    }

    /// A logical snapshot and verified owned files, never a copy of live SQLite.
    func exportBackup(to destination: URL) throws {
        let scoped = destination.startAccessingSecurityScopedResource()
        defer { if scoped { destination.stopAccessingSecurityScopedResource() } }
        try requireStableArchiveForBackup()
        // External edits to the readable daily file may not have triggered an
        // app save yet. Preserve them into owned recovery sidecars first.
        synchronizeArchive(captures + trashedCaptures)
        guard archiveFailures.isEmpty else {
            throw ArchiveBackupError.invalid("Some project documents could not be refreshed safely. Resolve the archive warning before creating a backup.")
        }
        try requireStableArchiveForBackup()
        let snapshots = try repository.load()
        try repository.validateSnapshots(snapshots)
        try ArchiveBackup.export(snapshots: snapshots, archiveRoot: root, to: destination)
    }

    func restoreBackup(from source: URL) throws -> ArchiveRestoreResult {
        let scoped = source.startAccessingSecurityScopedResource()
        defer { if scoped { source.stopAccessingSecurityScopedResource() } }
        try requireStableArchiveForBackup()
        let result = try ArchiveBackup.restore(from: source, into: root,
            existing: repository.load(), validate: repository.validateSnapshots,
            checkpoint: { try self.backupFailureInjector?($0) },
            commit: { try self.repository.saveSnapshots($0) })
        let restored = result.addedSnapshots.map(Capture.init(snapshot:))
        captures.append(contentsOf: restored.filter { $0.deletedAt == nil })
        trashedCaptures.append(contentsOf: restored.filter { $0.deletedAt != nil })
        captures.sort { $0.capturedAt == $1.capturedAt ? $0.id.uuidString < $1.id.uuidString : $0.capturedAt > $1.capturedAt }
        trashedCaptures.sort { ($0.deletedAt ?? .distantPast) > ($1.deletedAt ?? .distantPast) }
        synchronizeArchive(restored)
        return ArchiveRestoreResult(addedCount: restored.count, existingCount: result.existingCount)
    }

    private func requireStableArchiveForBackup() throws {
        let imports = try FileManager.default.contentsOfDirectory(at: safeURL("Imports"), includingPropertiesForKeys: nil)
        let moves = try safeURL("ExplorerMoves")
        let pendingMoves = FileManager.default.fileExists(atPath: moves.path)
            ? try FileManager.default.contentsOfDirectory(at: moves, includingPropertiesForKeys: nil) : []
        guard pendingRemovalIDs.isEmpty, !imports.contains(where: { $0.pathExtension == "json" }),
              !pendingMoves.contains(where: { $0.pathExtension == "json" }) else {
            throw ArchiveBackupError.busy
        }
    }

    /// The caller first cancels and awaits the capture's preview and local text-index
    /// work. Notification cancellation follows this committed removal, so delayed schedules see no record.
    /// No owned files are removed until the database deletion has committed.
    func remove(_ capture: Capture) throws -> CaptureRemovalResult {
        try requireCurrent(capture)
        return try removeOwnedCapture(capture)
    }

    /// Recoverable removal retains all originals and annotations. Replace the
    /// visible object after commit so a delayed service cannot mutate the trash.
    func moveToTrash(_ capture: Capture) throws {
        try requireCurrent(capture)
        let family = captureFamily(for: capture)
        let before = family.map(CaptureSnapshot.init)
        let timestamp = Date()
        for member in family {
            member.deletedAt = timestamp
            member.reminderRevision += 1
            member.notificationState = "trashed"
            member.updatedAt = timestamp
        }
        do {
            try failureInjector?(.beforeMetadataSave)
            try repository.save(family)
        } catch {
            rollbackTrashState(family, snapshots: before)
            throw error
        }
        let ids = Set(family.map(\.id))
        let retained = family.map { Capture(snapshot: CaptureSnapshot($0)) }
        captures.removeAll { ids.contains($0.id) }
        trashedCaptures.append(contentsOf: retained)
        trashedCaptures.sort { ($0.deletedAt ?? .distantPast) > ($1.deletedAt ?? .distantPast) }
        synchronizeArchive(retained)
    }

    func restoreFromTrash(_ capture: Capture) throws {
        try requireTrashed(capture)
        if let parentID = capture.parentTaskID {
            guard let parent = captures.first(where: { $0.id == parentID }) else {
                throw CaptureStoreError.invalidOriginal("Restore the task before restoring its attachment.")
            }
            try requireAttachmentParent(parent)
        }
        // Only restore children trashed together with this task. Earlier individual
        // removals remain in Recently Deleted until the user restores them.
        let family = [capture] + trashedCaptures.filter {
            $0.parentTaskID == capture.id && $0.deletedAt == capture.deletedAt
        }
        let before = family.map(CaptureSnapshot.init)
        for member in family {
            member.deletedAt = nil
            member.reminderRevision += 1
            member.notificationState = member.isTask && member.isCompleted ? "completed"
                : (member.reminderAt == nil ? "none" : "pending")
            member.updatedAt = Date()
        }
        do {
            try failureInjector?(.beforeMetadataSave)
            try repository.save(family)
        } catch {
            rollbackTrashState(family, snapshots: before)
            throw error
        }
        let ids = Set(family.map(\.id))
        let restored = family.map { Capture(snapshot: CaptureSnapshot($0)) }
        trashedCaptures.removeAll { ids.contains($0.id) }
        captures.append(contentsOf: restored)
        captures.sort { $0.capturedAt == $1.capturedAt ? $0.id.uuidString < $1.id.uuidString : $0.capturedAt > $1.capturedAt }
        synchronizeArchive(restored)
    }

    private func rollbackTrashState(_ family: [Capture], snapshots: [CaptureSnapshot]) {
        for (member, previous) in zip(family, snapshots) {
            member.deletedAt = previous.deletedAt
            member.reminderRevision = previous.reminderRevision
            member.notificationState = previous.notificationState
            member.updatedAt = previous.updatedAt
        }
    }

    /// Destructive deletion is available only for an explicitly selected trash
    /// record. Legacy remove() retains its existing active-record semantics.
    func permanentlyRemove(_ capture: Capture) throws -> CaptureRemovalResult {
        try requireTrashed(capture)
        return try removeOwnedCapture(capture)
    }

    private func removeOwnedCapture(_ capture: Capture) throws -> CaptureRemovalResult {
        let family = captureFamily(for: capture, includingTrashed: true)
        for member in family {
            if FileManager.default.fileExists(atPath: try safeURL("ExplorerMoves/\(member.id.uuidString).json").path) {
                throw CaptureStoreError.invalidOriginal("A project file move needs recovery before this item can be removed. Retry Explorer synchronization first.")
            }
        }
        let journals = family.map { CaptureRemovalJournal($0, projectName: explorerProject(for: $0)) }
        let ids = Set(family.map(\.id))
        try archive.ensureDirectory("Deletions")
        var prepared: [(CaptureRemovalJournal, URL)] = []
        do {
            // Every deletion intent is durable before the one metadata transaction.
            // A crash during preparation retains the entire task and all originals.
            for journal in journals {
                for path in try journal.ownedPaths() { try validateRemovalPath(path) }
                let journalURL = try safeURL("Deletions/\(journal.id.uuidString).json")
                guard !FileManager.default.fileExists(atPath: journalURL.path) else {
                    throw CaptureStoreError.invalidOriginal("An earlier removal needs recovery. Reopen DaBin before trying again.")
                }
                let temporary = try safeURL("Deletions/.\(journal.id.uuidString)-\(UUID().uuidString).pending")
                do {
                    try JSONEncoder().encode(journal).write(to: temporary, options: .atomic)
                    try FileManager.default.moveItem(at: temporary, to: journalURL)
                } catch {
                    try? FileManager.default.removeItem(at: temporary)
                    throw error
                }
                prepared.append((journal, journalURL))
                pendingRemovalIDs.insert(journal.id)
            }
        } catch {
            for (journal, url) in prepared {
                if (try? FileManager.default.removeItem(at: url)) != nil { pendingRemovalIDs.remove(journal.id) }
            }
            throw error
        }
        var committed = false
        do {
            try removalFailureInjector?(.afterJournal)
            try removalFailureInjector?(.beforeMetadataDelete)
            try repository.remove(ids: ids)
            committed = true
            captures.removeAll { ids.contains($0.id) }
            trashedCaptures.removeAll { ids.contains($0.id) }
            ids.forEach { archiveFailures.removeValue(forKey: $0) }
            synchronizeArchive([], removed: family)
            try removalFailureInjector?(.afterMetadataDelete)
        } catch {
            if case CaptureStoreError.injectedInterruption = error { throw error }
            if !committed {
                for (journal, url) in prepared {
                    do {
                        try FileManager.default.removeItem(at: url)
                        pendingRemovalIDs.remove(journal.id)
                    } catch {
                        self.error = "The capture was kept. Removal preparation will be cleared when DaBin reopens."
                    }
                }
                throw error
            }
        }
        do {
            try removalFailureInjector?(.beforeFileCleanup)
            for (journal, url) in prepared { try finishRemoval(journal, journalURL: url) }
            try removalFailureInjector?(.afterFileCleanup)
            return CaptureRemovalResult(warning: nil)
        } catch {
            if case CaptureStoreError.injectedInterruption = error { throw error }
            let warning = "Capture removed. Some of its local files could not be removed and will be retried when DaBin opens. \(error.localizedDescription)"
            self.error = [self.error, warning].compactMap { $0 }.joined(separator: "\n")
            return CaptureRemovalResult(warning: warning)
        }
    }

    func importData(_ data: Data, filename: String, at: Date = Date(), timeZone: TimeZone = .current,
                    source: CaptureSource = .unknown,
                    receipt: CaptureReceiptContext = .manual, projectName: String? = nil,
                    parentTask: Capture? = nil,
                    commitGuard: @escaping () -> Bool = { true }) async throws -> Capture {
        try await importOriginal(filename: filename,
                                 contentType: UTType(filenameExtension: (filename as NSString).pathExtension),
                                 at: at, timeZone: timeZone, source: source, receipt: receipt,
                                 projectName: projectName, parentTask: parentTask,
                                 commitGuard: commitGuard) { destination in
            try data.write(to: destination, options: [.atomic])
        }
    }

    private func importOriginal(filename: String, contentType: UTType?, at: Date, timeZone: TimeZone,
                                source: CaptureSource, receipt: CaptureReceiptContext, projectName: String?,
                                parentTask: Capture?,
                                commitGuard: @escaping () -> Bool,
                                copy: @escaping @Sendable (URL) throws -> Void) async throws -> Capture {
        try requireAttachmentParent(parentTask)
        let effectiveProject: String?
        if let parentTask { effectiveProject = normalizedProjectName(parentTask.projectName) }
        else { effectiveProject = normalizedProjectName(projectName) }
        let id = UUID()
        let safeName = CaptureClassifier.storageFilename(filename)
        var journal = ImportJournal(id: id, capturedAt: at, captureDay: CaptureCalendar.dayString(at, timeZone: timeZone),
                                    timeZoneID: timeZone.identifier, utcOffset: timeZone.secondsFromGMT(for: at),
                                    originalFilename: filename, sourceFilePath: source.filePath, sourceURL: source.url,
                                    parentTaskID: parentTask?.id,
                                    projectName: effectiveProject,
                                    captureOriginRaw: receipt.origin.rawValue,
                                    automaticActionID: receipt.origin.isAutomatic ? receipt.automaticActionID : nil,
                                    sourceApplicationName: receipt.sourceApplicationName,
                                    sourceApplicationBundleIdentifier: receipt.sourceApplicationBundleIdentifier,
                                    relativePath: try ProjectFileArchive.originalRelativePath(id: id, project: effectiveProject,
                                        day: CaptureCalendar.dayString(at, timeZone: timeZone),
                                        kind: CaptureClassifier.fileKind(filename: filename, contentType: contentType), filename: filename),
                                    stagingRelativePath: "Staging/\(id.uuidString)/\(safeName)",
                                    kind: CaptureClassifier.fileKind(filename: filename, contentType: contentType),
                                    contentType: contentType?.identifier, phase: "receiving")
        let staging = try safeURL(journal.stagingRelativePath)
        let original = try safeURL(journal.relativePath)
        let journalURL = root.appendingPathComponent("Imports/\(id.uuidString).json")
        var inserted: Capture?
        var committed = false
        do {
            try FileManager.default.createDirectory(at: staging.deletingLastPathComponent(), withIntermediateDirectories: false)
            try writeJournal(journal, at: journalURL)
            try failureInjector?(.beforeCopy)
            let verification = try await Task.detached(priority: .utility) {
                try copy(staging)
                return try OriginalFileStorage.verify(staging)
            }.value
            journal.byteCount = verification.byteCount
            journal.sha256 = verification.sha256
            journal.phase = "copied"
            try writeJournal(journal, at: journalURL)
            try failureInjector?(.afterCopy)
            try archive.ensureDirectory((journal.relativePath as NSString).deletingLastPathComponent)
            try FileManager.default.moveItem(at: staging, to: original)
            journal.phase = "moved"
            try writeJournal(journal, at: journalURL)
            try failureInjector?(.afterMove)
            guard commitGuard() else { throw CaptureStoreError.captureCancelled }
            try requireAttachmentParent(parentTask)
            let capture = model(for: journal)
            inserted = capture
            try failureInjector?(.beforeMetadataSave)
            try persist(capture)
            committed = true
            insertCommittedCaptures([capture])
            try failureInjector?(.afterMetadataSave)
            cleanupCompleted(journal, journalURL: journalURL)
            return capture
        } catch {
            // An interruption fixture models abrupt process exit, leaving the journal for next launch.
            if case CaptureStoreError.injectedInterruption = error { throw error }
            if !committed {
                compensateOwnedImport(journal, journalURL: journalURL)
                throw error
            }
            // A committed original remains successful even if housekeeping fails afterwards.
            self.error = "The capture was saved. Import cleanup will be retried when DaBin opens."
            return inserted!
        }
    }

    @discardableResult
    func appendComment(_ capture: Capture, text: String, at date: Date = Date()) throws -> CaptureCommentEntry {
        try requireCurrent(capture)
        try validateCommentText(text, at: date)
        var entries = capture.commentThread
        guard entries.count < CaptureCommentThread.maximumEntries else {
            throw CaptureStoreError.invalidOriginal("This capture has reached its comment limit. Edit an existing comment instead.")
        }
        let entry = CaptureCommentEntry(createdAt: date, text: text)
        entries.append(entry)
        try persistComments(CaptureCommentThread.ordered(entries), for: capture, at: date)
        return entry
    }

    @discardableResult
    func updateComment(_ capture: Capture, id: UUID, text: String, at date: Date = Date()) throws -> CaptureCommentEntry {
        try requireCurrent(capture)
        try validateCommentText(text, at: date)
        var entries = capture.commentThread
        guard let index = entries.firstIndex(where: { $0.id == id }) else {
            throw CaptureStoreError.invalidOriginal("This comment is no longer available. Reopen the capture and try again.")
        }
        guard entries[index].text != text else { return entries[index] }
        entries[index].text = text
        entries[index].editedAt = max(date, entries[index].createdAt ?? date)
        try persistComments(entries, for: capture, at: date)
        return entries[index]
    }

    @discardableResult
    func removeComment(_ capture: Capture, id: UUID, at date: Date = Date()) throws -> CaptureCommentRemovalReceipt {
        try requireCurrent(capture)
        guard date.timeIntervalSinceReferenceDate.isFinite else {
            throw CaptureStoreError.invalidOriginal("The comment deletion time is invalid.")
        }
        var entries = capture.commentThread
        guard let index = entries.firstIndex(where: { $0.id == id }) else {
            throw CaptureStoreError.invalidOriginal("This comment is no longer available. Reopen the capture and try again.")
        }
        let removed = entries.remove(at: index)
        try persistComments(entries, for: capture, at: date)
        return CaptureCommentRemovalReceipt(captureID: capture.id, entry: removed)
    }

    /// Add back only the removed reply. Later replies and edits stay intact;
    /// an identity now owned by different text is never overwritten by Undo.
    @discardableResult
    func restoreComment(_ capture: Capture, receipt: CaptureCommentRemovalReceipt, at date: Date = Date()) throws -> Bool {
        try requireCurrent(capture)
        guard receipt.captureID == capture.id, date.timeIntervalSinceReferenceDate.isFinite else {
            throw CaptureStoreError.invalidOriginal("This comment belongs to another capture or has an invalid restoration time.")
        }
        var entries = capture.commentThread
        if let existing = entries.first(where: { $0.id == receipt.entry.id }) {
            guard existing == receipt.entry else {
                throw CaptureStoreError.invalidOriginal("This comment changed after deletion. Your current comment was kept.")
            }
            return false
        }
        guard entries.count < CaptureCommentThread.maximumEntries else {
            throw CaptureStoreError.invalidOriginal("Remove a comment before restoring this reply; this capture has reached its comment limit.")
        }
        entries.append(receipt.entry)
        guard CaptureCommentThread.isValid(entries, aggregate: CaptureCommentThread.text(entries)) else {
            throw CaptureStoreError.invalidOriginal("The saved comment cannot be restored safely. Your current comments were kept.")
        }
        try persistComments(entries, for: capture, at: date)
        return true
    }

    private func validateCommentText(_ text: String, at date: Date) throws {
        guard date.timeIntervalSinceReferenceDate.isFinite,
              !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              text.count <= CaptureCommentThread.maximumNewCommentCharacters else {
            throw CaptureStoreError.invalidOriginal("Write a comment of 1–100,000 characters before saving.")
        }
    }

    private func persistComments(_ entries: [CaptureCommentEntry], for capture: Capture, at date: Date) throws {
        let old = (capture.commentEntries, capture.comment, capture.updatedAt)
        capture.setCommentEntries(CaptureCommentThread.ordered(entries))
        capture.comment = CaptureCommentThread.text(entries)
        capture.updatedAt = date
        do { try failureInjector?(.beforeMetadataSave); try persist(capture); objectWillChange.send() }
        catch {
            capture.setCommentEntries(old.0); capture.comment = old.1; capture.updatedAt = old.2
            throw error
        }
    }

    /// Acknowledges only the exact due occurrences shown by a popup. Stale,
    /// removed, completed or rescheduled occurrences are safely ignored.
    /// All eligible acknowledgments commit as one metadata transaction.
    @discardableResult
    func acknowledgeReminders(_ occurrences: [CaptureReminderOccurrence], at date: Date = Date()) throws -> Int {
        try acknowledgeAlerts(reminders: occurrences, focus: [], at: date)
    }

    /// Persists reminder and focus-completion acknowledgments together. A
    /// failure leaves every occurrence unacknowledged and available to retry.
    @discardableResult
    func acknowledgeAlerts(reminders: [CaptureReminderOccurrence], focus: [CaptureFocusOccurrence],
                           at date: Date = Date()) throws -> Int {
        guard date.timeIntervalSinceReferenceDate.isFinite else {
            throw CaptureStoreError.invalidOriginal("The alert acknowledgment time is invalid.")
        }
        let requestedReminders = Set(reminders)
        let requestedFocus = Set(focus)
        var updates: [(capture: Capture, reminder: CaptureReminderAcknowledgment?, planning: TaskPlanning?, count: Int)] = []
        for capture in captures where !capture.isCompleted && capture.deletedAt == nil && !pendingRemovalIDs.contains(capture.id) {
            var reminder: CaptureReminderAcknowledgment?
            var planning: TaskPlanning?
            var count = 0
            if !capture.isReminderAcknowledged, let occurrence = capture.reminderOccurrence,
               occurrence.revision >= 0, occurrence.dueAt.timeIntervalSinceReferenceDate.isFinite,
               occurrence.dueAt <= date, requestedReminders.contains(occurrence) {
                reminder = CaptureReminderAcknowledgment(revision: occurrence.revision,
                    dueAt: occurrence.dueAt, acknowledgedAt: date)
                count += 1
            }
            if capture.isTask, let occurrence = capture.focusOccurrence, requestedFocus.contains(occurrence),
               var value = capture.taskPlanning, var session = value.focusSession,
               session.acknowledgedAt == nil, let completedAt = session.completedAt,
               completedAt.timeIntervalSinceReferenceDate.isFinite, completedAt <= date,
               session.remainingSeconds == 0, session.endAt == nil {
                session.acknowledgedAt = date
                value.focusSession = session
                planning = value
                count += 1
            }
            if count > 0 { updates.append((capture, reminder, planning, count)) }
        }
        guard !updates.isEmpty else { return 0 }
        let old = updates.map { ($0.capture, $0.capture.reminderAcknowledgment, $0.capture.taskPlanning, $0.capture.updatedAt) }
        for update in updates {
            if let reminder = update.reminder { update.capture.setReminderAcknowledgment(reminder) }
            if let planning = update.planning { update.capture.setTaskPlanning(planning) }
            update.capture.updatedAt = date
        }
        do {
            try failureInjector?(.beforeMetadataSave)
            try repository.save(updates.map(\.capture))
            objectWillChange.send()
            synchronizeArchive(updates.map(\.capture))
            return updates.reduce(0) { $0 + $1.count }
        } catch {
            for (capture, acknowledgment, planning, updatedAt) in old {
                capture.setReminderAcknowledgment(acknowledgment)
                capture.setTaskPlanning(planning)
                capture.updatedAt = updatedAt
            }
            throw error
        }
    }

    /// Convenience for immediate acknowledgment. A displayed popup should keep
    /// immutable occurrence values instead, so later edits cannot change its target.
    @discardableResult
    func acknowledgeReminders(captures records: [Capture], at date: Date = Date()) throws -> Int {
        try acknowledgeReminders(records.compactMap(\.reminderOccurrence), at: date)
    }

    func update(_ capture: Capture, comment: String, reminderAt: Date?, reminderTimeZoneID: String?,
                planning: TaskPlanning? = nil, title: String? = nil) throws {
        try requireCurrent(capture)
        let editedTitle = title?.trimmingCharacters(in: .whitespacesAndNewlines)
        if let editedTitle, (!capture.isTask || editedTitle.isEmpty || editedTitle.count > 2000) {
            throw CaptureStoreError.invalidOriginal("Use a task title of 1–2,000 characters.")
        }
        guard planning == nil || (capture.isTask && planning!.isValid) else {
            throw CaptureStoreError.invalidOriginal("Check the task dates, estimate, and checklist before saving.")
        }
        let old = (capture.comment, capture.reminderAt, capture.reminderTimeZoneID,
                   capture.reminderRevision, capture.notificationState, capture.updatedAt, capture.taskPlanning, capture.title)
        let oldCommentEntries = capture.commentEntries
        let zone = reminderAt == nil ? nil : reminderTimeZoneID
        if capture.reminderAt != reminderAt || capture.reminderTimeZoneID != zone {
            capture.reminderRevision += 1
            capture.notificationState = capture.isTask && capture.isCompleted ? "completed" : (reminderAt == nil ? "none" : "pending")
        }
        if capture.comment != comment {
            // Compatibility for the older single-comment editor. New thread
            // UI uses appendComment/updateComment and never flattens replies.
            var replacement: [CaptureCommentEntry] = []
            if !comment.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                let existing = capture.commentThread
                if existing.count == 1 {
                    var entry = existing[0]
                    entry.text = comment
                    entry.editedAt = max(Date(), entry.createdAt ?? .distantPast)
                    replacement = [entry]
                } else { replacement = [CaptureCommentEntry(createdAt: Date(), text: comment)] }
            }
            capture.setCommentEntries(replacement)
            capture.comment = comment
        }
        if let editedTitle { capture.title = editedTitle }
        capture.reminderAt = reminderAt
        capture.reminderTimeZoneID = zone
        if var planning {
            planning = normalizedPlanning(planning, for: capture)
            planning.completedAt = capture.taskPlanning?.completedAt
            planning.previousOccurrenceID = capture.taskPlanning?.previousOccurrenceID
            planning.nextOccurrenceID = capture.taskPlanning?.nextOccurrenceID
            planning.focusSession = capture.taskPlanning?.focusSession
            // Manual ordering is owned by Today, not by an older detail draft.
            planning.order = planning.plannedDay == capture.taskPlanning?.plannedDay ? capture.taskPlanning?.order : nil
            capture.setTaskPlanning(planning)
        }
        capture.updatedAt = Date()
        do { try failureInjector?(.beforeMetadataSave); try persist(capture); objectWillChange.send() }
        catch {
            capture.comment = old.0; capture.reminderAt = old.1; capture.reminderTimeZoneID = old.2
            capture.reminderRevision = old.3; capture.notificationState = old.4; capture.updatedAt = old.5
            capture.setTaskPlanning(old.6)
            capture.title = old.7
            capture.setCommentEntries(oldCommentEntries)
            throw error
        }
    }

    /// Apply only explicitly chosen fields in one metadata transaction. The
    /// selected identities are frozen by the editor; arrivals never join it.
    func editCaptions(_ records: [Capture], changes: CaptionBatchEdit, at date: Date = Date()) throws {
        let records = CaptionSelection.orderedCaptures(records)
        guard records.count > 1, changes.hasChanges, date.timeIntervalSinceReferenceDate.isFinite else {
            throw CaptureStoreError.invalidOriginal("Choose at least two captions and a detail to change.")
        }
        for capture in records { try requireCurrent(capture) }
        let ids = Set(records.map(\.id))
        if changes.changesProject, records.contains(where: { capture in
            capture.parentTaskID.map { !ids.contains($0) } ?? false
        }) {
            throw CaptureStoreError.invalidOriginal("Select the parent task as well to change an attached caption's project.")
        }
        if changes.changesReminder, let reminder = changes.reminderAt,
           !reminder.timeIntervalSinceReferenceDate.isFinite || reminder <= date {
            throw CaptureStoreError.invalidOriginal("Choose a reminder time in the future.")
        }
        var comments: [UUID: [CaptureCommentEntry]] = [:]
        if let text = changes.comment {
            try validateCommentText(text, at: date)
            for capture in records {
                var entries = capture.commentThread
                guard entries.count < CaptureCommentThread.maximumEntries else {
                    throw CaptureStoreError.invalidOriginal("A selected caption has reached its comment limit.")
                }
                entries.append(CaptureCommentEntry(createdAt: date, text: text))
                entries = CaptureCommentThread.ordered(entries)
                guard CaptureCommentThread.isValid(entries, aggregate: CaptureCommentThread.text(entries)) else {
                    throw CaptureStoreError.invalidOriginal("The comment cannot be added to every selected caption.")
                }
                comments[capture.id] = entries
            }
        }
        let old = records.map { ($0, $0.projectName, $0.commentEntries, $0.comment,
            $0.reminderAt, $0.reminderTimeZoneID, $0.reminderRevision, $0.notificationState, $0.updatedAt) }
        var updated: [Capture] = []
        for capture in records {
            var changed = false
            if changes.changesProject, capture.parentTaskID == nil {
                let project = normalizedProjectName(changes.projectName)
                if capture.projectName != project { capture.projectName = project; changed = true }
            }
            if let entries = comments[capture.id] {
                capture.setCommentEntries(entries); capture.comment = CaptureCommentThread.text(entries); changed = true
            }
            if changes.changesReminder {
                let zone = changes.reminderAt == nil ? nil : TimeZone.current.identifier
                if capture.reminderAt != changes.reminderAt || capture.reminderTimeZoneID != zone {
                    capture.reminderAt = changes.reminderAt; capture.reminderTimeZoneID = zone
                    capture.reminderRevision += 1
                    capture.notificationState = capture.isCompleted ? "completed" : (changes.reminderAt == nil ? "none" : "pending")
                    changed = true
                }
            }
            if changed { capture.updatedAt = date; updated.append(capture) }
        }
        guard !updated.isEmpty else { return }
        do {
            try failureInjector?(.beforeMetadataSave)
            try repository.save(updated)
            objectWillChange.send()
            synchronizeArchive(updated)
        } catch {
            for (capture, project, entries, comment, reminder, zone, revision, notification, updatedAt) in old {
                capture.projectName = project; capture.setCommentEntries(entries); capture.comment = comment
                capture.reminderAt = reminder; capture.reminderTimeZoneID = zone; capture.reminderRevision = revision
                capture.notificationState = notification; capture.updatedAt = updatedAt
            }
            throw error
        }
    }

    func save() throws {
        try save(captures: captures)
    }

    /// Service updates touch only their changed records. Saving a preview or
    /// notification must not rewrite every capture in a long-lived archive.
    func save(captures records: [Capture]) throws {
        guard !records.isEmpty else { return }
        for capture in records { try requireCurrent(capture) }
        try repository.save(records)
        objectWillChange.send()
        synchronizeArchive(records)
    }

    private func persist(_ capture: Capture) throws {
        guard !pendingRemovalIDs.contains(capture.id), capture.deletedAt == nil,
              !trashedCaptures.contains(where: { $0.id == capture.id }) else {
            throw CaptureStoreError.invalidOriginal("This capture is being removed.")
        }
        if let parentID = capture.parentTaskID {
            guard let parent = captures.first(where: { $0.id == parentID }) else {
                throw CaptureStoreError.invalidOriginal("The task is no longer available for this attachment.")
            }
            try requireAttachmentParent(parent)
        }
        try repository.save([capture])
        // Metadata is already durable. A folder-write failure is retryable and
        // must not turn a successful capture into a misleading failed save.
        synchronizeArchive([capture])
    }

    func refresh() throws {
        let existing = Dictionary(uniqueKeysWithValues: (captures + trashedCaptures).map { ($0.id, $0) })
        let records = try repository.load().map { existing[$0.id] ?? Capture(snapshot: $0) }
        captures = records.filter { $0.deletedAt == nil }
            .sorted { $0.capturedAt == $1.capturedAt ? $0.id.uuidString < $1.id.uuidString : $0.capturedAt > $1.capturedAt }
        trashedCaptures = records.filter { $0.deletedAt != nil }
            .sorted { ($0.deletedAt ?? .distantPast) > ($1.deletedAt ?? .distantPast) }
    }

    /// Newly committed records are already the canonical live objects. Merge
    /// them into the ordered feed once, rather than fetching and decoding the
    /// entire repository after each automatic capture. Full refresh remains the
    /// explicit load/recovery path; ordinary inserts do not republish the trash.
    private func insertCommittedCaptures(_ records: [Capture]) {
        guard !records.isEmpty else { return }
        func precedes(_ lhs: Capture, _ rhs: Capture) -> Bool {
            lhs.capturedAt == rhs.capturedAt ? lhs.id.uuidString < rhs.id.uuidString : lhs.capturedAt > rhs.capturedAt
        }
        let incoming = records.sorted(by: precedes)
        var merged: [Capture] = []
        merged.reserveCapacity(captures.count + incoming.count)
        var currentIndex = 0
        var incomingIndex = 0
        while currentIndex < captures.count, incomingIndex < incoming.count {
            if precedes(incoming[incomingIndex], captures[currentIndex]) {
                merged.append(incoming[incomingIndex])
                incomingIndex += 1
            } else {
                merged.append(captures[currentIndex])
                currentIndex += 1
            }
        }
        merged.append(contentsOf: captures[currentIndex...])
        merged.append(contentsOf: incoming[incomingIndex...])
        captures = merged
    }

    var archiveRoot: URL { root.appendingPathComponent("Archive", isDirectory: true) }

    var explorerRootURL: URL { root }
    func explorerFolderURL(project: String?) throws -> URL { try projectArchive.folderURL(project: project) }
    func explorerDayURL(project: String?, day: String) throws -> URL { try projectArchive.dayURL(project: project, day: day) }
    func explorerFileURL(for capture: Capture) -> URL? { managedURL(for: capture) }
    func explorerProject(for capture: Capture) -> String? {
        projectArchive.effectiveProject(for: capture, records: captures + trashedCaptures)
    }
    func explorerDocuments(project: String? = nil, unfiledOnly: Bool = false) throws -> [ProjectArchiveDay] {
        try projectArchive.documents(records: captures, project: project, unfiledOnly: unfiledOnly)
    }
    /// Explicit maintenance retries failed moves without changing source files.
    func synchronizeExplorer() { synchronizeArchive(captures + trashedCaptures) }

    func prepareArchiveFolder(for capture: Capture? = nil) throws -> URL {
        if let capture {
            try requireCurrent(capture)
            try archive.synchronize(capture)
            guard let url = archiveURL(for: capture) else { throw CaptureStoreError.invalidManagedPath }
            return url
        }
        return try archive.ensureDirectory("Archive")
    }

    /// Finder opens the current saved files, independent of receipt sidecars
    /// and the historical source path from which a file was imported.
    func localArchiveFolderURL(for capture: Capture? = nil) throws -> URL {
        guard let capture else { return try archive.rootFolderURL() }
        try requireCurrent(capture)
        if capture.attachmentRelativePath != nil {
            guard let file = managedURL(for: capture) else {
                throw CaptureStoreError.invalidOriginal("The saved original is unavailable. Its capture details are still kept.")
            }
            return file.deletingLastPathComponent()
        }
        return try archive.ensureDirectory(ProjectFileArchive.dayRelativePath(
            project: explorerProject(for: capture), day: capture.captureDay))
    }

    func archiveURL(for capture: Capture) -> URL? {
        guard let path = try? DailyArchive.captureRelativePath(id: capture.id, capturedAt: capture.capturedAt,
            captureDay: capture.captureDay, utcOffset: capture.captureUTCOffsetSeconds) else { return nil }
        return try? safeURL(path)
    }

    func managedURL(for capture: Capture) -> URL? {
        guard let relative = capture.attachmentRelativePath,
              isOwnedOriginalPath(relative, id: capture.id, capturedAt: capture.capturedAt,
                  captureDay: capture.captureDay, utcOffset: capture.captureUTCOffsetSeconds,
                  filename: capture.originalFilename ?? "", kind: capture.kind),
              let url = try? safeURL(relative), (try? OriginalFileStorage.validateRegularFile(url)) != nil else { return nil }
        return url
    }

    func previewURL(for capture: Capture) -> URL? {
        guard let relative = capture.thumbnailRelativePath,
              relative == "Previews/\(capture.id.uuidString)/thumbnail.png" else { return nil }
        return try? safeURL(relative)
    }

    private func isOwnedOriginalPath(_ relative: String, id: UUID, capturedAt: Date,
                                    captureDay: String, utcOffset: Int, filename: String, kind: CaptureKind? = nil) -> Bool {
        let legacy = "Originals/\(id.uuidString)/\(CaptureClassifier.storageFilename(filename))"
        let current = try? DailyArchive.originalRelativePath(id: id, capturedAt: capturedAt,
            captureDay: captureDay, utcOffset: utcOffset, filename: filename)
        return relative == legacy || relative == current || kind.map {
            ProjectFileArchive.ownsOriginal(relative, id: id, day: captureDay, kind: $0, filename: filename)
        } == true
    }

    private func safeURL(_ relative: String) throws -> URL { try archive.safeURL(relative) }

    /// Excludes the task's original: that content stays on the task itself.
    func attachments(for task: Capture, includingTrashed: Bool = false) -> [Capture] {
        let records = includingTrashed ? captures + trashedCaptures : captures
        return records.filter { $0.parentTaskID == task.id }
            .sorted { $0.capturedAt == $1.capturedAt ? $0.id.uuidString < $1.id.uuidString : $0.capturedAt < $1.capturedAt }
    }

    /// Callers cancel preview/index/reminder jobs for these records before removing a task.
    func captureFamily(for capture: Capture, includingTrashed: Bool = false) -> [Capture] {
        [capture] + attachments(for: capture, includingTrashed: includingTrashed)
    }

    /// Attach an existing receipt without recopying its file or changing source history.
    /// Moving an existing task attachment requires explicit detachment first.
    func attachCapture(_ capture: Capture, to task: Capture) throws {
        try requireCurrent(capture)
        try requireAttachmentParent(task)
        guard !capture.isTask, capture.id != task.id, capture.parentTaskID == nil else {
            throw CaptureStoreError.invalidOriginal("Choose an independent capture to attach to this task.")
        }
        let previous = (capture.parentTaskID, capture.projectName, capture.updatedAt)
        capture.setParentTaskID(task.id)
        if capture.projectName == nil { capture.projectName = task.projectName }
        capture.updatedAt = Date()
        do { try failureInjector?(.beforeMetadataSave); try persist(capture); objectWillChange.send() }
        catch {
            capture.setParentTaskID(previous.0)
            capture.projectName = previous.1
            capture.updatedAt = previous.2
            throw error
        }
    }

    private func requireAttachmentParent(_ task: Capture?) throws {
        guard let task else { return }
        try requireCurrent(task)
        guard task.isTask, task.parentTaskID == nil else {
            throw CaptureStoreError.invalidOriginal("Choose an existing task before adding attachments.")
        }
    }

    private func requireCurrent(_ capture: Capture) throws {
        guard capture.deletedAt == nil, captures.contains(where: { $0 === capture }), !pendingRemovalIDs.contains(capture.id) else {
            throw CaptureStoreError.invalidOriginal("This capture is no longer in the current archive.")
        }
    }

    private func requireTrashed(_ capture: Capture) throws {
        guard capture.deletedAt != nil, trashedCaptures.contains(where: { $0 === capture }),
              !pendingRemovalIDs.contains(capture.id) else {
            throw CaptureStoreError.invalidOriginal("This capture is no longer in Recently Deleted.")
        }
    }

    /// Recovery runs before import recovery. A retained intent blocks any import
    /// receipt with the same ID even when file cleanup needs another retry.
    private func recoverPendingRemovals() throws {
        let directory = try safeURL("Deletions")
        let urls = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
            .filter { $0.pathExtension == "json" }
        pendingRemovalIDs = Set(urls.compactMap { UUID(uuidString: $0.deletingPathExtension().lastPathComponent) })
        for url in urls {
            do {
                _ = try safeURL("Deletions/\(url.lastPathComponent)")
                try OriginalFileStorage.validateRegularFile(url)
                let journal = try JSONDecoder().decode(CaptureRemovalJournal.self, from: Data(contentsOf: url))
                guard url.lastPathComponent == "\(journal.id.uuidString).json" else { throw CaptureStoreError.invalidManagedPath }
                _ = try journal.ownedPaths()
                if (captures + trashedCaptures).contains(where: { $0.id == journal.id }) {
                    // A crash before metadata commit leaves every file intact.
                    try FileManager.default.removeItem(at: url)
                    pendingRemovalIDs.remove(journal.id)
                } else {
                    try finishRemoval(journal, journalURL: url)
                }
            } catch {
                let warning = "A capture removal could not finish safely. Its remaining local files were preserved for retry. \(error.localizedDescription)"
                self.error = [self.error, warning].compactMap { $0 }.joined(separator: "\n")
            }
        }
    }

    private func finishRemoval(_ journal: CaptureRemovalJournal, journalURL: URL) throws {
        // A committed removal may have been interrupted before refreshing its
        // shared daily document. Retain the journal until that view is current.
        let removed = Capture(id: journal.id, capturedAt: journal.capturedAt,
            timeZone: TimeZone(secondsFromGMT: journal.utcOffset) ?? .gmt,
            kind: journal.kindRaw.flatMap(CaptureKind.init(rawValue:)) ?? .text, title: "Removed capture",
            captureDay: journal.captureDay, captureUTCOffsetSeconds: journal.utcOffset)
        removed.projectName = journal.projectName
        try projectArchive.synchronize([removed], records: captures + trashedCaptures, removingIDs: [journal.id]) { _ in }
        var firstFailure: Error?
        for relative in try journal.ownedPaths() {
            do {
                try validateRemovalPath(relative)
                let url = try safeURL(relative)
                if FileManager.default.fileExists(atPath: url.path) {
                    try FileManager.default.removeItem(at: url)
                }
            } catch { if firstFailure == nil { firstFailure = error } }
        }
        if let firstFailure { throw firstFailure }
        _ = try safeURL("Deletions/\(journal.id.uuidString).json")
        try FileManager.default.removeItem(at: journalURL)
        pendingRemovalIDs.remove(journal.id)
    }

    private func validateRemovalPath(_ relative: String) throws {
        let url = try safeURL(relative)
        var directory: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &directory) else { return }
        if relative.hasPrefix("Imports/") || relative.hasPrefix("ExplorerMoves/")
            || relative.hasPrefix("Projects/") || relative.hasPrefix("Unfiled/") || relative.hasPrefix(".Recently Deleted/") {
            try OriginalFileStorage.validateRegularFile(url)
        } else if !directory.boolValue {
            // A file obstructing an owned folder is not a normal DaBin object.
            throw CaptureStoreError.invalidManagedPath
        }
    }

    private func synchronizeArchive(_ records: [Capture], removed: [Capture] = []) {
        let changedIDs = Set(records.map(\.id))
        let children = (captures + trashedCaptures).filter { $0.parentTaskID.map(changedIDs.contains) == true }
        let changed = Array(Dictionary((records + children).map { ($0.id, $0) }, uniquingKeysWith: { _, latest in latest }).values)
        let all = Array(Dictionary((captures + trashedCaptures + changed).map { ($0.id, $0) }, uniquingKeysWith: { _, latest in latest }).values)
        let explorerFailures = projectArchive.synchronizeResults(changed + removed, records: all, removingIDs: Set(removed.map(\.id))) {
            try self.repository.save([$0])
        }
        for capture in changed {
            do {
                if let explorerFailure = explorerFailures[capture.id] { throw CaptureStoreError.invalidOriginal(explorerFailure) }
                try archive.synchronize(capture)
                archiveFailures.removeValue(forKey: capture.id)
                pendingArchiveRepairIDs.remove(capture.id)
            }
            catch { archiveFailures[capture.id] = error.localizedDescription }
        }
        if let explorerFailure = removed.compactMap({ explorerFailures[$0.id] }).first {
            error = "The capture was removed. Its daily document could not be refreshed. \(explorerFailure)"
        }
        if let previous = lastArchiveWarning, let current = error {
            let remaining = current.replacingOccurrences(of: previous, with: "").trimmingCharacters(in: .whitespacesAndNewlines)
            error = remaining.isEmpty ? nil : remaining
        }
        lastArchiveWarning = nil
        if let first = archiveFailures.values.first {
            let warning = "Saved locally. \(archiveFailures.count) capture folder(s) could not be refreshed and will be retried when DaBin opens. \(first)"
            lastArchiveWarning = warning
            error = [error, warning].compactMap { $0 }.joined(separator: "\n")
        }
    }

    private func writeJournal(_ journal: ImportJournal, at url: URL) throws {
        try JSONEncoder().encode(journal).write(to: url, options: .atomic)
    }

    private func model(for journal: ImportJournal) -> Capture {
        let capture = Capture(id: journal.id, capturedAt: journal.capturedAt,
                              timeZone: TimeZone(identifier: journal.timeZoneID) ?? TimeZone(secondsFromGMT: journal.utcOffset) ?? TimeZone(secondsFromGMT: 0)!,
                              kind: journal.kind, attachmentRelativePath: journal.relativePath,
                              originalFilename: journal.originalFilename, contentType: journal.contentType,
                              byteCount: journal.byteCount, title: journal.originalFilename,
                              captureDay: journal.captureDay, captureTimeZoneID: journal.timeZoneID,
                              captureUTCOffsetSeconds: journal.utcOffset,
                              sourceFilePath: journal.sourceFilePath, sourceURL: journal.sourceURL,
                              receipt: CaptureReceiptContext(
                                origin: CaptureOrigin(rawValue: journal.captureOriginRaw ?? "") ?? .manual,
                                automaticActionID: journal.automaticActionID,
                                sourceApplicationName: journal.sourceApplicationName,
                                sourceApplicationBundleIdentifier: journal.sourceApplicationBundleIdentifier),
                              parentTaskID: journal.parentTaskID)
        capture.projectName = normalizedProjectName(journal.projectName)
        return capture
    }

    private func cleanupCompleted(_ journal: ImportJournal, journalURL: URL) {
        if let staging = try? safeURL("Staging/\(journal.id.uuidString)") { try? FileManager.default.removeItem(at: staging) }
        try? FileManager.default.removeItem(at: journalURL)
    }

    private func compensateOwnedImport(_ journal: ImportJournal, journalURL: URL) {
        var cleanupFailed = false
        let imported = ProjectFileArchive.ownsOriginal(journal.relativePath, id: journal.id, day: journal.captureDay,
            kind: journal.kind, filename: journal.originalFilename)
            ? journal.relativePath : (journal.relativePath as NSString).deletingLastPathComponent
        for relative in ["Staging/\(journal.id.uuidString)", imported] {
            do {
                let url = try safeURL(relative)
                if FileManager.default.fileExists(atPath: url.path) { try FileManager.default.removeItem(at: url) }
            } catch { cleanupFailed = true }
        }
        if !cleanupFailed { try? FileManager.default.removeItem(at: journalURL) }
        else { self.error = "An interrupted import was preserved for recovery. Your existing captures are unchanged." }
    }

    private func recoverInterruptedImports() throws {
        let manager = FileManager.default
        let journalFiles = try manager.contentsOfDirectory(at: root.appendingPathComponent("Imports"),
                                                            includingPropertiesForKeys: nil).filter { $0.pathExtension == "json" }
        var warnings: [String] = []
        for journalURL in journalFiles {
            do {
                if let id = UUID(uuidString: journalURL.deletingPathExtension().lastPathComponent), pendingRemovalIDs.contains(id) {
                    warnings.append("A pending removal blocks recovery of the deleted capture's import receipt.")
                    continue
                }
                try OriginalFileStorage.validateRegularFile(journalURL)
                let journal = try JSONDecoder().decode(ImportJournal.self, from: Data(contentsOf: journalURL))
                // Treat journal paths as untrusted persisted input; IDs bind ownership and filenames.
                guard journalURL.lastPathComponent == "\(journal.id.uuidString).json",
                      journal.captureOriginRaw.map({ CaptureOrigin(rawValue: $0) != nil }) ?? true,
                      !(journal.captureOriginRaw.flatMap(CaptureOrigin.init(rawValue:))?.isAutomatic ?? false)
                        || journal.automaticActionID != nil,
                      isOwnedOriginalPath(journal.relativePath, id: journal.id, capturedAt: journal.capturedAt,
                          captureDay: journal.captureDay, utcOffset: journal.utcOffset, filename: journal.originalFilename, kind: journal.kind),
                      journal.stagingRelativePath == "Staging/\(journal.id.uuidString)/\(CaptureClassifier.storageFilename(journal.originalFilename))" else {
                    throw CaptureStoreError.invalidManagedPath
                }
                let original = try safeURL(journal.relativePath)
                let staging = try safeURL(journal.stagingRelativePath)
                if let capture = (captures + trashedCaptures).first(where: { $0.id == journal.id }) {
                    guard let managed = managedURL(for: capture) else { throw CaptureStoreError.importVerificationFailed }
                    // Explorer may have committed its verified project path
                    // before interruption left this older import receipt behind.
                    if capture.attachmentRelativePath != journal.relativePath {
                        let verification = try OriginalFileStorage.verify(managed)
                        guard verification.byteCount == journal.byteCount, verification.sha256 == journal.sha256 else {
                            throw CaptureStoreError.importVerificationFailed
                        }
                    }
                    cleanupCompleted(journal, journalURL: journalURL)
                    continue
                }
                guard let expectedSize = journal.byteCount, let expectedHash = journal.sha256 else {
                    warnings.append("An incomplete import remains in Staging; its bytes have been preserved.")
                    continue
                }
                let candidate = manager.fileExists(atPath: original.path) ? original : staging
                let verification = try OriginalFileStorage.verify(candidate)
                guard verification.byteCount == expectedSize, verification.sha256 == expectedHash else {
                    throw CaptureStoreError.importVerificationFailed
                }
                if candidate == staging {
                    try archive.ensureDirectory((journal.relativePath as NSString).deletingLastPathComponent)
                    try manager.moveItem(at: staging, to: original)
                }
                let capture = model(for: journal)
                try persist(capture)
                captures.append(capture)
                cleanupCompleted(journal, journalURL: journalURL)
            } catch {
                warnings.append("An interrupted import could not be recovered automatically. Its files were preserved. \(error.localizedDescription)")
            }
        }
        // Unknown files are never deleted. They may be the only surviving copy after an interrupted import.
        let remainingJournalIDs = Set((try manager.contentsOfDirectory(at: root.appendingPathComponent("Imports"), includingPropertiesForKeys: nil)).map { $0.deletingPathExtension().lastPathComponent })
        let savedIDs = Set((captures + trashedCaptures).map { $0.id.uuidString })
        for directory in ["Staging", "Originals"] {
            let children = try manager.contentsOfDirectory(at: root.appendingPathComponent(directory), includingPropertiesForKeys: nil)
            let unknown = children.filter {
                !remainingJournalIDs.contains($0.lastPathComponent) && (directory == "Staging" || !savedIDs.contains($0.lastPathComponent))
            }
            if !unknown.isEmpty {
                warnings.append("Unclaimed files in \(directory) were preserved for manual recovery.")
            }
        }
        if !warnings.isEmpty { error = [error, warnings.joined(separator: "\n")].compactMap { $0 }.joined(separator: "\n") }
    }
}
