import SwiftUI
import Combine
import UniformTypeIdentifiers

/// One project, including task attachments and its live scratchpad. The grid
/// uses recycled native List rows; no hidden inspector or offscreen thumbnails.
enum ProjectWorkspaceItem: Identifiable {
    case capture(Capture), note(WorkspaceScratchpad)
    var id: String {
        switch self {
        case .capture(let capture): return "capture:" + capture.id.uuidString
        case .note(let note): return "note:" + WorkspaceSnapshot.projectKey(note.projectName)
        }
    }
    var date: Date {
        switch self { case .capture(let capture): return capture.capturedAt; case .note(let note): return note.updatedAt }
    }
    var capture: Capture? { if case .capture(let capture) = self { return capture }; return nil }
    var title: String {
        switch self {
        case .capture(let capture): return capture.title.isEmpty ? "Untitled capture" : capture.title
        case .note: return "Project notes"
        }
    }
}

private enum ProjectWorkspaceFilter: String, CaseIterable, Identifiable {
    case all = "All", files = "Files", captures = "Captures & notes", links = "Links", tasks = "Tasks"
    var id: String { rawValue }
    @MainActor func includes(_ item: ProjectWorkspaceItem) -> Bool {
        guard self != .all else { return true }
        guard let capture = item.capture else { return self == .captures }
        switch self {
        case .all: return true
        case .files: return ![CaptureKind.text, .task, .link].contains(capture.kind)
        case .captures: return capture.kind == .text
        case .links: return capture.kind == .link
        case .tasks: return capture.isTask
        }
    }
}

private struct ProjectWorkspaceRow: Identifiable {
    let id: String
    let items: [ProjectWorkspaceItem]
}

private struct ProjectWorkspaceRows {
    let rows: [ProjectWorkspaceRow]
    let rowIDs: [String]
    let groups: [[String]]
}

/// Measurements belong to one Layout instance. Keep only the last exact
/// finite-width proposal and the intrinsic proposal; never retain subview proxies.
struct ProjectWorkspaceMeasurementCache<Key: Equatable> {
    private var key: Key
    private var finiteWidth: CGFloat?
    private var finiteSize: CGSize?
    private var intrinsicSize: CGSize?

    init(key: Key) { self.key = key }

    mutating func measured(width: CGFloat?, key nextKey: Key, _ measure: () -> CGSize) -> CGSize {
        if key != nextKey { self = Self(key: nextKey) }
        if let width, width.isFinite {
            if finiteWidth == width, let finiteSize { return finiteSize }
            let size = measure()
            finiteWidth = width
            finiteSize = size
            return size
        }
        if let intrinsicSize { return intrinsicSize }
        let size = measure()
        intrinsicSize = size
        return size
    }
}

/// Grid columns have equal widths. Propose that final width directly to each
/// card so a native row resize does not negotiate complete card layouts at
/// multiple minimum/maximum widths. The tallest real card determines the row.
private struct ProjectWorkspaceRowLayout: Layout {
    let spacing: CGFloat
    let direction: LayoutDirection

    struct MeasurementKey: Equatable {
        let spacing: CGFloat
        let direction: LayoutDirection
        let count: Int
    }
    typealias Cache = ProjectWorkspaceMeasurementCache<MeasurementKey>

    private func measurementKey(_ subviews: Subviews) -> MeasurementKey {
        MeasurementKey(spacing: spacing, direction: direction, count: subviews.count)
    }

    func makeCache(subviews: Subviews) -> Cache { Cache(key: measurementKey(subviews)) }

    func updateCache(_ cache: inout Cache, subviews: Subviews) {
        // SwiftUI calls this when the layout or its subviews change, including
        // model, text and typography updates even when width/count stay equal.
        cache = makeCache(subviews: subviews)
    }

    private func dimensions(proposedWidth: CGFloat?, subviews: Subviews) -> (width: CGFloat, columnWidth: CGFloat) {
        let gaps = spacing * CGFloat(max(0, subviews.count - 1))
        let width: CGFloat
        if let proposedWidth, proposedWidth.isFinite {
            width = max(gaps, proposedWidth)
        } else {
            let ideal = subviews.map { $0.sizeThatFits(.unspecified).width }.filter(\.isFinite).max() ?? 0
            width = max(0, ideal) * CGFloat(subviews.count) + gaps
        }
        return (width, max(0, width - gaps) / CGFloat(max(1, subviews.count)))
    }

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout Cache) -> CGSize {
        guard !subviews.isEmpty else { return .zero }
        return cache.measured(width: proposal.width, key: measurementKey(subviews)) {
            let dimensions = dimensions(proposedWidth: proposal.width, subviews: subviews)
            let cardProposal = ProposedViewSize(width: dimensions.columnWidth, height: nil)
            let height = subviews.map { $0.sizeThatFits(cardProposal).height }.max() ?? 0
            return CGSize(width: dimensions.width, height: height)
        }
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout Cache) {
        let dimensions = dimensions(proposedWidth: bounds.width, subviews: subviews)
        let cardProposal = ProposedViewSize(width: dimensions.columnWidth, height: nil)
        for index in subviews.indices {
            let offset = CGFloat(index) * (dimensions.columnWidth + spacing)
            // SwiftUI mirrors logical x positions for RTL; do not reverse twice.
            let x = bounds.minX + offset
            subviews[index].place(at: CGPoint(x: x, y: bounds.minY), anchor: .topLeading, proposal: cardProposal)
        }
    }
}

/// Keep sorting/filtering work tied to archive/workspace changes, not every
/// magnification tick. Cached rows retain Capture identities and native List
/// virtualization; thumbnail requests remain independent of layout scale.
@MainActor private final class ProjectWorkspaceContentCache {
    private var subscriptions: [AnyCancellable] = []
    private var key: String?
    private var value: [ProjectWorkspaceItem] = []
    private var visibleKey: String?
    private var visibleValue: [ProjectWorkspaceItem] = []
    private(set) var visibleIDs: [String] = []
    private(set) var visibleCaptures: [Capture] = []
    private(set) var visibleRevision: UInt64 = 0
    private var visibleLookup: [String: ProjectWorkspaceItem] = [:]
    private var selectedIDs: Set<String>?
    private var selectedItems: [ProjectWorkspaceItem] = []
    private var layouts: [Int: ProjectWorkspaceRows] = [:]
    init(store: CaptureStore, workspace: WorkspaceStore) {
        subscriptions = [store.objectWillChange.sink { [weak self] _ in self?.invalidate() },
                         workspace.objectWillChange.sink { [weak self] _ in self?.invalidate() }]
    }
    private func invalidate() { key = nil; visibleKey = nil }
    func items(key: String, build: () -> [ProjectWorkspaceItem]) -> [ProjectWorkspaceItem] {
        if self.key != key { value = build(); self.key = key; visibleKey = nil }
        return value
    }
    func visible(key: String, build: () -> [ProjectWorkspaceItem]) -> [ProjectWorkspaceItem] {
        if visibleKey != key {
            visibleValue = build(); visibleKey = key
            visibleRevision &+= 1
            // UUID string formatting is surprisingly expensive at archive
            // scale. Build identity/lookup storage once, not for every pinch.
            visibleIDs = visibleValue.map(\.id)
            visibleCaptures = visibleValue.compactMap(\.capture)
            visibleLookup = Dictionary(uniqueKeysWithValues: zip(visibleIDs, visibleValue))
            layouts.removeAll(keepingCapacity: true)
            selectedIDs = nil; selectedItems = []
        }
        return visibleValue
    }
    func selected(_ ids: Set<String>) -> [ProjectWorkspaceItem] {
        guard !ids.isEmpty else { return [] }
        if selectedIDs != ids {
            selectedIDs = ids
            selectedItems = visibleIDs.compactMap { ids.contains($0) ? visibleLookup[$0] : nil }
        }
        return selectedItems
    }
    func layout(columns: Int) -> ProjectWorkspaceRows {
        // Workspace column policy permits only these three variants. Bound
        // the cache even if a malformed future caller passes another number.
        let key = min(3, max(1, columns))
        if let cached = layouts[key] { return cached }
        let groups = ProjectWorkspaceOrdering.rows(ids: visibleIDs, columns: key, newestFirst: true)
        let rows = groups.map { group in
            ProjectWorkspaceRow(id: group[0], items: group.compactMap { visibleLookup[$0] })
        }
        let result = ProjectWorkspaceRows(rows: rows, rowIDs: rows.map(\.id), groups: groups)
        layouts[key] = result
        return result
    }
}

/// Actions resolve the latest project snapshot at invocation time. Keeping
/// this holder stable avoids rebuilding native List content just to replace
/// closures during a zoom. Bindings preserve the parent's focus and sheets;
/// the context does not retain the view or this holder through a callback.
@MainActor private final class ProjectWorkspaceBrowserActions {
    @MainActor private struct Context {
        let state: AppState
        let project: String
        let visible: [ProjectWorkspaceItem]
        let visibleIDs: [String]
        let focus: Binding<String?>
        let notePresented: Binding<Bool>
        let undoReceipt: Binding<ProjectTaskConversionReceipt?>
        let pasteboard: NSPasteboard

        var presentation: ProjectNavigationPresentation {
            get { state.projectPresentation[project] ?? ProjectNavigationPresentation() }
            nonmutating set { state.projectPresentation[project] = newValue }
        }
    }

    private var context: Context?
    private var current: Context {
        guard let context else { preconditionFailure("Project browser actions must be configured before use") }
        return context
    }

    func update(state: AppState, project: String, visible: [ProjectWorkspaceItem], visibleIDs: [String],
                focus: Binding<String?>, notePresented: Binding<Bool>,
                undoReceipt: Binding<ProjectTaskConversionReceipt?>, pasteboard: NSPasteboard) {
        context = Context(state: state, project: project, visible: visible, visibleIDs: visibleIDs,
                          focus: focus, notePresented: notePresented, undoReceipt: undoReceipt, pasteboard: pasteboard)
    }

    var copyPasteboard: NSPasteboard { current.pasteboard }

    var hasVisibleItems: Bool { !current.visibleIDs.isEmpty }
    var hasSelectedVisibleItems: Bool {
        let context = current
        let selected = context.presentation.selectedIDs
        return !selected.isEmpty && context.visibleIDs.contains(where: selected.contains)
    }

    func select(_ item: ProjectWorkspaceItem) {
        let context = current
        var presentation = context.presentation
        if NSEvent.modifierFlags.contains(.shift), let anchor = presentation.selectionAnchor,
           let from = context.visibleIDs.firstIndex(of: anchor), let to = context.visibleIDs.firstIndex(of: item.id) {
            presentation.selectedIDs.formUnion(context.visibleIDs[min(from, to)...max(from, to)])
        } else {
            if !presentation.selectedIDs.insert(item.id).inserted { presentation.selectedIDs.remove(item.id) }
            presentation.selectionAnchor = item.id
        }
        context.presentation = presentation
        context.focus.wrappedValue = item.id
    }

    func open(_ item: ProjectWorkspaceItem) {
        if NSEvent.modifierFlags.contains(.command) || NSEvent.modifierFlags.contains(.shift) { select(item); return }
        let context = current
        guard let capture = item.capture else { context.notePresented.wrappedValue = true; return }
        context.state.workspace.selectedCaptureID = capture.id
        if capture.attachmentRelativePath != nil || capture.kind == .link { context.state.openOriginal(capture) }
        else { context.state.openCapture(capture.id) }
    }

    func details(_ item: ProjectWorkspaceItem) {
        let context = current
        if let capture = item.capture { context.state.openCapture(capture.id) }
        else { context.notePresented.wrappedValue = true }
    }

    func makeTasks(_ items: [ProjectWorkspaceItem]) {
        let context = current
        do {
            let receipt = try context.state.convertProjectItemsToTasks(items.compactMap(\.capture))
            context.undoReceipt.wrappedValue = receipt
            let count = receipt.count
            let hasNotes = items.contains { if case .note = $0 { return true }; return false }
            context.state.status = AppStatusMessage(text: (count == 1 ? "1 capture is now a task. Originals are kept." : "\(count) captures are now tasks. Originals are kept.")
                + (hasNotes ? " Live project notes remain notes." : ""), severity: .success)
        } catch { context.state.reportFailure(error.localizedDescription) }
    }

    func drag(_ item: ProjectWorkspaceItem) throws -> [NSPasteboardWriting] {
        let context = current
        let selection = context.presentation.selectedIDs
        let identities = selection.contains(item.id) ? selection : [item.id]
        // Selection and transfer order always come from the current visible
        // project, including after a filter, date or scratchpad change.
        let items = context.visible.filter { identities.contains($0.id) }
        let captures = items.compactMap(\.capture)
        let captureWriters = captures.isEmpty ? [] : try ExplorerTransfer.pasteboardWriters(for: captures, store: context.state.store)
        var iterator = captureWriters.makeIterator()
        return items.map { value in
            switch value {
            case .capture: return iterator.next()!
            case .note(let note): return note.text as NSString
            }
        }
    }

    func selectAll() {
        let context = current
        var presentation = context.presentation
        presentation.selectedIDs = Set(context.visibleIDs)
        presentation.selectionAnchor = context.visibleIDs.first
        context.presentation = presentation
    }

    func resetFilters() {
        let context = current
        var presentation = context.presentation
        presentation.filterRawValue = ProjectWorkspaceFilter.all.rawValue
        presentation.selectedDateRange = nil
        presentation.dateFilter = .anytime
        presentation.selectedIDs.removeAll()
        presentation.selectionAnchor = nil
        context.presentation = presentation
    }

    func recordHistory(_ anchor: NavigationViewportAnchor) { current.presentation.viewport = anchor }
}

/// These are all non-zoom inputs to the browser. The revision changes whenever
/// archive/workspace content is rebuilt, including replacement captures and
/// scratchpad text. Independent Capture observers still deliver live edits.
private struct ProjectWorkspaceBrowserInputs: Equatable {
    let actionsID: ObjectIdentifier
    let stateID: ObjectIdentifier
    let storeID: ObjectIdentifier
    let revision: UInt64
    let project: String
    let filter: String
    let dateFilter: String
    let columns: Int
    let compact: Bool
    let selection: Set<String>
    let selectionAnchor: String?
    let focusedItem: String?
    let historyAnchor: NavigationViewportAnchor?
    let color: Color
    let emptyProject: Bool
    let busy: Bool
    let navigationBlocked: Bool
}

/// Font/preview scaling remains inside ProjectWorkspaceCard. The equality
/// boundary only keeps the row's zoom spacing from replacing card callbacks
/// and focus controls that have otherwise retained the same content/state.
@MainActor private struct ProjectWorkspaceBrowserCard: View, Equatable {
    let item: ProjectWorkspaceItem
    let itemID: String
    let inputs: ProjectWorkspaceBrowserInputs
    let state: AppState
    let actions: ProjectWorkspaceBrowserActions
    let focus: FocusState<String?>.Binding

    nonisolated static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.itemID == rhs.itemID && lhs.inputs == rhs.inputs
    }

    var body: some View {
        ProjectWorkspaceCard(state: state, item: item, selected: inputs.selection.contains(itemID),
            compact: inputs.compact, color: inputs.color, focus: focus,
            open: { actions.open(item) }, select: { actions.select(item) }, details: { actions.details(item) },
            makeTask: { actions.makeTasks([item]) }, drag: { try actions.drag(item) })
    }
}

@MainActor private struct ProjectWorkspaceBrowserRow: View {
    let row: ProjectWorkspaceRow
    let inputs: ProjectWorkspaceBrowserInputs
    let state: AppState
    let actions: ProjectWorkspaceBrowserActions
    @Binding var focus: String?
    @FocusState private var rowFocus: String?

    @Environment(\.workspaceZoom) private var zoom
    @Environment(\.layoutDirection) private var layoutDirection

    var body: some View {
        ProjectWorkspaceRowLayout(spacing: zoom.value(12), direction: layoutDirection) {
            ForEach(row.items) { item in
                ProjectWorkspaceBrowserCard(item: item, itemID: item.id, inputs: inputs,
                    state: state, actions: actions, focus: $rowFocus).equatable().frame(maxWidth: .infinity)
            }
            ForEach(0..<max(0, inputs.columns - row.items.count), id: \.self) { _ in
                Color.clear.frame(maxWidth: .infinity)
            }
        }
        // Each hosting tree owns its native focus registration. Logical focus
        // survives a non-key window or virtualization; only its matching row
        // requests native focus when that row is mounted again.
        .onChange(of: focus, initial: true) { _, desired in
            guard focus == desired else { return }
            if let desired {
                // Another row taking focus is an AppKit transfer. Explicitly
                // clearing this independent host can clear the new responder
                // after the click that transferred it has already completed.
                guard row.items.contains(where: { $0.id == desired }) else { return }
                if rowFocus != desired { rowFocus = desired }
            } else if rowFocus != nil {
                // Observe the global value so a deliberate nil also reaches
                // a retained row whose item was not the previous logical owner.
                rowFocus = nil
            }
        }
        .onChange(of: rowFocus) { _, claimed in
            // An inactive/recycled row losing native focus must not clear the
            // current logical owner. The row-ID scope resets state on reuse.
            guard let claimed, rowFocus == claimed, row.items.contains(where: { $0.id == claimed }),
                  focus != claimed else { return }
            focus = claimed
        }
    }
}

/// Own-process QA refuses Copy unless normal responder lookup exposes its
/// explicitly injected private destination. This never redirects child editors.
@MainActor protocol ProjectWorkspaceCopyDelivery: AnyObject {
    var projectCopyPasteboardName: NSPasteboard.Name { get }
}

/// Read-only completeness receipt for the bounded row-refresh experiment.
/// It reports root assignment, while the caller still performs native layout.
@MainActor protocol ProjectWorkspaceRowRefreshReadiness: AnyObject {
    var hasPendingRowRefresh: Bool { get }
    var lastAppliedZoomFactor: CGFloat? { get }
}

/// A native row is a separate SwiftUI tree. Resolve its anchors locally and
/// reset the local controller when that native host is reused for another row.
/// Forward public presentation settings explicitly. The new hosting tree keeps
/// its own focus/hosting context, and the scope owns its tooltip controller.
@MainActor
struct ProjectWorkspaceRowTooltipScope: ViewModifier {
    let rowID: String
    let environment: EnvironmentValues

    func body(content: Content) -> some View {
        content.hoverTooltips().clipped().id(rowID)
            .environment(\.locale, environment.locale)
            .environment(\.calendar, environment.calendar)
            .environment(\.timeZone, environment.timeZone)
            .environment(\.colorScheme, environment.colorScheme)
            .environment(\.layoutDirection, environment.layoutDirection)
            .environment(\.displayScale, environment.displayScale)
            .environment(\.isEnabled, environment.isEnabled)
            .environment(\.font, environment.font)
            .environment(\.controlSize, environment.controlSize)
            .environment(\.dynamicTypeSize, environment.dynamicTypeSize)
            .environment(\.legibilityWeight, environment.legibilityWeight)
            .environment(\.openURL, environment.openURL)
            .environment(\.workspaceZoom, environment.workspaceZoom)
            .environment(\.daBinAccent, environment.daBinAccent)
            .environment(\.daBinTooltipsEnabled, environment.daBinTooltipsEnabled)
            .environment(\.daBinTutorialTargets, environment.daBinTutorialTargets)
            .tint(environment.daBinAccent)
    }
}

/// An owned native table retains its rows and hosting views while typography
/// changes. It uses only AppKit's automatic heights and ordinary reuse; no
/// offscreen row measurement is involved. Keyboard traversal crosses an owned
/// hosting boundary only after its ordinary in-row key-view chain ends.
@MainActor private struct ProjectWorkspaceNativeTable: NSViewRepresentable {
    let layout: ProjectWorkspaceRows
    let inputs: ProjectWorkspaceBrowserInputs
    let state: AppState
    let actions: ProjectWorkspaceBrowserActions
    let focus: Binding<String?>
    @Environment(\.self) private var environment

    private static let columnID = NSUserInterfaceItemIdentifier("project-native-column")
    private static let cellID = NSUserInterfaceItemIdentifier("project-native-row")

    struct Snapshot {
        let layout: ProjectWorkspaceRows
        let inputs: ProjectWorkspaceBrowserInputs
        let state: AppState
        let actions: ProjectWorkspaceBrowserActions
        let focus: Binding<String?>
        let environment: EnvironmentValues
    }

    private var snapshot: Snapshot {
        Snapshot(layout: layout, inputs: inputs, state: state, actions: actions,
                 focus: focus, environment: environment)
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeNSView(context: Context) -> NSScrollView {
        let scroll = NSScrollView()
        scroll.drawsBackground = false
        scroll.borderType = .noBorder
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.scrollerStyle = .overlay
        scroll.setAccessibilityIdentifier("project-items")

        let table = Table(frame: NSRect(x: 0, y: 0, width: 1, height: 1))
        table.headerView = nil
        table.style = .plain
        table.backgroundColor = .clear
        table.usesAlternatingRowBackgroundColors = false
        table.gridStyleMask = []
        table.intercellSpacing = .zero
        table.selectionHighlightStyle = .none
        table.allowsEmptySelection = true
        table.usesAutomaticRowHeights = true
        table.rowHeight = 200 // Estimate only; each instantiated row supplies its intrinsic height.
        table.columnAutoresizingStyle = .lastColumnOnlyAutoresizingStyle
        table.autoresizingMask = [.width]
        let column = NSTableColumn(identifier: Self.columnID)
        column.minWidth = 0
        column.maxWidth = .greatestFiniteMagnitude
        column.width = 1
        column.resizingMask = [.autoresizingMask]
        table.addTableColumn(column)
        table.dataSource = context.coordinator
        table.delegate = context.coordinator
        scroll.documentView = table
        context.coordinator.update(snapshot, table: table)
        return scroll
    }

    func updateNSView(_ scroll: NSScrollView, context: Context) {
        guard let table = scroll.documentView as? Table else { return }
        context.coordinator.update(snapshot, table: table)
    }

    // A scroll viewport fills its proposed space; its document's intrinsic
    // dimensions do not determine the surrounding project layout.
    func sizeThatFits(_ proposal: ProposedViewSize, nsView: NSScrollView, context: Context) -> CGSize? {
        guard let width = proposal.width, let height = proposal.height,
              width.isFinite, height.isFinite else { return nil }
        return CGSize(width: max(0, width), height: max(0, height))
    }

    static func dismantleNSView(_ scroll: NSScrollView, coordinator: Coordinator) {
        if let table = scroll.documentView as? NSTableView {
            table.delegate = nil
            table.dataSource = nil
        }
        coordinator.stop()
    }

    /// A concrete root type preserves SwiftUI state within the same native
    /// host. A reused host resets card state only when its logical row changes.
    struct HostedRow: View {
        let row: ProjectWorkspaceRow
        let inputs: ProjectWorkspaceBrowserInputs
        let state: AppState
        let actions: ProjectWorkspaceBrowserActions
        let focus: Binding<String?>
        let environment: EnvironmentValues
        let copySelection: () -> Void
        let copyPasteboardName: NSPasteboard.Name
        let moveFocusAcrossBoundary: (Bool) -> Bool

        var body: some View {
            ProjectWorkspaceBrowserRow(row: row, inputs: inputs, state: state, actions: actions, focus: focus)
                .padding(EdgeInsets(top: 5, leading: 16, bottom: 7, trailing: 16))
                .frame(maxWidth: .infinity, alignment: .topLeading)
                .fixedSize(horizontal: false, vertical: true)
                .modifier(ProjectWorkspaceRowTooltipScope(rowID: row.id, environment: environment))
                .transaction { $0.animation = nil; $0.disablesAnimations = true }
        }
    }

    @MainActor final class Table: NSTableView, ProjectWorkspaceRowRefreshReadiness {
        weak var refreshCoordinator: Coordinator?
        var hasPendingRowRefresh: Bool { refreshCoordinator?.rowRefreshPending ?? false }
        var lastAppliedZoomFactor: CGFloat? { refreshCoordinator?.lastAppliedZoomFactor }
    }

    /// Ordinary copy: lookup reaches this host after its focused child. The
    /// outer project command remains for controls outside the row hosting tree.
    @MainActor final class RowHostingView: NSHostingView<HostedRow>, ProjectWorkspaceCopyDelivery, NSMenuItemValidation {
        var projectCopyPasteboardName: NSPasteboard.Name { rootView.copyPasteboardName }
        @objc func copy(_ sender: Any?) {
            guard rootView.environment.isEnabled, rootView.actions.hasSelectedVisibleItems else { return }
            rootView.copySelection()
        }

        override func selectAll(_ sender: Any?) {
            guard rootView.environment.isEnabled, rootView.actions.hasVisibleItems else { return }
            rootView.actions.selectAll()
        }

        func validateMenuItem(_ menuItem: NSMenuItem) -> Bool {
            // AppKit prefers this public menu validator to NSHostingView's
            // SwiftUI-command validator, which does not know these native actions.
            if menuItem.action == #selector(NSText.selectAll(_:)) {
                return rootView.environment.isEnabled && rootView.actions.hasVisibleItems
            }
            if menuItem.action == #selector(NSText.copy(_:)) {
                return rootView.environment.isEnabled && rootView.actions.hasSelectedVisibleItems
            }
            return super.validateUserInterfaceItem(menuItem)
        }

        override func keyDown(with event: NSEvent) {
            let isTab = event.charactersIgnoringModifiers == "\t"
                || event.charactersIgnoringModifiers == "\u{19}"
            if isTab, event.modifierFlags.intersection([.command, .control, .option]).isEmpty,
               rootView.moveFocusAcrossBoundary(event.modifierFlags.contains(.shift)) { return }
            super.keyDown(with: event)
        }

        private var allowsBoundaryCommand: Bool {
            guard let event = NSApp.currentEvent, event.type == .keyDown else { return true }
            return event.modifierFlags.intersection([.command, .control, .option]).isEmpty
        }

        override func insertTab(_ sender: Any?) {
            if !(allowsBoundaryCommand && rootView.moveFocusAcrossBoundary(false)) { super.insertTab(sender) }
        }

        override func insertBacktab(_ sender: Any?) {
            if !(allowsBoundaryCommand && rootView.moveFocusAcrossBoundary(true)) { super.insertBacktab(sender) }
        }
    }

    @MainActor final class Cell: NSTableCellView {
        let hosting: RowHostingView

        init(root: HostedRow) {
            hosting = RowHostingView(rootView: root)
            super.init(frame: .zero)
            identifier = ProjectWorkspaceNativeTable.cellID
            hosting.sizingOptions = [.intrinsicContentSize]
            hosting.translatesAutoresizingMaskIntoConstraints = false
            hosting.setContentHuggingPriority(.defaultLow, for: .horizontal)
            hosting.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
            hosting.setContentHuggingPriority(.defaultHigh, for: .vertical)
            hosting.setContentCompressionResistancePriority(.required, for: .vertical)
            addSubview(hosting)
            // AppKit owns the cell width. The host receives that exact width;
            // its intrinsic height closes the automatic-row-height constraint chain.
            NSLayoutConstraint.activate([
                hosting.leadingAnchor.constraint(equalTo: leadingAnchor),
                hosting.widthAnchor.constraint(equalTo: widthAnchor),
                hosting.topAnchor.constraint(equalTo: topAnchor),
                hosting.bottomAnchor.constraint(equalTo: bottomAnchor)
            ])
        }

        required init?(coder: NSCoder) { fatalError("Use init(root:)") }

        func update(_ root: HostedRow) { hosting.rootView = root }
    }

    @MainActor final class Coordinator: NSObject, NSTableViewDataSource, NSTableViewDelegate {
        private var current: Snapshot?
        private weak var attachedTable: Table?
        private var generation: UInt64 = 0
        private var lifecycle: UInt64 = 0
        private var drainQueued = false
        private(set) var rowRefreshPending = false
        private(set) var lastAppliedZoomFactor: CGFloat?

        fileprivate func update(_ next: Snapshot, table: Table) {
            if attachedTable !== table {
                stop()
                attachedTable = table
                table.refreshCoordinator = self
            }
            // Every update invalidates an in-flight older snapshot. A queued
            // callback owns no snapshot or row; it reads only the latest one.
            generation &+= 1
            let updateGeneration = generation
            let previous = current
            current = next
            guard let previous else {
                // Only the initial table population uses reloadData. Arrivals
                // below preserve existing native row objects for the viewport anchor.
                table.reloadData()
                if generation == updateGeneration {
                    lastAppliedZoomFactor = next.environment.workspaceZoom.factor
                }
                return
            }
            let nextZoom = next.environment.workspaceZoom
            if nextZoom.isInteracting, previous.inputs == next.inputs,
               sameControlEnvironment(previous.environment, next.environment),
               previous.environment.workspaceZoom.factor != nextZoom.factor || rowRefreshPending {
                rowRefreshPending = true
                scheduleRetainedRefresh(table)
                return
            }
            // Content, identity, selection, focus, disabled state and gesture
            // completion stay synchronous and cancel a pending zoom snapshot.
            // An already queued empty callback remains the single queue slot.
            rowRefreshPending = false
            // Zoom/environment/selection changes do not compare thousands of
            // row IDs. The content cache revision also covers filter changes.
            let structureMayChange = previous.inputs.revision != next.inputs.revision
                || previous.inputs.columns != next.inputs.columns
                || previous.inputs.project != next.inputs.project
                || previous.inputs.stateID != next.inputs.stateID
                || previous.inputs.storeID != next.inputs.storeID
            if structureMayChange, previous.layout.rowIDs != next.layout.rowIDs {
                let changes = next.layout.rowIDs.difference(from: previous.layout.rowIDs)
                var removed = IndexSet(), inserted = IndexSet()
                for change in changes {
                    switch change {
                    case .remove(let offset, _, _): removed.insert(offset)
                    case .insert(let offset, _, _): inserted.insert(offset)
                    }
                }
                NSAnimationContext.runAnimationGroup { animation in
                    animation.duration = 0
                    animation.allowsImplicitAnimation = false
                    table.beginUpdates()
                    if !removed.isEmpty { table.removeRows(at: removed, withAnimation: []) }
                    if !inserted.isEmpty { table.insertRows(at: inserted, withAnimation: []) }
                    table.endUpdates()
                }
            }
            refreshRetainedRows(next, table: table, generation: updateGeneration)
            if generation == updateGeneration {
                lastAppliedZoomFactor = next.environment.workspaceZoom.factor
            }
        }

        private func sameControlEnvironment(_ lhs: EnvironmentValues, _ rhs: EnvironmentValues) -> Bool {
            lhs.isEnabled == rhs.isEnabled && lhs.colorScheme == rhs.colorScheme
                && lhs.layoutDirection == rhs.layoutDirection && lhs.daBinAccent == rhs.daBinAccent
                && lhs.daBinTooltipsEnabled == rhs.daBinTooltipsEnabled
                && lhs.hoverTooltipActiveID == rhs.hoverTooltipActiveID
                && lhs.timelineTooltipController === rhs.timelineTooltipController
                && lhs.daBinTutorialTargets == rhs.daBinTutorialTargets
                && lhs.workspaceZoom.gestureLogicalWidth == rhs.workspaceZoom.gestureLogicalWidth
        }

        private func scheduleRetainedRefresh(_ table: Table) {
            guard !drainQueued else { return }
            drainQueued = true
            let scheduledLifecycle = lifecycle
            DispatchQueue.main.async { [weak self, weak table] in
                guard let self, let table, self.lifecycle == scheduledLifecycle,
                      self.attachedTable === table else { return }
                self.drainQueued = false
                guard self.rowRefreshPending, let latest = self.current else { return }
                let refreshGeneration = self.generation
                self.refreshRetainedRows(latest, table: table, generation: refreshGeneration)
                guard self.generation == refreshGeneration else {
                    // A reentrant newer zoom update owns the next bounded drain;
                    // a synchronous update already cleared the pending receipt.
                    if self.rowRefreshPending { self.scheduleRetainedRefresh(table) }
                    return
                }
                self.lastAppliedZoomFactor = latest.environment.workspaceZoom.factor
                self.rowRefreshPending = false
            }
        }

        private func refreshRetainedRows(_ snapshot: Snapshot, table: Table, generation: UInt64) {
            // Enumerate at application time: insertions/reuse may have changed
            // every old row index. Never create or measure offscreen row views.
            table.enumerateAvailableRowViews { rowView, index in
                guard self.generation == generation, self.attachedTable === table,
                      snapshot.layout.rows.indices.contains(index),
                      let cell = rowView.view(atColumn: 0) as? Cell else { return }
                cell.update(self.root(snapshot, index: index))
            }
        }

        func numberOfRows(in tableView: NSTableView) -> Int { current?.layout.rows.count ?? 0 }

        func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
            guard let current, current.layout.rows.indices.contains(row) else { return nil }
            let root = root(current, index: row)
            if let cell = tableView.makeView(withIdentifier: ProjectWorkspaceNativeTable.cellID, owner: self) as? Cell {
                cell.update(root)
                return cell
            }
            return Cell(root: root)
        }

        private func root(_ snapshot: Snapshot, index: Int) -> HostedRow {
            let rowID = snapshot.layout.rows[index].id
            return HostedRow(row: snapshot.layout.rows[index], inputs: snapshot.inputs, state: snapshot.state,
                      actions: snapshot.actions, focus: snapshot.focus, environment: snapshot.environment,
                      copySelection: { [weak self] in self?.copyItems() },
                      copyPasteboardName: snapshot.actions.copyPasteboard.name,
                      moveFocusAcrossBoundary: { [weak self] backwards in
                          self?.moveFocusAcrossBoundary(from: rowID,
                                                        backwards: backwards) ?? false
                      })
        }

        /// SwiftUI owns the key views inside each row. AppKit's view-table loop
        /// does not join every independent hosting tree, so continue at that
        /// boundary without rewriting framework-owned links or native selection.
        private func moveFocusAcrossBoundary(from rowID: String, backwards: Bool) -> Bool {
            guard let current, let table = attachedTable, let window = table.window,
                  window.isKeyWindow, current.environment.isEnabled,
                  let origin = window.firstResponder as? NSView,
                  !(origin is NSTextView) else { return false }
            let index = table.row(for: origin)
            guard current.layout.rows.indices.contains(index),
                  current.layout.rows[index].id == rowID,
                  let cell = table.view(atColumn: 0, row: index, makeIfNecessary: false) as? Cell,
                  origin !== cell.hosting, origin.isDescendant(of: cell.hosting) else {
                // A clicked SwiftUI control initially makes the host first
                // responder. Let SwiftUI enter its own registered key view first.
                return false
            }
            let withinRow = backwards ? origin.previousValidKeyView : origin.nextValidKeyView
            if let withinRow, withinRow !== origin, withinRow.isDescendant(of: cell.hosting) {
                return false
            }
            let adjacent = index + (backwards ? -1 : 1)
            guard current.layout.rows.indices.contains(adjacent) else {
                // At a real model edge, continue through the window's existing
                // outer chain. Never wrap to another control in this row.
                var candidate = backwards ? origin.previousKeyView : origin.nextKeyView
                var visited: Set<ObjectIdentifier> = [ObjectIdentifier(origin)]
                while let view = candidate, visited.insert(ObjectIdentifier(view)).inserted {
                    if view !== table, !view.isDescendant(of: table), view.canBecomeKeyView {
                        return window.makeFirstResponder(view)
                    }
                    candidate = backwards ? view.previousKeyView : view.nextKeyView
                }
                return false
            }
            let navigationGeneration = generation
            let adjacentID = current.layout.rows[adjacent].id
            let oldOffset = table.enclosingScrollView?.contentView.bounds.origin
            table.scrollRowToVisible(adjacent)
            table.layoutSubtreeIfNeeded()
            // Materialize at most this one adjacent row, after scrolling it into
            // view. No full-table traversal or offscreen height measurement.
            guard attachedTable === table, generation == navigationGeneration,
                  window.firstResponder === origin else { return false }
            guard let nextCell = table.view(atColumn: 0, row: adjacent, makeIfNecessary: true) as? Cell,
                  nextCell.hosting.rootView.row.id == adjacentID else {
                restoreScroll(oldOffset, table: table)
                return false
            }
            nextCell.hosting.layoutSubtreeIfNeeded()
            var candidate = nextCell.hosting.nextKeyView
            var entry: NSView?
            var visited = Set<ObjectIdentifier>()
            while let view = candidate, view.isDescendant(of: nextCell.hosting),
                  visited.insert(ObjectIdentifier(view)).inserted {
                if view.canBecomeKeyView {
                    entry = view
                    if !backwards { break }
                }
                candidate = view.nextKeyView
            }
            guard attachedTable === table, generation == navigationGeneration,
                  window.firstResponder === origin,
                  nextCell.hosting.rootView.row.id == adjacentID else { return false }
            guard let entry, window.makeFirstResponder(entry) else {
                restoreScroll(oldOffset, table: table)
                return false
            }
            return true
        }

        private func restoreScroll(_ point: NSPoint?, table: Table) {
            guard let point, let scroll = table.enclosingScrollView else { return }
            scroll.contentView.scroll(to: point)
            scroll.reflectScrolledClipView(scroll.contentView)
        }

        private func copyItems() {
            guard let current else { return }
            let selected = current.state.projectPresentation[current.inputs.project]?.selectedIDs ?? []
            let items = current.layout.rows.flatMap(\.items).filter { selected.contains($0.id) }
            guard !items.isEmpty else { return }
            do {
                let note = items.compactMap { item -> String? in
                    if case .note(let note) = item { return note.text }; return nil
                }.first
                try ProjectWorkspaceExport.copyItems(captures: items.compactMap(\.capture), store: current.state.store,
                    notes: note, orderedItemIDs: items.map(\.id), pasteboard: current.actions.copyPasteboard)
            } catch { current.state.reportFailure(error.localizedDescription) }
        }

        func stop() {
            generation &+= 1
            lifecycle &+= 1
            rowRefreshPending = false
            drainQueued = false
            lastAppliedZoomFactor = nil
            current = nil
            attachedTable?.refreshCoordinator = nil
            attachedTable = nil
        }
    }
}

/// The native table and both existing viewport bridges share the same browser
/// bounds. Empty content stays in SwiftUI and never becomes a synthetic data row.
@MainActor private struct ProjectWorkspaceBrowser: View, Equatable {
    let layout: ProjectWorkspaceRows
    let inputs: ProjectWorkspaceBrowserInputs
    let state: AppState
    let store: CaptureStore
    let actions: ProjectWorkspaceBrowserActions
    let focus: Binding<String?>

    nonisolated static func == (lhs: Self, rhs: Self) -> Bool { lhs.inputs == rhs.inputs }

    var body: some View {
        Group {
            if layout.rows.isEmpty {
                VStack(spacing: 8) {
                    EmptyMessage(symbol: "folder", title: inputs.emptyProject ? "Make room for your next idea" : "No matching items",
                        message: inputs.emptyProject ? "Drop a file or paste something into this project. Your notes, links and tasks will live here too." : "Try another filter or show the complete project.")
                    if !inputs.emptyProject {
                        Button("Show all items") { actions.resetFilters() }
                            .frame(minHeight: 32).accessibilityIdentifier("project-reset-filters")
                    }
                }.padding(EdgeInsets(top: 5, leading: 16, bottom: 7, trailing: 16))
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            } else {
                ProjectWorkspaceNativeTable(layout: layout, inputs: inputs, state: state, actions: actions, focus: focus)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
            .transaction { $0.animation = nil; $0.disablesAnimations = true }
            .background {
                ExplorerViewport(store: store, rowIDs: layout.rowIDs,
                    context: ExplorerViewportContext(project: inputs.project, unfiledOnly: false, dailyFiles: false,
                        query: "", filter: inputs.filter, pinnedOnly: false, dateFilter: inputs.dateFilter,
                        source: nil, origin: "all", grouping: "project-\(inputs.columns)-\(inputs.compact)-newest", selectedID: nil), handlesZoom: false)
                    .allowsHitTesting(false).accessibilityHidden(true)
            }
            .background {
                WorkspaceZoomViewport(groups: layout.groups, historyAnchor: inputs.historyAnchor,
                    onHistoryAnchor: { actions.recordHistory($0) })
                    .allowsHitTesting(false).accessibilityHidden(true)
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("project-items")
    }
}

/// Keep scale and gesture column locking inside the browser viewport. The
/// project toolbar, selection actions and copy command retain their independent
/// state dependencies while rows continue observing the live zoom environment.
@MainActor private struct ProjectWorkspaceColumnViewport<Content: View>: View {
    let compact: Bool
    private let content: (Int) -> Content
    @Environment(\.workspaceZoom) private var zoom
    @State private var gestureColumns: Int?
    @State private var settledColumns = 1

    init(compact: Bool, @ViewBuilder content: @escaping (Int) -> Content) {
        self.compact = compact
        self.content = content
    }

    var body: some View {
        GeometryReader { geometry in
            let proposedColumns = WorkspaceZoomLayout(factor: zoom.factor).columns(for: geometry.size.width, compact: compact)
            let columns = compact ? 1 : zoom.isInteracting ? (gestureColumns ?? settledColumns) : proposedColumns
            content(columns)
                .onAppear { settledColumns = proposedColumns }
                .onChange(of: proposedColumns) { _, value in if !zoom.isInteracting { settledColumns = value } }
                .onChange(of: zoom.isInteracting) { _, active in
                    gestureColumns = active ? settledColumns : nil
                    if !active { settledColumns = proposedColumns }
                }
        }
    }
}

@MainActor struct ProjectWorkspaceView: View {
    @ObservedObject var state: AppState
    @ObservedObject private var workspace: WorkspaceStore
    @ObservedObject private var store: CaptureStore
    @ObservedObject private var intake: ExplorerCaptureController
    let project: String
    let showsSearchEntry: Bool
    private let chooseExportDestination: @MainActor (ProjectWorkspaceExportDocument) -> URL?
    private let pasteboard: NSPasteboard
    private var presentation: ProjectNavigationPresentation {
        get { state.projectPresentation[project] ?? ProjectNavigationPresentation() }
        nonmutating set { state.projectPresentation[project] = newValue }
    }
    private var filter: ProjectWorkspaceFilter {
        get { ProjectWorkspaceFilter(rawValue: presentation.filterRawValue) ?? .all }
        nonmutating set { presentation.filterRawValue = newValue.rawValue }
    }
    private var dateFilter: WorkspaceDateFilter { presentation.dateFilter }
    private var dateFilterTitle: String { presentation.selectedDateRange?.displayTitle ?? dateFilter.title }
    private var dateFilterKey: String { presentation.selectedDateRange?.cacheKey ?? dateFilter.rawValue }
    private var hasDateFilter: Bool { presentation.selectedDateRange != nil || dateFilter != .anytime }
    private var compact: Bool {
        get { presentation.compact }
        nonmutating set { presentation.compact = newValue }
    }
    private var selection: Set<String> {
        get { presentation.selectedIDs }
        nonmutating set { presentation.selectedIDs = newValue }
    }
    private var selectionAnchor: String? {
        get { presentation.selectionAnchor }
        nonmutating set { presentation.selectionAnchor = newValue }
    }
    /// Bulk caption actions share the project's existing selection rather than
    /// introducing another card control or changing drag/keyboard selection.
    /// Live project notes keep their own selection and are never caption targets.
    private var selectedCaptionIDs: Binding<Set<UUID>> {
        Binding(get: {
            Set(selection.compactMap { id in
                guard id.hasPrefix("capture:") else { return nil }
                return UUID(uuidString: String(id.dropFirst("capture:".count)))
            })
        }, set: { ids in
            let current = presentation
            var next = current
            let otherItems = next.selectedIDs.filter { !$0.hasPrefix("capture:") }
            next.selectedIDs = otherItems.union(ids.map(ProjectWorkspaceIdentity.capture))
            if let anchor = next.selectionAnchor, !next.selectedIDs.contains(anchor) {
                next.selectionAnchor = nil
            }
            guard next != current else { return }
            presentation = next
        })
    }
    @State private var contentCache: ProjectWorkspaceContentCache
    @State private var browserActions = ProjectWorkspaceBrowserActions()
    @State private var targeted = false
    @State private var exporting = false
    @State private var notePresented = false
    @State private var datePickerPresented = false
    @State private var undoReceipt: ProjectTaskConversionReceipt?
    @State private var focusedItem: String?
    @State private var iconHover: Set<String> = []

    init(state: AppState, project: String, showsSearchEntry: Bool = true, pasteboard: NSPasteboard = .general,
         chooseExportDestination: @escaping @MainActor (ProjectWorkspaceExportDocument) -> URL? = { document in
             let panel = NSSavePanel()
             panel.allowedContentTypes = [.zip]
             panel.nameFieldStringValue = document.suggestedFilename
             panel.title = document.scope == .project ? "Export project" : "Export selected items"
             panel.prompt = "Save ZIP"
             let count = document.itemCount
             panel.message = "\(document.scope.title) · \(count) \(count == 1 ? "item" : "items") from \(document.project ?? "DaBin").\nIncludes original files, text, links, notes and task details."
             return panel.runModal() == .OK ? panel.url : nil
         }) {
        self.state = state; self.project = project; self.showsSearchEntry = showsSearchEntry
        _contentCache = State(initialValue: ProjectWorkspaceContentCache(store: state.store, workspace: state.workspace))
        self.chooseExportDestination = chooseExportDestination
        self.pasteboard = pasteboard
        _workspace = ObservedObject(wrappedValue: state.workspace)
        _store = ObservedObject(wrappedValue: state.store)
        _intake = ObservedObject(wrappedValue: state.explorerInput)
    }

    private var color: Color {
        ProjectColorChoice.color(for: workspace.projectColorHex(for: project) ?? WorkspaceStore.defaultProjectColorHex)
    }
    private var busy: Bool { exporting || intake.isBusy || state.isArchiveOperationRunning }
    private var allItems: [ProjectWorkspaceItem] {
        contentCache.items(key: project) { buildAllItems() }
    }
    private func buildAllItems() -> [ProjectWorkspaceItem] {
        var items = ProjectWorkspaceContents.captures(in: project, from: store.captures).map(ProjectWorkspaceItem.capture)
        let text = workspace.scratchpad(project: project)
        if !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let saved = workspace.snapshot.scratchpads[WorkspaceSnapshot.projectKey(project)]
            items.append(.note(WorkspaceScratchpad(text: text, projectName: project, updatedAt: saved?.updatedAt ?? Date())))
        }
        items.sort { $0.date == $1.date ? $0.id < $1.id : $0.date > $1.date }
        return items
    }
    private func visibleItems(_ all: [ProjectWorkspaceItem]) -> [ProjectWorkspaceItem] {
        contentCache.visible(key: "\(filter.rawValue)-\(dateFilterKey)") {
            all.filter { item in
                let day = item.capture?.captureDay ?? CaptureCalendar.dayString(item.date)
                let included = presentation.selectedDateRange?.includes(day: day) ?? dateFilter.includes(day)
                return filter.includes(item) && included
            }
        }
    }

    var body: some View {
        let all = allItems
        let visible = visibleItems(all)
        let selected = contentCache.selected(selection)
        let visibleIDs = contentCache.visibleIDs
        browserActions.update(state: state, project: project, visible: visible, visibleIDs: visibleIDs,
                              focus: $focusedItem, notePresented: $notePresented, undoReceipt: $undoReceipt, pasteboard: pasteboard)
        return VStack(spacing: 0) {
            header(all: all, selected: selected)
            CaptionSelectionScope(state: state, captures: contentCache.visibleCaptures,
                contextID: "project-\(WorkspaceSnapshot.projectKey(project))-\(filter.rawValue)-\(dateFilterKey)",
                selectedIDs: selectedCaptionIDs, isBusy: busy) {
                VStack(spacing: 0) {
                    selectionBar(all: all, visible: visible, selected: selected)
                    ProjectWorkspaceColumnViewport(compact: compact) { columns in
                        let layout = contentCache.layout(columns: columns)
                        browser(layout: layout, columns: columns, emptyProject: all.isEmpty)
                    }
                    HStack(spacing: 6) {
                        DaBinIcon(systemName: "lock").accessibilityHidden(true)
                        Text(intake.isBusy ? "Saving into \(project)…" : "Saved on this Mac")
                        Spacer(minLength: 0)
                        if intake.canUndoMove {
                            Button("Undo move") { intake.undoLastMove() }
                                .frame(minHeight: 32).disabled(busy)
                                .accessibilityLabel("Undo project move").accessibilityIdentifier("project-undo-move")
                        }
                        if let receipt = undoReceipt, state.canUndoProjectTaskConversion(receipt) {
                            Button("Undo tasks") { undoTasks() }.frame(minHeight: 32).disabled(busy)
                                .accessibilityLabel("Undo task conversion").accessibilityIdentifier("project-undo-tasks")
                        }
                    }.font(.system(size: 11)).foregroundStyle(Palette.muted).padding(.horizontal, 18).padding(.vertical, 8)
                }
            }
        }
        .background(Palette.background)
        .overlay { if targeted { RoundedRectangle(cornerRadius: 12).strokeBorder(color, lineWidth: 2).allowsHitTesting(false) } }
        .onDrop(of: ExplorerTransfer.acceptedTypeIdentifiers, isTargeted: $targeted) { intake.receive($0, project: project) }
        .onChange(of: visibleIDs) { _, ids in
            let visible = Set(ids)
            selection.formIntersection(visible)
            if let anchor = selectionAnchor, !visible.contains(anchor) { selectionAnchor = nil }
        }
        .onAppear { focusedItem = presentation.focusedID }
        .onChange(of: focusedItem) { _, value in presentation.focusedID = value }
        .onChange(of: presentation.focusedID) { _, value in if focusedItem != value { focusedItem = value } }
        .onCopyCommand {
            do { return try visible.filter { selection.contains($0.id) }.map { item in
                switch item {
                case .capture(let capture): return try ExplorerTransfer.itemProvider(for: capture, store: store, includeInternalReference: false)
                case .note(let note): return NSItemProvider(object: note.text as NSString)
                }
            } } catch { state.reportFailure(error.localizedDescription); return [] }
        }
        .sheet(isPresented: $notePresented) {
            VStack(spacing: 8) {
                HStack { Text("Project notes").font(.headline); Spacer(); Button("Done") { notePresented = false }.keyboardShortcut(.cancelAction).accessibilityIdentifier("project-notes-done") }.padding()
                ScratchpadView(state: state, workspace: workspace,
                    noteContext: WorkspaceScratchpad(text: workspace.scratchpad(project: project), projectName: project, updatedAt: Date()))
            }.frame(minWidth: 400, idealWidth: 560, minHeight: 450, idealHeight: 620)
                .environment(\.workspaceZoom, WorkspaceZoomLayout())
        }
        .accessibilityElement(children: .contain).accessibilityLabel("Project workspace")
        .accessibilityIdentifier("project-workspace")
    }

    private func header(all: [ProjectWorkspaceItem], selected: [ProjectWorkspaceItem]) -> some View {
        HStack(spacing: 6) {
            headerActions(selected: selected)
            projectActions(all: all, selected: selected)
        }.font(.system(size: 12)).controlSize(.regular)
            .padding(.horizontal, 14).padding(.vertical, 8)
            .accessibilityElement(children: .contain).accessibilityIdentifier("project-toolbar")
    }

    private func projectActions(all: [ProjectWorkspaceItem], selected: [ProjectWorkspaceItem]) -> some View {
        let items = selected.isEmpty ? all : selected
        let scope: ProjectWorkspaceExportScope = selected.isEmpty ? .project : .selection
        let copyTitle = selected.isEmpty ? "Copy project items" : "Copy selected items"
        let summaryTitle = selected.isEmpty ? "Copy project summary" : "Copy selection summary"
        return Menu {
            Button("Add files…", daBinSystemImage: "folder.badge.plus") { intake.chooseFiles(project: project) }
            Button("Paste into project", daBinSystemImage: "doc.on.clipboard") { intake.paste(project: project, from: pasteboard) }
            Button("Project notes", daBinSystemImage: "note.text") { notePresented = true }
            Button("Open folder", daBinSystemImage: "folder") { state.showProjectFiles() }
            Divider()
            Button(copyTitle, daBinSystemImage: "doc.on.doc") { copy(items, summary: false, scope: scope) }
                .disabled(items.isEmpty)
            Button(summaryTitle, daBinSystemImage: "text.alignleft") { copy(items, summary: true, scope: scope) }
                .disabled(items.isEmpty)
            Divider()
            Button("Clipboard view") { state.navigateWorkspaceMode(.clipboard) }.disabled(state.isNavigationBlocked)
            Button("Shelf view") { state.navigateWorkspaceMode(.shelf) }.disabled(state.isNavigationBlocked)
        } label: { DaBinIcon(systemName: "ellipsis").daBinInterfaceGlyphMotion(baseSize: 14, hovered: iconHover.contains("actions"))
            .foregroundStyle(Palette.muted).frame(width: 32, height: 32).contentShape(Rectangle()) }
            .menuStyle(.button).buttonStyle(.plain).menuIndicator(.hidden).fixedSize().accessibilityLabel("Project actions")
            .onHover { if $0 { iconHover.insert("actions") } else { iconHover.remove("actions") } }
            .accessibilityIdentifier("project-actions")
            .disabled(busy)
    }

    private func headerActions(selected: [ProjectWorkspaceItem]) -> some View {
        let canExport = !selected.isEmpty && !busy
        return HStack(spacing: 6) {
            if showsSearchEntry {
                Button { state.performSearchCommand() } label: {
                    DaBinIcon(name: .search, baseSize: 14, tint: Palette.muted, hovered: iconHover.contains("search"))
                        .frame(width: 14, height: 14).frame(width: 32, height: 32).contentShape(Rectangle())
                }.buttonStyle(.plain).foregroundStyle(Palette.muted).accessibilityLabel("Search everything saved in DaBin")
                    .onHover { if $0 { iconHover.insert("search") } else { iconHover.remove("search") } }
                    .accessibilityIdentifier("project-search").buddyHelp("Search across DaBin; refine by project in Filters")
            }
            filterMenu
            viewOptions
            Spacer(minLength: 0)
            Button { exportSelected(selected) } label: {
                Label(exporting ? "Exporting…" : "Export Selected", daBinSystemImage: "arrow.down.to.line", iconSize: 11)
                    .font(.system(size: 11, weight: .medium)).fixedSize()
                    .padding(.horizontal, 9).frame(height: 28)
                    .foregroundStyle(canExport ? color : Palette.muted)
                    .background(color.opacity(canExport ? 0.12 : 0.05), in: RoundedRectangle(cornerRadius: 7))
                    .overlay(RoundedRectangle(cornerRadius: 7).stroke(color.opacity(canExport ? 0.24 : 0.1), lineWidth: 1))
                    .contentShape(Rectangle())
            }.buttonStyle(.plain).disabled(!canExport)
                .accessibilityLabel("Export Selected").accessibilityIdentifier("project-export")
                .buddyHelp(selected.isEmpty ? "Select items to export a ZIP" : "Save \(selected.count) selected \(selected.count == 1 ? "item" : "items") as a ZIP with original files, notes and task details")
        }
    }

    private var filterMenu: some View {
        Menu {
            ForEach(ProjectWorkspaceFilter.allCases) { value in
                Button { selectFilter(value) } label: {
                    Label(value.rawValue, daBinSystemImage: filter == value ? "checkmark" : "line.3.horizontal.decrease")
                }.accessibilityIdentifier("project-filter-\(value.id)")
            }
        } label: {
            DaBinIcon(systemName: "line.3.horizontal.decrease").frame(width: 32, height: 32)
                .background(filter == .all ? Color.clear : color.opacity(0.13), in: RoundedRectangle(cornerRadius: 7))
                .contentShape(Rectangle())
        }.menuStyle(.borderlessButton).menuIndicator(.hidden).fixedSize()
            .foregroundStyle(filter == .all ? Palette.muted : color)
            .accessibilityLabel("Project item type: \(filter.rawValue)")
            .accessibilityIdentifier("project-filter-menu").buddyHelp("Filter items: \(filter.rawValue)")
    }

    private var viewOptions: some View {
        HStack(spacing: 6) {
            Button { datePickerPresented.toggle() } label: {
                DaBinIcon(name: .calendar, baseSize: 14, tint: hasDateFilter ? color : Palette.muted,
                          hovered: iconHover.contains("date"))
                    .frame(width: 14, height: 14).frame(width: 32, height: 32)
                    .background(hasDateFilter ? color.opacity(0.13) : Color.clear, in: RoundedRectangle(cornerRadius: 7))
                    .contentShape(Rectangle())
            }.buttonStyle(.plain).fixedSize()
                .foregroundStyle(hasDateFilter ? color : Palette.muted)
                .accessibilityLabel("Project date: \(presentation.selectedDateRange?.accessibilityLabel ?? dateFilter.title)")
                .onHover { if $0 { iconHover.insert("date") } else { iconHover.remove("date") } }
                .accessibilityIdentifier("project-date-filter").buddyHelp("Date: \(dateFilterTitle)")
                .popover(isPresented: $datePickerPresented, arrowEdge: .bottom) {
                    ProjectDatePicker(selection: presentation.selectedDateRange, dateFilter: dateFilter,
                        activityDays: Set(allItems.map { $0.capture?.captureDay ?? CaptureCalendar.dayString($0.date) }),
                        onSelect: selectDate, onClear: clearDate,
                        dismiss: { datePickerPresented = false })
                        .environment(\.daBinAccent, color)
                        .hoverTooltips()
                }
            Button { compact.toggle() } label: {
                DaBinIcon(systemName: compact ? "square.grid.2x2" : "list.bullet")
                    .frame(width: 32, height: 32).contentShape(Rectangle())
            }.buttonStyle(.plain).accessibilityLabel(compact ? "Show preview grid" : "Show compact list")
                .accessibilityIdentifier("project-view-toggle").buddyHelp(compact ? "Show preview grid" : "Show compact list")
        }.font(.system(size: 12)).foregroundStyle(Palette.muted).fixedSize()
    }

    private func selectDate(_ range: ProjectDateSelection) {
        var next = presentation
        next.selectedDateRange = range
        next.dateFilter = .anytime
        next.selectedIDs.removeAll()
        next.selectionAnchor = nil
        presentation = next
    }

    private func clearDate() {
        var next = presentation
        next.selectedDateRange = nil
        next.dateFilter = .anytime
        next.selectedIDs.removeAll()
        next.selectionAnchor = nil
        presentation = next
    }

    private func selectionBar(all: [ProjectWorkspaceItem], visible: [ProjectWorkspaceItem], selected: [ProjectWorkspaceItem]) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) { selectionLabel(visible: visible, allCount: all.count); Spacer(minLength: 4); selectionActions(selected, visible: visible) }
            VStack(alignment: .leading, spacing: 6) {
                HStack { selectionLabel(visible: visible, allCount: all.count); Spacer(minLength: 0) }
                ViewThatFits(in: .horizontal) {
                    HStack(spacing: 8) { selectionActions(selected, visible: visible); Spacer(minLength: 0) }
                    HStack(spacing: 8) { selectionActions(selected, visible: visible); Spacer(minLength: 0) }.labelStyle(.iconOnly)
                }
            }
        }.font(.system(size: 12)).frame(minHeight: 38)
            .padding(.horizontal, 18).padding(.bottom, 8)
    }

    private func selectionLabel(visible: [ProjectWorkspaceItem], allCount: Int) -> some View {
        HStack(spacing: 6) {
            Text(selection.isEmpty ? (visible.count == allCount ? "\(allCount) items" : "\(visible.count) of \(allCount) items") : "\(selection.count) selected")
                .foregroundStyle(selection.isEmpty ? Palette.muted : Palette.foreground)
                .accessibilityIdentifier("project-selection-count")
            if !selection.isEmpty {
                Button { selection.removeAll(); selectionAnchor = nil } label: { DaBinIcon(systemName: "xmark.circle.fill")
                    .daBinInterfaceGlyphMotion(baseSize: 12, hovered: iconHover.contains("clear-selection"))
                    .frame(width: 32, height: 32) }
                    .buttonStyle(.plain).foregroundStyle(Palette.muted).accessibilityLabel("Clear selection")
                    .onHover { if $0 { iconHover.insert("clear-selection") } else { iconHover.remove("clear-selection") } }
                    .accessibilityIdentifier("project-clear-selection")
            }
        }
    }

    @ViewBuilder private func selectionActions(_ selected: [ProjectWorkspaceItem], visible: [ProjectWorkspaceItem]) -> some View {
        if selected.isEmpty {
            Button("Select all") { selection = Set(visible.map(\.id)); selectionAnchor = visible.first?.id }
                .buttonStyle(.plain).foregroundStyle(color).disabled(visible.isEmpty)
                .accessibilityIdentifier("project-select-all")
        } else {
            Button(selected.lazy.filter { $0.capture?.isTask == false }.count == 1 ? "Make task" : "Make tasks", daBinSystemImage: "checkmark.circle") { makeTasks(selected) }
                .disabled(busy || !selected.contains { $0.capture?.isTask == false })
                .buddyHelp("Keeps each capture and file. Edit live project notes before saving them as a task.")
                .accessibilityIdentifier("project-make-tasks")

        }
    }

    private func browser(layout: ProjectWorkspaceRows, columns: Int, emptyProject: Bool) -> some View {
        let inputs = ProjectWorkspaceBrowserInputs(actionsID: ObjectIdentifier(browserActions),
            stateID: ObjectIdentifier(state), storeID: ObjectIdentifier(store), revision: contentCache.visibleRevision,
            project: project, filter: filter.rawValue, dateFilter: dateFilterKey, columns: columns, compact: compact,
            selection: selection, selectionAnchor: selectionAnchor, focusedItem: focusedItem,
            historyAnchor: presentation.viewport, color: color, emptyProject: emptyProject,
            busy: busy, navigationBlocked: state.isNavigationBlocked)
        return ProjectWorkspaceBrowser(layout: layout, inputs: inputs, state: state, store: store,
            actions: browserActions, focus: $focusedItem).equatable()
    }
    private func selectFilter(_ value: ProjectWorkspaceFilter) {
        filter = value; selection.removeAll(); selectionAnchor = nil
    }
    private func makeTasks(_ items: [ProjectWorkspaceItem]) {
        browserActions.makeTasks(items)
    }
    private func undoTasks() {
        guard let receipt = undoReceipt else { return }
        if state.undoProjectTaskConversion(receipt) { undoReceipt = nil }
    }

    private func notes(in items: [ProjectWorkspaceItem]) -> String? {
        items.compactMap { if case .note(let note) = $0 { return note.text }; return nil }.first
    }
    private func copy(_ items: [ProjectWorkspaceItem], summary: Bool, scope: ProjectWorkspaceExportScope) {
        do {
            if summary {
                let document = try ProjectWorkspaceExport.document(project: project, captures: items.compactMap(\.capture), store: store,
                    notes: notes(in: items), scope: scope, orderedItemIDs: items.map(\.id))
                try WorkspaceClipboard.write(document.summary, to: pasteboard)
            } else {
                try ProjectWorkspaceExport.copyItems(captures: items.compactMap(\.capture), store: store, notes: notes(in: items),
                    orderedItemIDs: items.map(\.id), pasteboard: pasteboard)
            }
            state.status = AppStatusMessage(text: "\(items.count) items copied\(summary ? " as a summary" : "").", severity: .success)
        } catch { state.reportFailure(error.localizedDescription) }
    }
    private func exportSelected(_ items: [ProjectWorkspaceItem]) {
        guard !items.isEmpty && !busy else { return }
        do {
            let document = try ProjectWorkspaceExport.document(project: project, captures: items.compactMap(\.capture), store: store,
                notes: notes(in: items), scope: .selection, orderedItemIDs: items.map(\.id))
            guard let url = chooseExportDestination(document) else { return }
            exporting = true
            Task { @MainActor in
                defer { exporting = false }
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                do {
                    try await ProjectWorkspaceExport.export(document, to: url)
                    state.status = AppStatusMessage(text: "\(document.itemCount) selected \(document.itemCount == 1 ? "item" : "items") saved as ZIP.", severity: .success)
                } catch { state.reportFailure(error.localizedDescription) }
            }
        } catch { state.reportFailure(error.localizedDescription) }
    }
}
