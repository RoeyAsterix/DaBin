import AppKit
import CryptoKit
import Foundation

private let daBinBundleIdentifier = "com.dabin.mac"

private enum UpdateFailure: LocalizedError {
    case message(String)

    var errorDescription: String? {
        switch self {
        case .message(let text): return text
        }
    }
}

private struct AppIdentity {
    let version: String
    let build: String
    let configuration: String?

    init(app: URL, requireRelease: Bool) throws {
        let infoURL = app.appendingPathComponent("Contents/Info.plist")
        guard let info = NSDictionary(contentsOf: infoURL) as? [String: Any],
              info["CFBundleIdentifier"] as? String == daBinBundleIdentifier,
              let version = info["CFBundleShortVersionString"] as? String,
              let build = info["CFBundleVersion"] as? String else {
            throw UpdateFailure.message("The selected application is not a valid DaBin build.")
        }
        let configuration = info["DaBinBuildConfiguration"] as? String
        if requireRelease && configuration != "Release" {
            throw UpdateFailure.message("The update does not contain a DaBin Release build.")
        }
        self.version = version
        self.build = build
        self.configuration = configuration
    }
}

private struct UpdateOptions {
    static var defaultDestination: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Applications/DaBin.app")
            .standardizedFileURL
    }

    var destination = defaultDestination
    var nonInteractive = false
    var noLaunch = false
    var verifyOnly = false
    var package: URL?
    var packageSHA256: String?

    static var installedUpdatesDirectory: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Containers/\(daBinBundleIdentifier)/Data/Library/Application Support/DaBin/Updates",
                                    isDirectory: true).standardizedFileURL
    }

    mutating func applyHandoff(_ url: URL, allowedDirectory: URL = installedUpdatesDirectory) throws {
        guard package == nil, packageSHA256 == nil else {
            throw UpdateFailure.message("The updater received conflicting package requests.")
        }
        let resolved = try DaBinUpdateHandoff.consume(url, allowedDirectory: allowedDirectory)
        package = resolved.package
        packageSHA256 = resolved.packageSHA256
    }

    static func parse(_ arguments: [String]) throws -> UpdateOptions {
        var result = UpdateOptions()
        var index = 1
        while index < arguments.count {
            switch arguments[index] {
            case "--non-interactive": result.nonInteractive = true
            case "--no-launch": result.noLaunch = true
            case "--verify-only": result.verifyOnly = true
            case "--package":
                index += 1
                guard index < arguments.count, result.package == nil else {
                    throw UpdateFailure.message("--package needs an absolute update ZIP path.")
                }
                let path = arguments[index]
                guard path.hasPrefix("/"), URL(fileURLWithPath: path).pathExtension.lowercased() == "zip" else {
                    throw UpdateFailure.message("--package must be an absolute path to a ZIP file.")
                }
                result.package = URL(fileURLWithPath: path).standardizedFileURL
            case "--handoff-file":
                index += 1
                guard index < arguments.count else {
                    throw UpdateFailure.message("--handoff-file needs an absolute request path.")
                }
                let handoff = URL(fileURLWithPath: arguments[index]).standardizedFileURL
                try result.applyHandoff(handoff, allowedDirectory: handoff.deletingLastPathComponent())
            case "--package-sha256":
                index += 1
                guard index < arguments.count, result.packageSHA256 == nil,
                      arguments[index].range(of: "^[0-9a-f]{64}$", options: .regularExpression) != nil else {
                    throw UpdateFailure.message("--package-sha256 needs a lowercase SHA-256 checksum.")
                }
                result.packageSHA256 = arguments[index]
            case "--destination":
                index += 1
                guard index < arguments.count else {
                    throw UpdateFailure.message("--destination needs an absolute DaBin.app path.")
                }
                let path = arguments[index]
                guard path.hasPrefix("/"), URL(fileURLWithPath: path).lastPathComponent == "DaBin.app" else {
                    throw UpdateFailure.message("--destination must be an absolute path ending in DaBin.app.")
                }
                result.destination = URL(fileURLWithPath: path).standardizedFileURL
            default:
                throw UpdateFailure.message("Unknown updater option: \(arguments[index])")
            }
            index += 1
        }
        guard (result.package == nil) == (result.packageSHA256 == nil) else {
            throw UpdateFailure.message("A package path and its SHA-256 checksum must be supplied together.")
        }
        return result
    }
}

private final class PreparedUpdate {
    private let files = FileManager.default
    private var temporaryRoot: URL?
    let source: URL

    init(options: UpdateOptions, updaterBundle: Bundle) throws {
        guard let package = options.package, let expectedHash = options.packageSHA256 else {
            source = updaterBundle.bundleURL.deletingLastPathComponent().appendingPathComponent("DaBin.app")
            return
        }
        let root = files.temporaryDirectory.appendingPathComponent("DaBinUpdate-\(UUID().uuidString)", isDirectory: true)
        try files.createDirectory(at: root, withIntermediateDirectories: false,
                                  attributes: [.posixPermissions: 0o700])
        temporaryRoot = root
        do {
            let frozen = try DaBinUpdatePackageCopy.freeze(package, sha256: expectedHash, in: root)
            try DaBinUpdateArchiveValidator.validate(frozen)
            let payload = root.appendingPathComponent("Payload", isDirectory: true)
            try files.createDirectory(at: payload, withIntermediateDirectories: false,
                                      attributes: [.posixPermissions: 0o700])
            _ = try Self.run("/usr/bin/ditto", ["-x", "-k", frozen.path, payload.path])
            try Self.rejectSymlinks(in: payload)
            let entries = try files.contentsOfDirectory(at: payload, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
                                                        options: [.skipsHiddenFiles])
            guard entries.count == 1, entries[0].lastPathComponent.hasPrefix("DaBin-"),
                  try entries[0].resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey]).isDirectory == true,
                  try entries[0].resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey]).isSymbolicLink != true else {
                throw UpdateFailure.message("The update ZIP has an unexpected folder layout.")
            }
            let app = entries[0].appendingPathComponent("DaBin.app", isDirectory: true)
            guard files.fileExists(atPath: app.path) else {
                throw UpdateFailure.message("The update ZIP does not contain DaBin.app.")
            }
            source = app
        } catch {
            try? files.removeItem(at: root)
            temporaryRoot = nil
            throw error
        }
    }

    deinit {
        if let temporaryRoot { try? files.removeItem(at: temporaryRoot) }
    }

    private static func run(_ executable: String, _ arguments: [String]) throws -> String {
        let process = Process()
        let pipe = Pipe()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        process.standardOutput = pipe
        process.standardError = pipe
        try process.run()
        process.waitUntilExit()
        let text = String(data: pipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8) ?? ""
        guard process.terminationStatus == 0 else {
            throw UpdateFailure.message(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                ? "The update ZIP could not be extracted." : text)
        }
        return text
    }

    private static func rejectSymlinks(in root: URL) throws {
        guard let enumerator = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isSymbolicLinkKey]) else {
            throw UpdateFailure.message("The extracted update could not be inspected.")
        }
        for case let item as URL in enumerator where try item.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink == true {
            throw UpdateFailure.message("The update ZIP contains an unsupported symbolic link.")
        }
    }
}

private struct UpdateResult {
    let identity: AppIdentity
    let backup: URL?
}

private final class DaBinInstaller {
    private let files = FileManager.default
    private let preparedUpdate: PreparedUpdate
    var source: URL { preparedUpdate.source.standardizedFileURL }
    let destination: URL
    let standardDestination: URL

    init(preparedUpdate: PreparedUpdate, destination: URL) {
        self.preparedUpdate = preparedUpdate
        self.destination = destination.standardizedFileURL
        standardDestination = files.homeDirectoryForCurrentUser
            .appendingPathComponent("Applications/DaBin.app").standardizedFileURL
    }

    @discardableResult
    private func run(_ executable: String, _ arguments: [String]) throws -> String {
        let process = Process()
        let pipe = Pipe()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        process.standardOutput = pipe
        process.standardError = pipe
        do { try process.run() } catch {
            throw UpdateFailure.message("Could not run \(URL(fileURLWithPath: executable).lastPathComponent): \(error.localizedDescription)")
        }
        process.waitUntilExit()
        let output = String(data: pipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8) ?? ""
        guard process.terminationStatus == 0 else {
            let detail = output.trimmingCharacters(in: .whitespacesAndNewlines)
            throw UpdateFailure.message(detail.isEmpty ? "\(executable) failed." : detail)
        }
        return output.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func rejectSymlinks(in root: URL) throws {
        let rootValues = try root.resourceValues(forKeys: [.isSymbolicLinkKey, .isDirectoryKey])
        guard rootValues.isDirectory == true, rootValues.isSymbolicLink != true else {
            throw UpdateFailure.message("The update application must be a real folder, not a symbolic link.")
        }
        guard let enumerator = files.enumerator(at: root, includingPropertiesForKeys: [.isSymbolicLinkKey]) else {
            throw UpdateFailure.message("The update application could not be inspected.")
        }
        for case let item as URL in enumerator {
            if try item.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink == true {
                throw UpdateFailure.message("The update contains an unsupported symbolic link.")
            }
        }
    }

    @discardableResult
    func validateSource() throws -> AppIdentity {
        try rejectSymlinks(in: source)
        let identity = try AppIdentity(app: source, requireRelease: true)
        let executable = source.appendingPathComponent("Contents/MacOS/DaBin")
        let architectures = try run("/usr/bin/lipo", ["-archs", executable.path])
        guard architectures == "arm64" else {
            throw UpdateFailure.message("This update must contain an Apple Silicon ARM64 build.")
        }
        _ = try run("/usr/bin/codesign", ["--verify", "--deep", "--strict", source.path])
        return identity
    }

    private func validateExistingDestination() throws -> AppIdentity? {
        guard files.fileExists(atPath: destination.path) else { return nil }
        let values = try destination.resourceValues(forKeys: [.isSymbolicLinkKey, .isDirectoryKey])
        guard values.isDirectory == true, values.isSymbolicLink != true else {
            throw UpdateFailure.message("The existing destination is not a normal DaBin application. It was preserved.")
        }
        return try AppIdentity(app: destination, requireRelease: false)
    }

    private func quitInstalledDaBin() throws {
        guard destination == standardDestination else { return }
        let running = NSRunningApplication.runningApplications(withBundleIdentifier: daBinBundleIdentifier)
        guard !running.isEmpty else { return }
        running.forEach { _ = $0.terminate() }
        let deadline = Date().addingTimeInterval(15)
        while running.contains(where: { !$0.isTerminated }) && Date() < deadline {
            RunLoop.current.run(until: Date().addingTimeInterval(0.05))
        }
        guard running.allSatisfy(\.isTerminated) else {
            throw UpdateFailure.message("DaBin is still open. Finish or cancel any edit or removal, quit DaBin, then run the updater again.")
        }
    }

    private func timestamp() -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        return formatter.string(from: Date())
    }

    func install(launch: Bool) throws -> UpdateResult {
        let sourceIdentity = try validateSource()
        let current = try validateExistingDestination()
        _ = current
        try quitInstalledDaBin()

        let applications = destination.deletingLastPathComponent()
        let parentValues = try applications.deletingLastPathComponent()
            .resourceValues(forKeys: [.isSymbolicLinkKey])
        guard parentValues.isSymbolicLink != true else {
            throw UpdateFailure.message("The Applications destination is reached through a symbolic link. Nothing was changed.")
        }
        if files.fileExists(atPath: applications.path) {
            let values = try applications.resourceValues(forKeys: [.isSymbolicLinkKey, .isDirectoryKey])
            guard values.isDirectory == true, values.isSymbolicLink != true else {
                throw UpdateFailure.message("The Applications destination is not a normal folder. Nothing was changed.")
            }
        }
        try files.createDirectory(at: applications, withIntermediateDirectories: true)
        let stage = applications.appendingPathComponent(".DaBin-update-\(UUID().uuidString).app")
        try files.createDirectory(at: stage, withIntermediateDirectories: false,
                                  attributes: [.posixPermissions: 0o700])
        let ownedStage = try DaBinUpdateCommit.directoryIdentity(stage)
        var backup: URL?
        defer {
            if files.fileExists(atPath: stage.path) {
                do { try DaBinUpdateCommit.removeOwnedDirectory(stage, matching: ownedStage) }
                catch { fputs("DaBin Update: \(error.localizedDescription)\n", stderr) }
            }
        }

        _ = try run("/usr/bin/ditto", ["--noextattr", "--norsrc", source.path, stage.path])
        let stagedIdentity = try AppIdentity(app: stage, requireRelease: true)
        guard stagedIdentity.version == sourceIdentity.version,
              stagedIdentity.build == sourceIdentity.build else {
            throw UpdateFailure.message("The staged update identity changed while copying.")
        }
        _ = try run("/usr/bin/codesign", ["--verify", "--deep", "--strict", stage.path])

        if files.fileExists(atPath: destination.path) {
            let backups = applications.appendingPathComponent(".DaBinBackups", isDirectory: true)
            let backupValues = try? backups.resourceValues(forKeys: [.isSymbolicLinkKey])
            if backupValues?.isSymbolicLink == true {
                throw UpdateFailure.message("The DaBin backup location is a symbolic link. Nothing was changed.")
            }
            try files.createDirectory(at: backups, withIntermediateDirectories: true)
            let backupURL = backups.appendingPathComponent("\(timestamp())-\(UUID().uuidString.prefix(8)).app")
            try files.moveItem(at: destination, to: backupURL)
            backup = backupURL
        }

        try DaBinUpdateCommit.install(stage: stage, destination: destination, backup: backup) { destination in
            _ = try run("/usr/bin/codesign", ["--verify", "--deep", "--strict", destination.path])
            let installed = try AppIdentity(app: destination, requireRelease: true)
            guard installed.version == sourceIdentity.version,
                  installed.build == sourceIdentity.build else {
                throw UpdateFailure.message("The installed DaBin version does not match the update.")
            }
        }

        if launch {
            _ = try run("/usr/bin/open", ["-a", destination.path, "--args", "--show-daily"])
        }
        return UpdateResult(identity: sourceIdentity, backup: backup)
    }
}

@MainActor
private final class UpdateDelegate: NSObject, NSApplicationDelegate {
    private let baseOptions: UpdateOptions
    private let waitingForHandoff: Bool
    private var readyOptions: UpdateOptions?
    private var pendingError: Error?
    private var didFinishLaunching = false
    private var didStart = false
    private var timeoutScheduled = false

    init(options: UpdateOptions, waitingForHandoff: Bool) {
        baseOptions = options
        self.waitingForHandoff = waitingForHandoff
        readyOptions = waitingForHandoff ? nil : options
    }

    func application(_ application: NSApplication, open urls: [URL]) {
        guard waitingForHandoff, !didStart, readyOptions == nil, pendingError == nil, urls.count == 1 else {
            pendingError = UpdateFailure.message("The updater received an unexpected or duplicate update request.")
            application.reply(toOpenOrPrint: .failure)
            startIfReady()
            return
        }
        do {
            var options = baseOptions
            let isolatedQARoot = baseOptions.nonInteractive && baseOptions.noLaunch
                && baseOptions.destination != UpdateOptions.defaultDestination
                ? urls[0].deletingLastPathComponent()
                : UpdateOptions.installedUpdatesDirectory
            try options.applyHandoff(urls[0], allowedDirectory: isolatedQARoot)
            readyOptions = options
            application.reply(toOpenOrPrint: .success)
        } catch {
            pendingError = error
            application.reply(toOpenOrPrint: .failure)
        }
        startIfReady()
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        didFinishLaunching = true
        NSApp.activate(ignoringOtherApps: true)
        startIfReady()
        guard waitingForHandoff, readyOptions == nil, pendingError == nil, !timeoutScheduled else { return }
        timeoutScheduled = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) { [weak self] in
            guard let self, !self.didStart, self.readyOptions == nil, self.pendingError == nil else { return }
            self.pendingError = UpdateFailure.message("DaBin Update did not receive a verified update request. Try again from DaBin Settings, or open the updater from the downloaded package.")
            self.startIfReady()
        }
    }

    private func startIfReady() {
        guard didFinishLaunching, !didStart else { return }
        if let pendingError {
            didStart = true
            finish(with: pendingError)
            return
        }
        guard let options = readyOptions else { return }
        didStart = true
        perform(options)
    }

    private func perform(_ options: UpdateOptions) {
        do {
            let prepared = try PreparedUpdate(options: options, updaterBundle: .main)
            let installer = DaBinInstaller(preparedUpdate: prepared, destination: options.destination)
            if options.verifyOnly {
                let identity = try installer.validateSource()
                print("Verified DaBin \(identity.version) (\(identity.build)) ARM64 Release update")
                NSApp.terminate(nil)
                return
            }
            if options.nonInteractive {
                let result = try installer.install(launch: !options.noLaunch)
                print("Installed DaBin \(result.identity.version) (\(result.identity.build)) at \(options.destination.path)")
                if let backup = result.backup { print("Previous app backed up at \(backup.path)") }
                NSApp.terminate(nil)
                return
            }
            let update = try installer.validateSource()
            let current = try? AppIdentity(app: options.destination, requireRelease: false)
            let alert = NSAlert()
            alert.messageText = current == nil ? "Install DaBin \(update.version)?" : "Update DaBin to \(update.version)?"
            alert.informativeText = "Current app: \(current.map { "\($0.version) (\($0.build))" } ?? "not installed")\nUpdate: \(update.version) (\(update.build))\n\nDaBin will quit, the current app will be backed up, and the update will be verified before it opens. Your captures and local archive stay in place."
            alert.addButton(withTitle: current == nil ? "Install" : "Update")
            alert.addButton(withTitle: "Cancel")
            guard alert.runModal() == .alertFirstButtonReturn else { NSApp.terminate(nil); return }

            let result = try installer.install(launch: !options.noLaunch)
            let done = NSAlert()
            done.messageText = "DaBin \(result.identity.version) is ready"
            done.informativeText = result.backup == nil
                ? "DaBin was installed and verified. Your local archive was not changed."
                : "DaBin was updated and verified. The previous app was backed up, and your local archive was not changed."
            done.addButton(withTitle: "Done")
            done.runModal()
        } catch {
            finish(with: error)
            return
        }
        NSApp.terminate(nil)
    }

    private func finish(with error: Error) {
        if baseOptions.nonInteractive {
            fputs("DaBin Update: \(error.localizedDescription)\n", stderr)
        } else {
            let alert = NSAlert(error: error)
            alert.messageText = "DaBin could not be updated"
            alert.informativeText = error.localizedDescription
            alert.addButton(withTitle: "Close")
            alert.runModal()
        }
        NSApp.terminate(nil)
    }
}

@main
private enum DaBinUpdaterMain {
    @MainActor static func main() {
        do {
            let options = try UpdateOptions.parse(CommandLine.arguments)
            let siblingApp = Bundle.main.bundleURL.deletingLastPathComponent()
                .appendingPathComponent("DaBin.app", isDirectory: true)
            let waitingForHandoff = options.package == nil
                && !FileManager.default.fileExists(atPath: siblingApp.path)
            if !waitingForHandoff && (options.verifyOnly || options.nonInteractive) {
                let prepared = try PreparedUpdate(options: options, updaterBundle: .main)
                let installer = DaBinInstaller(preparedUpdate: prepared, destination: options.destination)
                if options.verifyOnly {
                    let identity = try installer.validateSource()
                    print("Verified DaBin \(identity.version) (\(identity.build)) ARM64 Release update")
                } else {
                    let result = try installer.install(launch: !options.noLaunch)
                    print("Installed DaBin \(result.identity.version) (\(result.identity.build)) at \(options.destination.path)")
                    if let backup = result.backup { print("Previous app backed up at \(backup.path)") }
                }
                return
            }
            let application = NSApplication.shared
            application.setActivationPolicy(.regular)
            let delegate = UpdateDelegate(options: options, waitingForHandoff: waitingForHandoff)
            application.delegate = delegate
            application.run()
            _ = delegate
        } catch {
            fputs("DaBin Update: \(error.localizedDescription)\n", stderr)
            exit(1)
        }
    }
}
