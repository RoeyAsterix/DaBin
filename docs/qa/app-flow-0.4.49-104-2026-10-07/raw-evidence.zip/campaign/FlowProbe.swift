@testable import DaBinTestCore
import AppKit
import SwiftUI

@MainActor private final class FixtureNotifications: ReminderNotificationClient {
    func authorization() async -> ReminderAuthorization { .denied }
    func requestAuthorization() async throws -> Bool { false }
    func pending() async -> [ScheduledReminder] { [] }
    func add(_ reminder: ScheduledReminder) async throws { }
    func removePending(_ identifiers: [String]) { }
    func removeDelivered(_ identifiers: [String]) { }
}

/// Disposable manual exploration of the production BoardView and action state.
/// All stores, defaults, clipboard and exports are owned by this fixture.
@main @MainActor final class FlowProbe: NSObject, NSApplicationDelegate {
    static let evidence = URL(fileURLWithPath: "/private/tmp/dabin-flow-check-20261007/manual", isDirectory: true)
    var state: AppState!
    var window: NSWindow!
    var tick: Timer?
    var preferences: UserDefaults!
    var clipboard: NSPasteboard!
    var clipboardWrites = 0
    var folderRequests: [String] = []

    static func main() {
        let app = NSApplication.shared
        app.setActivationPolicy(.regular)
        let delegate = FlowProbe()
        app.delegate = delegate
        withExtendedLifetime(delegate) { app.run() }
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        do {
            try FileManager.default.createDirectory(at: Self.evidence, withIntermediateDirectories: true)
            preferences = UserDefaults(suiteName: "com.dabin.qa.flowprobe.preferences")!
            preferences.set(false, forKey: PreviewService.linkPreviewPreference)
            let store = try CaptureStore(root: Self.evidence.appendingPathComponent("archive"), repairArchiveOnOpen: false)
            let previews = PreviewService(store: store, defaults: preferences)
            clipboard = NSPasteboard(name: .init("com.dabin.qa.flowprobe.clipboard"))
            let auto = AutoCaptureService(settings: AutoCaptureSettings(defaults: preferences), input: InputService(store: store),
                pasteboardProvider: { fatalError("Fixture must not read the system clipboard") }, sourceApplicationProvider: { nil })
            let captureClipboard = CaptureClipboardService(pasteboard: clipboard)
            state = AppState(store: store, previews: previews, reminders: ReminderService(store: store, client: FixtureNotifications()),
                autoCapture: auto, captureClipboard: captureClipboard,
                folderOpener: { [weak self] url in self?.folderRequests.append(url.path); return true })
            if store.captures.isEmpty {
                try state.workspace.createProject(name: "Flow Alpha", colorHex: "7568D8")
                try state.workspace.createProject(name: "Flow Empty", colorHex: "38A58D")
                _ = try store.createNote(text: "Review the fictional launch brief. Save the notes and send the revised draft.", projectName: "Flow Alpha")
                _ = try store.createTask(text: "Prepare fictional review", planning: TaskPlanning(plannedDay: CaptureCalendar.dayString(Date()), checklist: [TaskChecklistItem(text: "Check the draft")]), projectName: "Flow Alpha")
                _ = try store.capture(text: "https://example.invalid/fictional-reference")
                _ = try store.capture(text: "Unassigned fictional caption — search needle")
                try state.workspace.setScratchpad(text: "Fictional project notes for the flow check.", project: "Flow Alpha")
                let textFile = Self.evidence.appendingPathComponent("fictional-attachment.txt")
                try Data("Fictional file content only".utf8).write(to: textFile)
                _ = try awaitImport(store: store, file: textFile)
            }
            state.openLibrary()
            state.navigateProject("Flow Alpha")
            state.isBoardVisible = true
            let export = DayExportActionController(pasteboardWriter: { [weak self] text in
                self?.clipboard.clearContents(); self?.clipboardWrites += 1
                return self?.clipboard.setString(text, forType: .string) ?? false
            }, destinationChooser: { _, name in .selected(Self.evidence.appendingPathComponent(name)) },
                fileWriter: { data, url in try data.write(to: url, options: .atomic) })
            let view = BoardView(state: state, theme: ThemeSettings(defaults: preferences, systemDarkMode: false), dayExportController: export)
            window = NSWindow(contentRect: NSRect(x: 140, y: 100, width: 760, height: 740),
                styleMask: [.titled, .closable, .resizable, .miniaturizable], backing: .buffered, defer: false)
            window.title = "DaBin Disposable Flow Check"
            window.minSize = NSSize(width: 380, height: 430)
            window.contentView = NSHostingView(rootView: view)
            window.isReleasedWhenClosed = false
            state.onDismiss = { [weak self] in self?.window.orderOut(nil) }
            window.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            tick = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
                Task { @MainActor in self?.record() }
            }
            record()
        } catch {
            try? String(describing: error).write(to: Self.evidence.appendingPathComponent("launch-error.txt"), atomically: true, encoding: .utf8)
            NSApp.terminate(nil)
        }
    }

    // Import's asynchronous commit is exercised by the automated native suites.
    // The manual fixture provides a local text capture with its file URL instead.
    func awaitImport(store: CaptureStore, file: URL) throws -> Capture {
        try store.capture(text: file.absoluteString)[0]
    }

    func record() {
        guard let state else { return }
        let values: [String: Any] = ["route": String(describing: state.route), "project": state.libraryProject ?? "Captions",
            "query": state.query, "newNoteText": state.newNoteText, "newTaskText": state.newTaskDraft.text,
            "selectedID": state.selectedCapture?.id.uuidString ?? "", "draftComment": state.selectedDraft?.commentComposer ?? "",
            "status": state.notificationMessage?.text ?? "", "clipboardText": clipboard.string(forType: .string) ?? "",
            "folderRequests": folderRequests, "captures": state.store.captures.map { ["id": $0.id.uuidString, "text": $0.originalText ?? "", "task": $0.isTask] },
            "trashedIDs": state.store.trashedCaptures.map { $0.id.uuidString }]
        if let data = try? JSONSerialization.data(withJSONObject: values, options: [.prettyPrinted, .sortedKeys]) {
            try? data.write(to: Self.evidence.appendingPathComponent("state.json"), options: .atomic)
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        state?.persistDrafts(); record(); tick?.invalidate()
        state?.autoCapture.shutdown(); state?.previews.shutdown(); state?.focusSessions.shutdown()
        state?.shutdownNotificationPresentation(); state?.store.cancelArchiveRepair()
    }
}
