#!/usr/bin/env python3
"""Stage review evidence only; never run workloads or change repository inputs.

Run only after root writes flow-verification.json. Required contract:
status=passed_selected_101, sourceUnchanged=true, canonicalFingerprint,
selectedSuiteCount=101, registeredSuiteCount=132, reports=[{role,report,log}],
supplementalInputManifest=update-config-fixture-repair.json. Reports use paths
relative to this campaign. Roles: focused, remaining, supplemental. The original
remaining report must remain failed for UpdateConfigurationTests alone; the
supplemental report must request and pass only that suite. A successful original
96 phase is also supported, without silently dropping a supplied supplement.

Supplemental manifest accepts inputs=[{path,sha256/SHA256/SHA,snapshotPath?}]
or inputHashes={repo-relative:sha256}. Existing frozen hashes complete the
already-tracked dependencies. Explicit missing runner inputs remain separate.
A missing/failed/mismatched receipt raises before staging any evidence.
"""
import ast
import copy
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import re
import shutil
import sys
import tempfile
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
NATIVE = ROOT / 'working/native'
PREFIX = b'@testable import DaBinTestCore\n'
DEPENDENCIES = {
    'native/Resources/Info.plist', 'native/DaBin.xcodeproj/project.pbxproj',
    'native/Config/AppStoreSigning.json', 'native/Sources/DaBin/SoftwareUpdateService.swift',
    'native/Sources/DaBin/UpdateHandoff.swift', 'native/scripts/build_app.py',
    'native/scripts/archive_app_store.sh', 'native/scripts/app_store_archive_location.py',
    'native/scripts/app_store_preflight.py', 'native/UpdateTools/package_update.py',
    'native/scripts/stage_release_assets.py', '.github/workflows/stable-latest-downloads.yml',
    'docs/RELEASING.md', 'README.md', 'native/UpdateTools/DaBinUpdater.swift',
    'native/Resources/PrivacyPolicy.md',
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def fp(value):
    return digest(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def within(base, relative):
    value = Path(relative)
    require(not value.is_absolute() and '..' not in value.parts,
            'Unsafe relative evidence/input path: ' + str(relative))
    result = base / value
    require(result.resolve().is_relative_to(base.resolve()), 'Path escaped its declared root')
    return result


def registry():
    result = {'NONFOCUS': [], 'WINDOW': []}
    for node in ast.parse((NATIVE / 'scripts/run_qa.py').read_text()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name) and target.id in result:
                result[target.id] = ast.literal_eval(node.value)
        elif isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Name):
            if node.target.id in result:
                result[node.target.id] += ast.literal_eval(node.value)
        elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
            call = node.value
            if isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name):
                if call.func.value.id in result and call.func.attr == 'append':
                    result[call.func.value.id].append(ast.literal_eval(call.args[0]))
    names = result['NONFOCUS'] + result['WINDOW']
    require(len(names) == len(set(names)) == 132, 'Registered suite inventory is not the frozen132')
    return names


def inventory_module():
    spec = importlib.util.spec_from_file_location('flow_evidence_inventory', NATIVE / 'scripts/project_inventory.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # Pure inventory definitions; its CLI is not invoked.
    return module


def inventory_at(module, native_root):
    original = module.ROOT
    try:
        module.ROOT = native_root
        return module.build_inventory()
    finally:
        module.ROOT = original


def main():
    output = ROOT / 'evidence'
    require(not output.exists(), 'Refusing to overwrite existing evidence staging')
    verification = read_json(ROOT / 'flow-verification.json')
    freeze = read_json(ROOT / 'flow-freeze.json')
    base = read_json(ROOT / 'baseline.json')
    live = Path(base['liveRoot'])
    working = Path(base['workingRoot'])
    require(working.resolve() == (ROOT / 'working').resolve(), 'Unexpected working snapshot')
    require(verification.get('status') == 'passed_selected_101'
            and verification.get('sourceUnchanged') is True
            and verification.get('selectedSuiteCount') == 101
            and verification.get('registeredSuiteCount') == 132,
            'Final joined acceptance receipt is missing or not accepted')
    require(verification.get('canonicalFingerprint') == freeze['canonicalFingerprint'],
            'Final receipt production fingerprint differs from freeze')
    selected = freeze['requestedSuites']
    registered = registry()
    require(len(selected) == len(set(selected)) == 101 and set(selected) <= set(registered),
            'Expected exactly101 distinct selected registered suites')
    require(freeze['registryCount'] == 132 and fp(freeze['inputs']) == freeze['qaFingerprint'],
            'Invalid frozen QA inventory fingerprint')
    raw = {}
    stage = {}
    read_receipts = {}

    def add_file(path, archive_name):
        require(path.is_file() and not path.is_symlink(), 'Missing/nonregular evidence: ' + str(path))
        data = path.read_bytes()
        require(archive_name not in raw, 'Duplicate archive entry: ' + archive_name)
        raw[archive_name] = data
        read_receipts[str(path)] = digest(data)
        return data

    def add_root(relative):
        return add_file(within(ROOT, relative), 'campaign/' + relative)

    def check_sources():
        for path, expected in freeze['inputs'].items():
            require(sha(within(NATIVE, path)) == expected, 'Snapshot input mismatch: ' + path)
            require(sha(within(live / 'native', path)) == expected, 'Live input mismatch: ' + path)
        require(fp(inventory_at(inv, NATIVE)) == freeze['canonicalFingerprint'], 'Snapshot production changed')
        require(fp(inventory_at(inv, live / 'native')) == freeze['canonicalFingerprint'], 'Live production changed')
        for item in owned['changes']:
            relative = item['path']
            require(sha(within(working, relative)) == item['afterSHA256'], 'Owned snapshot mismatch: ' + relative)
            require(sha(within(live, relative)) == item['afterSHA256'], 'Owned live mismatch: ' + relative)

    inv = inventory_module()
    owned = read_json(ROOT / 'owned-changes.json')
    require(len(owned['changes']) == 11
            and sum(c['path'].startswith('native/Sources/') for c in owned['changes']) == 7
            and sum(c['path'].startswith('native/Tests/') for c in owned['changes']) == 4,
            'Owned seven-source/four-test boundary changed')
    applied = read_json(ROOT / 'applied-fixes.json')
    require(applied['canonicalFingerprint'] == freeze['canonicalFingerprint']
            and applied['allCopiedBytesVerified'] is True
            and set(applied['ownedPaths']) == {c['path'] for c in owned['changes']}, 'Invalid applied-fixes receipt')
    check_sources()

    reports = {}
    suite_history = {name: [] for name in selected}
    phase_info = []
    warning_lines = []
    completion_receipts = []
    module_inputs = None
    log_paths = set()
    declarations = verification['reports']
    require(len({r['role'] for r in declarations}) == len(declarations), 'Duplicate report role')
    require({'focused', 'remaining'} <= {r['role'] for r in declarations}, 'Missing final original phases')
    require({r['role'] for r in declarations} <= {'focused', 'remaining', 'supplemental'}, 'Unknown phase role')
    declarations = sorted(declarations, key=lambda r: ['focused', 'remaining', 'supplemental'].index(r['role']))
    for declaration in declarations:
        role = declaration['role']
        path = within(ROOT, declaration['report'])
        report = read_json(path)
        reports[role] = report
        requested = [s for s in report['suites'] if s['status'] != 'not_requested']
        names = {s['name'] for s in requested}
        require(len(report['suites']) == 132 and {s['name'] for s in report['suites']} == set(registered),
                role + ': report registry mismatch')
        require(len(names) == len(requested) and names <= set(selected), role + ': invalid requested inventory')
        require(report['configuration'] == 'Release' and report['distribution'] == 'app-store'
                and report['coverage'] == 'selected_suites' and report['compileDefinitions'] == []
                and report['sourceChangedDuringRun'] is False
                and report['productionModule']['status'] == 'passed', role + ': invalid runtime/input scope')
        expected = {p: h for p, h in freeze['inputs'].items()
                    if (not p.startswith('Tests/') or p in {'Tests/' + n + '.swift' for n in names})
                    and (p != 'Handoff/implementation/search-cases.json' or 'DomainTests' in names)}
        require(report['inputs'] == expected and fp(report['inputs']) == report['sourceFingerprint'],
                role + ': report inputs do not match final frozen bytes')
        require(report['passedSuites'] == sum(s['status'] == 'passed' for s in requested)
                and report['failedSuites'] == sum(s['status'] != 'passed' for s in requested), role + ': count mismatch')
        phase_info.append({'role': role, 'report': declaration['report'], 'reportSHA256': sha(path),
                           'status': report['status'], 'requestedSuites': len(names),
                           'passedSuites': report['passedSuites'], 'failedSuites': report['failedSuites'],
                           'sourceFingerprint': report['sourceFingerprint']})
        add_root(declaration['report']); add_root(declaration['log'])
        run_directories = set()
        for suite in requested:
            require(suite.get('compile', {}).get('status') == 'passed', role + ': compile failure')
            suite_history[suite['name']].append({'role': role, **suite})
            log_path = within(NATIVE, suite['log'])
            run_directories.add(log_path.parent)
            log_paths.add(log_path)
            if suite['name'] in {'WindowTests', 'HeaderInteractionTests', 'SearchWindowTests'}:
                require(suite.get('completion', {}).get('passed') is True, role + ': missing native completion sentinel')
                completion_receipts.append({'role': role, 'name': suite['name'], 'log': suite['log'],
                                            'completion': suite['completion']})
            if suite['name'] == 'CardDeletionInteractionTests' and suite['status'] == 'passed':
                require('COMPLETE: CardDeletionInteractionTests finished every fixture and cleanup'
                        in log_path.read_text(), 'Missing CardDeletion explicit completion marker')
        for directory in run_directories:
            for artifact in sorted(directory.iterdir()):
                if artifact.is_file() and artifact.suffix in {'.json', '.log'}:
                    if artifact not in log_paths: log_paths.add(artifact)
                    add_file(artifact, 'native-final/' + str(artifact.relative_to(NATIVE)))
        current_module = {'sources': inv.hashes(inv.sources(False)), 'compiler': report['swiftVersion'],
                          'sdk': report['sdkVersion'], 'target': report['target'],
                          'configuration': report['configuration'], 'distribution': report['distribution'],
                          'compileDefinitions': report['compileDefinitions'],
                          'runner': sha(NATIVE / 'scripts/run_qa.py'),
                          'inventory': sha(NATIVE / 'scripts/project_inventory.py')}
        require(module_inputs is None or module_inputs == current_module, 'Phase production compile inputs differ')
        module_inputs = current_module

    focused_names = {'CardDeletionInteractionTests', 'WindowTests', 'SearchInputTests', 'SearchWindowTests', 'HeaderInteractionTests'}
    require({s['name'] for s in reports['focused']['suites'] if s['status'] != 'not_requested'} == focused_names,
            'Focused phase is not the five affected suites')
    require(reports['focused']['status'] == 'passed' and reports['focused']['passedSuites'] == 5, 'Focused phase not passed')
    remaining = reports['remaining']
    remaining_names = {s['name'] for s in remaining['suites'] if s['status'] != 'not_requested'}
    require(remaining_names == set(selected) - focused_names and len(remaining_names) == 96,
            'Original remaining phase is not the other96 suites')
    original_failed = [s for s in remaining['suites'] if s['status'] not in {'passed', 'not_requested'}]
    if original_failed:
        require(remaining['status'] == 'failed' and len(original_failed) == 1
                and original_failed[0]['name'] == 'UpdateConfigurationTests'
                and original_failed[0]['status'] == 'failed'
                and remaining['passedSuites'] == 95, 'Unexpected original remaining failure')
        require('supplemental' in reports, 'Missing failed-suite supplement')
    if 'supplemental' in reports:
        supplemental = reports['supplemental']
        require({s['name'] for s in supplemental['suites'] if s['status'] != 'not_requested'} == {'UpdateConfigurationTests'}
                and supplemental['status'] == 'passed' and supplemental['passedSuites'] == 1
                and supplemental['failedSuites'] == 0, 'Supplement is not the single accepted configuration suite')
    final_suites = {name: history[-1] for name, history in suite_history.items() if history}
    require(set(final_suites) == set(selected) and all(s['status'] == 'passed' for s in final_suites.values()),
            'Final unique selected-suite acceptance is not101 passed')

    supplemental_path = within(ROOT, verification['supplementalInputManifest'])
    manifest = read_json(supplemental_path)
    explicit = {}
    for entry in manifest.get('inputs', []):
        path = entry['path']
        expected_hash = entry.get('sha256') or entry.get('SHA256') or entry.get('SHA')
        require(path not in explicit and re.fullmatch('[a-f0-9]{64}', expected_hash or ''), 'Invalid supplemental hash')
        snapshot = Path(entry.get('snapshotPath', working / path))
        require(snapshot.resolve() == within(working, path).resolve(), 'Unexpected supplemental snapshot path')
        explicit[path] = expected_hash
    for path, expected_hash in manifest.get('inputHashes', {}).items():
        require(path not in explicit and re.fullmatch('[a-f0-9]{64}', expected_hash), 'Duplicate/invalid supplemental input')
        explicit[path] = expected_hash
    frozen_repo = {'native/' + p: h for p, h in freeze['inputs'].items()}
    dependency_hashes = {}
    for path in sorted(DEPENDENCIES | set(explicit)):
        expected_hash = explicit.get(path) or frozen_repo.get(path)
        require(expected_hash is not None, 'Unrecorded supplemental dependency: ' + path)
        require(sha(within(working, path)) == sha(within(live, path)) == expected_hash,
                'Supplemental live/snapshot dependency mismatch: ' + path)
        if path in explicit and path in frozen_repo:
            require(explicit[path] == frozen_repo[path], 'Supplemental dependency changed frozen input')
        dependency_hashes[path] = expected_hash
        if path in explicit or path not in frozen_repo:
            add_file(within(working, path), 'supplemental-inputs/' + path)
    add_root(verification['supplementalInputManifest'])

    cache = NATIVE / 'build/qa-cache' / ('app-store-' + fp(module_inputs))
    module_receipt = read_json(cache / 'module-ready.json')
    require(module_receipt['inputs'] == module_inputs, 'Compiled module receipt inputs differ')
    cache_output_verification = []
    for output_name, expected_hash in module_receipt['outputs'].items():
        require(sha(within(cache, output_name)) == expected_hash, 'Compiled module output changed')
        cache_output_verification.append({'kind': 'module', 'name': output_name, 'sha256': expected_hash})
    add_file(cache / 'module-ready.json', 'cache-receipts/module-ready.json')
    for name in selected:
        test_hash = freeze['inputs']['Tests/' + name + '.swift']
        folder = cache / (name + '-' + test_hash[:16])
        receipt = read_json(folder / 'executable-ready.json')
        require(receipt['inputs'] == {'testSHA256': test_hash, 'production': module_inputs}, 'Executable receipt inputs: ' + name)
        require(set(receipt['outputs']) == {name} and sha(folder / name) == receipt['outputs'][name],
                'Compiled executable output changed: ' + name)
        cache_output_verification.append({'kind': 'executable', 'name': name, 'sha256': receipt['outputs'][name], 'testSHA256': test_hash})
        add_file(folder / 'executable-ready.json', 'cache-receipts/' + name + '/executable-ready.json')

    baseline_result = read_json(ROOT / 'baseline-native-result.json')
    baseline_suites = {s['name']: s for s in baseline_result['suites']}
    require(set(baseline_suites) == {'CardDeletionInteractionTests', 'WindowTests'}
            and all(s['compile']['status'] == 'passed' and s['run']['status'] == 'failed' for s in baseline_suites.values()),
            'Expected baseline failures are not retained')
    baseline_dir = NATIVE / 'build/flow-baseline'
    for name, suite in baseline_suites.items():
        wrapper = baseline_dir / (name + '.swift')
        data = wrapper.read_bytes()
        require(data.startswith(PREFIX) and digest(data[len(PREFIX):]) == suite['testSHA256'], 'Baseline test source mismatch: ' + name)
        raw['baseline-tests/' + name + '.swift'] = data[len(PREFIX):]
        add_file(wrapper, 'baseline-tests/' + name + '-wrapper.swift')
        for part in ['compile', 'run']:
            add_file(within(NATIVE, suite[part]['log']), 'baseline-logs/' + name + ('-compile.log' if part == 'compile' else '.log'))
    require((ROOT / 'comment-baseline.swift').read_bytes() == (baseline_dir / 'CardDeletionInteractionTests.swift').read_bytes(),
            'Standalone comment baseline does not match tested source')
    require(sha(ROOT / 'before/reproduction/CardDeletionInteractionTests.swift') == baseline_suites['CardDeletionInteractionTests']['testSHA256'],
            'Comment expected-failure source mismatch')
    require('Pressing the same comment pencil again preserves every unsaved native character'
            in (baseline_dir / 'CardDeletionInteractionTests.log').read_text(), 'Missing expected comment-loss failure')
    require('4 of 218 window checks failed' in (baseline_dir / 'WindowTests.log').read_text(), 'Missing four expected composition failures')
    add_root('comment-baseline.swift'); add_root('comment-baseline.log'); add_root('comment-baseline-compile.log')
    baseline_modules = []
    for path in sorted((NATIVE / 'build/qa-cache').glob('app-store-*/module-ready.json')):
        receipt = read_json(path)
        if receipt['outputs'] == baseline_result['baselineModuleOutputs']:
            require(all(base['inputs'].get('native/' + p) == h for p, h in receipt['inputs']['sources'].items()),
                    'Baseline module production provenance mismatch')
            require(all(sha(path.parent / p) == h for p, h in receipt['outputs'].items()), 'Baseline compiled output changed')
            baseline_modules.append(str(path))
            add_file(path, 'baseline-cache/module-ready.json')
    require(len(baseline_modules) == 1, 'Expected exactly one verified baseline module receipt')

    for attempt in ['focused-1', 'focused-2']:
        folder = ROOT / 'attempts' / attempt
        preserved = read_json(folder / 'preservation.json')
        for item in preserved['preserved']:
            require(sha(within(folder, item['path'])) == item['SHA256'], 'Preserved failed attempt changed: ' + attempt)
        attempt_report = read_json(folder / 'focused-qa-report.json')
        require(attempt_report['status'] == 'failed' and attempt_report['passedSuites'] == 4
                and attempt_report['failedSuites'] == 1 and attempt_report['sourceChangedDuringRun'] is False,
                'Failed focused attempt not retained accurately')
        for path in sorted(folder.rglob('*')):
            if path.is_file() and path.suffix in {'.json', '.log', '.patch', '.swift'}:
                add_file(path, 'attempts/' + attempt + '/' + str(path.relative_to(folder)))

    for item in owned['changes']:
        relative = item['path']
        old = ROOT / 'before' / relative
        require(sha(old) == item['beforeSHA256'], 'Owned original changed: ' + relative)
        add_file(old, 'owned-before/' + relative)
        add_file(within(working, relative), 'owned-after/' + relative)
    for relative in ['baseline.json', 'baseline-native-result.json', 'manual-session.json', 'manual-build.json',
                     'manual-compile.log', 'FlowProbe.swift', 'flow-freeze.json', 'flow-result.json', 'flow-progress.json',
                     'flow-verification.json', 'fixture-cleanup.json', 'owned-changes.json', 'applied-fixes.json',
                     'ui-flow-before.json', 'ui-flow-changes.json', 'ui-flow.patch', 'usability-fixes.patch',
                     'before/comment-edit-manifest.json', 'package_flow_evidence.py']:
        add_root(relative)
    manual_build = read_json(ROOT / 'manual-build.json')
    require(sha(ROOT / 'FlowProbe.swift') == manual_build['fixtureSourceSHA256'], 'Manual fixture source mismatch')

    visual = read_json(ROOT / 'visual-audit.json')
    require(len(visual['images']) == 9, 'Expected nine specifically reviewed PNGs')
    for item in visual['images']:
        path = Path(item['preservedAbsolutePath'])
        require(path.resolve().is_relative_to((ROOT / 'visual-review-inputs').resolve())
                and path.suffix == '.png' and sha(path) == item['sha256'], 'Reviewed PNG mismatch')
        stage[item['preservedRelativePath']] = path.read_bytes()
    add_root('visual-audit.json')
    stage['visual-audit.json'] = json_bytes(visual)

    for path in sorted(log_paths):
        if path.suffix != '.log': continue
        for number, line in enumerate(path.read_text(errors='replace').splitlines(), 1):
            if re.search(r'warning:|NOT TESTED|NOT VERIFIED|CONTROL_BOUNDARY|SKIP:|OD_PROTOCOL_PROXY_FAILED', line, re.I):
                warning_lines.append({'path': str(path.relative_to(NATIVE)), 'line': number, 'text': line})
    raw['native-completions.json'] = json_bytes(completion_receipts)
    raw['final-warning-and-boundary-lines.json'] = json_bytes(warning_lines)
    prior_path = live / 'docs/qa/modularity-0.4.49-104-2026-10-07/README.md'
    prior_data = add_file(prior_path, 'prior-performance/modularity-README.md')
    require(all(term in prior_data.decode() for term in ['52.77', '36.19', 'ten NSTableView']), 'Prior issue documentation changed')

    coverage = read_json(ROOT / 'flow-coverage.json')
    raw['campaign/flow-coverage-before-final-join.json'] = json_bytes(coverage)
    test_hashes = {name: freeze['inputs']['Tests/' + name + '.swift'] for name in selected}
    coverage['snapshot']['referencedTestSourceSHA256'].update(test_hashes)
    coverage['snapshot']['executedTestSourceSHA256'] = test_hashes
    coverage['ownedChangeManifest']['SHA256'] = sha(ROOT / 'owned-changes.json')
    coverage['currentExecution'] = {'status': 'passed_selected_101', 'selectedSuites': 101,
        'registeredSuites': 132, 'notRequestedSuites': 31, 'canonicalFingerprint': freeze['canonicalFingerprint'],
        'qaFingerprint': freeze['qaFingerprint'], 'phaseReports': phase_info,
        'originalRemainingFailures': original_failed, 'finalSuiteResults': final_suites,
        'sourceUnchanged': True, 'supplementalDependencySHA256': dependency_hashes,
        'doesNotClaimEveryPhysicalFlowVerified': True,
        'inventoryBoundary': '12 routes and24 additional user-goal families are a source inventory; neither is a count of unique continuous or physical journeys.'}
    for regression in coverage['reproducedRegressions']:
        name = regression.get('test')
        if name in final_suites:
            regression['afterFinal'] = {'status': final_suites[name]['status'], 'role': final_suites[name]['role'],
                                        'testSHA256': test_hashes[name], 'log': final_suites[name]['log']}
            if 'currentStatus' in regression:
                regression['currentStatus'] = 'Final native regression accepted; both earlier fixture-only failures are preserved.'
    require(len(coverage['routes']) == 12 and len(coverage['additionalFlowFamilies']) == 24, 'Flow inventory cardinality changed')
    stage['flow-coverage.json'] = json_bytes(coverage)
    stage['flow-verification.json'] = json_bytes(verification)
    stage['owned-changes.json'] = (ROOT / 'owned-changes.json').read_bytes()
    stage['applied-fixes.json'] = (ROOT / 'applied-fixes.json').read_bytes()
    stage['usability-fixes.patch'] = (ROOT / 'usability-fixes.patch').read_bytes()
    summary = {'schemaVersion': 1, 'createdAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'passed_selected_101', 'selectedSuitesPassed': 101, 'registeredSuites': 132,
        'notRequestedSuites': sorted(set(registered) - set(selected)), 'phaseReports': phase_info,
        'originalRemainingFailuresRetained': original_failed, 'canonicalFingerprint': freeze['canonicalFingerprint'],
        'qaFingerprint': freeze['qaFingerprint'], 'snapshotAndLiveInputsVerified': True,
        'ownedAfterHashesVerified': 11, 'compiledOutputHashReceiptsVerified': 102,
        'compiledOutputHashes': cache_output_verification, 'nativeCompletionReceipts': completion_receipts,
        'supplementalDependencySHA256': dependency_hashes, 'warningAndBoundaryLines': warning_lines,
        'inventoryScope': {'routes': 12, 'additionalUserGoalFamilies': 24, 'uniquePhysicalJourneysClaimed': False},
        'priorOpenIssues': {'sourceFingerprint': base['canonicalFingerprint'], 'strict600Seconds': {
            'status': 'failed_both_original_limits', 'inputLayoutP95ms': 52.77, 'inputLimitMs': 50,
            'steadyTimerP95ms': 36.19, 'timerLimitMs': 33}, 'priorTableWarnings': 10,
            'sourceDocument': str(prior_path), 'sourceDocumentSHA256': digest(prior_data),
            'shortComparisonsDoNotExonerateSustainedFailure': True},
        'claimsLimit': '101 selected native fixtures and service contracts; not all132, every control/physical flow, performance qualification, signed/sandboxed readiness, installation or upload.'}
    stage['verification-summary.json'] = json_bytes(summary)
    info = plistlib.loads((NATIVE / 'Resources/Info.plist').read_bytes())
    repaired_line = ('The original remaining phase was95/96 with UpdateConfigurationTests failing because the private snapshot omitted configuration/document inputs. '
                     'The preserved report is joined with one accepted supplemental run using explicitly hashed inputs; the95 successful suites were not rerun.'
                     if original_failed else 'The original remaining96 phase completed without failures.')
    stage['README.md'] = f'''# DaBin user-flow fixes — {info['CFBundleShortVersionString']} ({info['CFBundleVersion']})

Seven bounded usability fixes are applied to the existing working source. Final acceptance is **101 selected suites of132 registered**, with unchanged frozen production/test inputs and verified live owned bytes. This is fixture/control/service evidence, not every unique physical user journey or performance/release qualification.

The production fingerprint is `{freeze['canonicalFingerprint']}`. The affected five-suite focused run completed; the other96 original suite results and any configuration supplement are retained without replacing failures. {repaired_line}

The fixes preserve unfinished same-comment edits; deliver marked-text Escape to its editor before window dismissal; distinguish filtered-empty Search and Explorer from an empty archive; give untitled Search actions their visible fallback label; retain a24-by-28-point Clear-search target and stationary field; and identify the owning Trash item in Restore/Delete accessibility actions. `usability-fixes.patch`, `owned-changes.json` and `applied-fixes.json` retain11 guarded paths: seven production files and four regression tests against the preexisting working bytes. Version/build, compile flags and original timing limits remain unchanged.

The manual baseline used production BoardView/AppState with disposable archive/preferences, a named clipboard, fake reminders and disabled previews. Task creation, native typing, project filtering, Search/detail return, comment posting and completion were observed. Same-comment Edit replaced unsent text, and filtered blank Search displayed misleading empty-archive wording. The native baseline separately rejected comment reset and recorded four marked-text Escape/panel-retention failures. Escape interrupted composition; this does not assert stored draft text was erased or a physical language IME was tested.

Both focused fixture failures are preserved in `raw-evidence.zip`: stale pre-reload capture identity, then optimized Explorer-row lookup. Their repairs change test setup/lookup only. Native completion receipts, phase reports/logs, expected baseline failures/exact test sources, before/after owned sources, cache input/output hash receipts and explicit supplemental dependencies are also retained. Compiled binaries and the manual archive are excluded.

`flow-coverage.json` joins final reports and their executed test hashes. Its12 routes and24 additional user-goal families are source inventories, not counts of unique continuous/physical journeys. FlowActionStress and ConnectedWorkflow call production handlers/state/storage; actual native-control evidence is labeled separately. `visual-audit.json` and nine preserved PNGs cover only named fixture sizes/states. The standalone comment bitmap lacks Board theme context; actual Board interaction did not reproduce its contrast artifact. No confirmation-sheet pixels or compact380-point Trash layout are established by those captures.

Performance remains open. The latest prior600-second workload on `{base['canonicalFingerprint']}` failed both original gates: input/layout p95 **52.77ms >50ms** and steady timer p95 **36.19ms >33ms**. Earlier short comparisons do not exonerate that result. This flow selection excludes the strict performance test and makes no improvement claim. The prior full campaign retained ten native table delegate-reentrancy warnings and existing actor diagnostics; current exact warning/boundary lines are in `verification-summary.json` and the raw archive.

Physical drag delivery, actual chooser/OS consent, offscreen AVKit control fallbacks, physical IME/gestures/multiple displays, VoiceOver speech/rotor, real network/update installation and hardware timing remain separate boundaries. Temporary QA bundles use ad hoc signatures for native focus; this is not distribution signing or sandbox/release certification. No installation/upload outcome or all132-suite acceptance is asserted.

`verification-summary.json` distinguishes selected acceptance, preserved failed attempts and prior open issues. `evidence-manifest.json` hashes staged files; the raw ZIP contains its own member hash index. Source remains in the shared working tree with existing work preserved.
'''.encode()

    # Recheck mutable receipts and source bytes before making final claims visible.
    check_sources()
    for path, expected_hash in read_receipts.items():
        require(sha(Path(path)) == expected_hash, 'Evidence changed during collection: ' + path)
    for path, expected_hash in dependency_hashes.items():
        require(sha(within(working, path)) == sha(within(live, path)) == expected_hash, 'Supplemental input changed during collection')
    archive_index = {name: {'sha256': digest(data), 'bytes': len(data)} for name, data in sorted(raw.items())}
    raw['artifact-hashes.json'] = json_bytes({'schemaVersion': 1, 'entries': archive_index,
        'excludesSelf': True, 'scope': 'Reports/logs/receipts and explicit source/patch evidence; no compiled binaries or fixture archives.'})
    temporary = Path(tempfile.mkdtemp(prefix='.flow-evidence-', dir=ROOT))
    try:
        for relative, data in stage.items():
            path = within(temporary, relative); path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
        zip_path = temporary / 'raw-evidence.zip'
        with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, data in sorted(raw.items()): archive.writestr(name, data)
        with zipfile.ZipFile(zip_path) as archive:
            require(archive.testzip() is None, 'Raw evidence ZIP integrity failure')
            for name, item in archive_index.items():
                require(digest(archive.read(name)) == item['sha256'], 'Raw evidence member hash mismatch')
        staged_manifest = {str(p.relative_to(temporary)): {'sha256': sha(p), 'bytes': p.stat().st_size}
                           for p in sorted(temporary.rglob('*')) if p.is_file()}
        (temporary / 'evidence-manifest.json').write_bytes(json_bytes({'schemaVersion': 1, 'entries': staged_manifest, 'excludesSelf': True}))
        check_sources()
        require(not output.exists(), 'Evidence destination appeared during collection')
        os.rename(temporary, output)
    except BaseException:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    print(json.dumps({'staged': str(output), 'selectedPassed': 101, 'registered': 132,
                      'retainedOriginalRemainingFailures': len(original_failed),
                      'rawMembers': len(raw), 'compiledReceiptsVerified': 102,
                      'evidenceManifestSHA256': sha(output / 'evidence-manifest.json')}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        raise SystemExit('Evidence not staged: ' + str(error))
