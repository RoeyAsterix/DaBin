import AppKit
import SwiftUI
import Combine

enum ScreenCorner: String, CaseIterable {
    case bottomLeft, bottomRight, topLeft, topRight
    var isRight: Bool { self == .bottomRight || self == .topRight }
    var isTop: Bool { self == .topLeft || self == .topRight }
}

enum RobotRevealTarget: Equatable {
    case corner(ScreenCorner)
    case cameraIsland
}

enum CornerGeometry {
    /// Reserve the labeled navigation and search header before sizing the
    /// receipt feed. Longer lists scroll inside the screen's available space.
    @MainActor static func dailyPanelHeight(for state: AppState) -> CGFloat {
        let extra: CGFloat = state.notificationMessage != nil ? 45 : 0
        let captures = state.todayTimelineCaptures
        guard !captures.isEmpty else { return 380 + extra }
        let feed = HourlyCaptureFeed.cards(from: state.receiptCaptures(for: state.selectedDay), filter: state.filter)
        let featuredID = feed.compactMap { item -> CaptureCardGroup? in
            if case .capture(let card) = item { return card }
            return nil
        }.first { !$0.isImportedBatch && !$0.primary.isMinimized
            && $0.primary.thumbnailRelativePath != nil }?.primary.id

        func cardHeight(_ card: CaptureCardGroup, includesSingleFrameSpacing: Bool = true) -> CGFloat {
            if card.isImportedBatch {
                if card.isMinimized { return CollectionPreviewLayout.previewHeight(compact: false) + 170 }
                var height = CGFloat(92 + card.captures.count * 58)
                if !card.primary.comment.isEmpty { height += 30 }
                if card.primary.reminderAt != nil { height += 22 }
                return height
            }
            let capture = card.primary
            let promoted = state.isTaskAtTop(capture)
            // Top-level single-caption cards include six points of breathing
            // room on each side of their rounded frame. Automatic-hour actions
            // supply their own outer card and omit this spacing.
            let frameSpacing: CGFloat = includesSingleFrameSpacing ? 12 : 0
            // The minimized row still keeps its action controls inside the
            // frame, so reserve enough room for the complete rounded bottom
            // edge above the board footer.
            var height: CGFloat = (capture.isMinimized ? 112 : 118) + frameSpacing
            if promoted { height += 32 }
            if capture.isMinimized {
                if capture.isTask { height += 12 }
                return height
            }
            let featured = capture.id == featuredID
            let titleSize: CGFloat = featured ? 19.55 : 16.1
            let timestampWidth: CGFloat = capture.isTask ? (capture.isCompleted ? 98 : 66) : 44
            let thumbnailWidth: CGFloat = !featured && capture.kind != .text && capture.kind != .task ? 67 : 0
            let contentWidth: CGFloat = 348 - (promoted ? 20 : 0)
            let titleWidth = max(100, contentWidth - timestampWidth - 11 - thumbnailWidth)
            let titleFont = NSFont.systemFont(ofSize: titleSize, weight: .medium)
            let lineHeight = ceil(titleFont.ascender - titleFont.descender + titleFont.leading)
            let titleHeight = measuredTextHeight(capture.title.isEmpty ? "Untitled capture" : capture.title,
                                                font: titleFont, width: titleWidth, maximumLines: 3)
            height += max(0, titleHeight - lineHeight)
            if !capture.previewDescription.isEmpty {
                height += measuredTextHeight(capture.previewDescription, font: .systemFont(ofSize: 12),
                                             width: titleWidth, maximumLines: 2) + 4
            }
            if !capture.comment.isEmpty {
                height += measuredTextHeight(capture.comment, font: .systemFont(ofSize: 12),
                                             width: contentWidth, maximumLines: 2) + 7
            }
            if capture.reminderAt != nil { height += 22 }
            if capture.kind == .link && !promoted { height += 18 }
            return height
        }

        let rows = feed.reduce(CGFloat.zero) { total, item in
            switch item {
            case .capture(let card):
                return total + cardHeight(card)
            case .automaticHour(let group):
                guard state.isHourlyGroupExpanded(group.id) else {
                    return total + CollectionPreviewLayout.previewHeight(compact: false) + 134
                }
                let actions = group.actions.reduce(CGFloat.zero) { partial, action in
                    partial + action.cards.reduce(CGFloat.zero) {
                        $0 + cardHeight($1, includesSingleFrameSpacing: false)
                    } + 34
                }
                return total + 58 + actions
            }
        }
        return min(560, max(380, 235 + rows + (featuredID == nil ? 0 : 125) + extra))
    }

    private static func measuredTextHeight(_ text: String, font: NSFont, width: CGFloat, maximumLines: Int) -> CGFloat {
        let lineHeight = ceil(font.ascender - font.descender + font.leading)
        let bounds = (text as NSString).boundingRect(with: NSSize(width: width, height: .greatestFiniteMagnitude),
                                                   options: [.usesLineFragmentOrigin, .usesFontLeading],
                                                   attributes: [.font: font])
        return min(CGFloat(maximumLines) * lineHeight, max(lineHeight, ceil(bounds.height)))
    }

    static func corner(at point: NSPoint, in frame: NSRect, threshold: CGFloat = 9) -> ScreenCorner? {
        guard frame.insetBy(dx: -1, dy: -1).contains(point) else { return nil }
        let left = point.x <= frame.minX + threshold
        let right = point.x >= frame.maxX - threshold
        let bottom = point.y <= frame.minY + threshold
        let top = point.y >= frame.maxY - threshold
        if left && bottom { return .bottomLeft }
        if right && bottom { return .bottomRight }
        if left && top { return .topLeft }
        if right && top { return .topRight }
        return nil
    }

    /// The physical camera cutout is the gap between macOS' two usable menu-bar
    /// areas. Display names and model lists are intentionally not used.
    static func cameraIslandRect(frame: NSRect, safeAreaTop: CGFloat,
                                 auxiliaryLeft: NSRect?, auxiliaryRight: NSRect?) -> NSRect? {
        guard safeAreaTop.isFinite, safeAreaTop > 0,
              let left = auxiliaryLeft, let right = auxiliaryRight,
              left.maxX.isFinite, right.minX.isFinite,
              right.minX - left.maxX >= 24 else { return nil }
        let bottom = max(frame.minY, frame.maxY - safeAreaTop)
        let candidate = NSRect(x: left.maxX, y: bottom,
                               width: right.minX - left.maxX,
                               height: min(safeAreaTop, frame.height))
        guard candidate.width > 0, candidate.height > 0,
              frame.insetBy(dx: -1, dy: -1).contains(NSPoint(x: candidate.midX, y: candidate.midY)) else { return nil }
        return candidate
    }

    static func cameraIslandRect(on screen: NSScreen) -> NSRect? {
        cameraIslandRect(frame: screen.frame, safeAreaTop: screen.safeAreaInsets.top,
                         auxiliaryLeft: screen.auxiliaryTopLeftArea,
                         auxiliaryRight: screen.auxiliaryTopRightArea)
    }

    static func cameraIslandTriggerFrame(on screen: NSScreen) -> NSRect? {
        cameraIslandRect(on: screen).map {
            $0.insetBy(dx: -10, dy: 0).union(NSRect(x: $0.minX - 10, y: $0.minY - 12,
                                                   width: $0.width + 20, height: 12))
        }
    }

    static func revealTarget(at point: NSPoint, on screen: NSScreen, home: RobotHome) -> RobotRevealTarget? {
        if home == .cameraIsland {
            if let trigger = cameraIslandTriggerFrame(on: screen) {
                return trigger.contains(point) ? .cameraIsland : nil
            }
            return corner(at: point, in: screen.frame) == .topRight ? .corner(.topRight) : nil
        }
        return corner(at: point, in: screen.frame).map(RobotRevealTarget.corner)
    }

    static func robotFrame(corner: ScreenCorner, visible: NSRect) -> NSRect {
        let size = NSSize(width: min(72, visible.width), height: min(88, visible.height))
        return NSRect(x: corner.isRight ? visible.maxX - size.width - 3 : visible.minX + 3,
                      y: corner.isTop ? visible.maxY - size.height - 3 : visible.minY + 3,
                      width: size.width, height: size.height)
    }

    static func robotFrame(cameraIsland: NSRect, visible: NSRect) -> NSRect {
        let size = NSSize(width: min(232, visible.width), height: min(150, visible.height))
        // Borderless NSWindows resolve their origin to whole display points.
        // Match that placement up front so geometry and the actual panel agree.
        let idealX = floor(cameraIsland.midX - size.width / 2)
        return NSRect(x: min(max(idealX, visible.minX), visible.maxX - size.width),
                      y: max(visible.minY, min(visible.maxY, cameraIsland.minY) - size.height),
                      width: size.width, height: size.height)
    }

    /// Island choreography has room to swing, but its transparent side margins
    /// must never become a larger mouse or drop destination.
    static func robotInteractionFrame(in stage: NSRect, target: RobotRevealTarget) -> NSRect {
        guard target == .cameraIsland else { return stage }
        let size = NSSize(width: min(128, stage.width), height: min(130, stage.height))
        return NSRect(x: stage.midX - size.width / 2, y: stage.maxY - size.height,
                      width: size.width, height: size.height)
    }

    /// Board expansion starts at the central body, not at the swept animation
    /// envelope. This also keeps its initial placement below the visible body.
    static func robotBodyFrame(in stage: NSRect, target: RobotRevealTarget) -> NSRect {
        guard target == .cameraIsland else { return stage }
        let size = NSSize(width: min(88, stage.width), height: min(108, stage.height))
        let topInset = min(8, max(0, stage.height - size.height))
        return NSRect(x: stage.midX - size.width / 2, y: stage.maxY - topInset - size.height,
                      width: size.width, height: size.height)
    }

    static func robotFrame(target: RobotRevealTarget, on screen: NSScreen) -> NSRect {
        switch target {
        case .corner(let corner): return robotFrame(corner: corner, visible: screen.visibleFrame)
        case .cameraIsland:
            let island = cameraIslandRect(on: screen)
                ?? NSRect(x: screen.frame.midX, y: screen.visibleFrame.maxY, width: 0, height: 0)
            if let layout = QuietOrbitLayout(cameraIsland: island, displayFrame: screen.frame) {
                return layout.panelFrame
            }
            return robotFrame(cameraIsland: island, visible: screen.visibleFrame)
        }
    }

    static func panelFrame(robot: NSRect, visible: NSRect, corner: ScreenCorner, preferredHeight: CGFloat = 500) -> NSRect {
        let width = min(400, max(280, visible.width - 16))
        let height = min(preferredHeight, max(240, visible.height - 16))
        var frame = NSRect(x: corner.isRight ? robot.maxX - width : robot.minX,
                           y: corner.isTop ? robot.minY - height - 6 : robot.maxY + 6,
                           width: min(width, visible.width), height: min(height, visible.height))
        frame.origin.x = min(max(frame.minX, visible.minX), visible.maxX - frame.width)
        frame.origin.y = min(max(frame.minY, visible.minY), visible.maxY - frame.height)
        return frame
    }

    static func panelFrame(robot: NSRect, visible: NSRect, target: RobotRevealTarget,
                           preferredHeight: CGFloat = 500) -> NSRect {
        guard target == .cameraIsland else {
            if case .corner(let corner) = target {
                return panelFrame(robot: robot, visible: visible, corner: corner, preferredHeight: preferredHeight)
            }
            return panelFrame(robot: robot, visible: visible, corner: .bottomRight, preferredHeight: preferredHeight)
        }
        let width = min(400, max(280, visible.width - 16))
        let height = min(preferredHeight, max(240, visible.height - 16))
        var frame = NSRect(x: robot.midX - width / 2, y: robot.minY - height - 6,
                           width: min(width, visible.width), height: min(height, visible.height))
        frame.origin.x = min(max(frame.minX, visible.minX), visible.maxX - frame.width)
        frame.origin.y = min(max(frame.minY, visible.minY), visible.maxY - frame.height)
        return frame
    }

    /// Keep the header at the user's chosen point when the board changes height.
    static func movedPanelFrame(topLeft: NSPoint, visible: NSRect, preferredHeight: CGFloat) -> NSRect {
        let size = panelFrame(robot: .zero, visible: visible, corner: .bottomLeft, preferredHeight: preferredHeight).size
        return NSRect(x: min(max(topLeft.x, visible.minX), visible.maxX - size.width),
                      y: min(max(topLeft.y - size.height, visible.minY), visible.maxY - size.height),
                      width: size.width, height: size.height)
    }

    /// A filtered board keeps its header still. Extra content scrolls when
    /// there is no more room below the header on this display.
    static func filterPanelFrame(current: NSRect, visible: NSRect, preferredHeight: CGFloat) -> NSRect {
        let width = min(max(0, current.width), max(0, visible.width))
        let top = min(max(current.maxY, visible.minY), visible.maxY)
        let height = min(max(0, preferredHeight), max(0, top - visible.minY))
        return NSRect(x: min(max(current.minX, visible.minX), visible.maxX - width),
                      y: top - height, width: width, height: height)
    }

    static func shouldAnimateFilterTransition(from previous: BoardRoute?, to next: BoardRoute,
                                             previousFilter: CaptureFilter?, filter: CaptureFilter,
                                             visible: Bool, reduceMotion: Bool) -> Bool {
        visible && !reduceMotion && previous == next && (next == .daily || next == .search)
            && previousFilter != nil && previousFilter != filter
    }

    /// Open away from the closest display edge. The compact board's edge stays
    /// fixed whenever the display has enough room for the expanded view.
    static func weeklyExpansionDirection(compact: NSRect, visible: NSRect) -> WeeklyExpansionDirection {
        let leftRoom = max(0, compact.minX - visible.minX)
        let rightRoom = max(0, visible.maxX - compact.maxX)
        return leftRoom > rightRoom ? .left : .right
    }

    static func compactTopLeft(weeklyFrame: NSRect, compactWidth: CGFloat, direction: WeeklyExpansionDirection) -> NSPoint {
        NSPoint(x: direction == .left ? weeklyFrame.maxX - compactWidth : weeklyFrame.minX,
                y: weeklyFrame.maxY)
    }

    static func shouldAnimateWeeklyTransition(from previous: BoardRoute?, to next: BoardRoute,
                                             visible: Bool, reduceMotion: Bool) -> Bool {
        visible && !reduceMotion && previous != nil && previous != next && (previous == .weekly || next == .weekly)
    }
}

class DaBinPanel: NSPanel {
    /// The real camera stage may use drawable pixels beside the menu bar.
    /// Ordinary app windows keep AppKit's normal visible-frame constraints.
    var cameraStageDisplayFrame: NSRect?
    override func constrainFrameRect(_ frameRect: NSRect, to screen: NSScreen?) -> NSRect {
        guard let display = cameraStageDisplayFrame else { return super.constrainFrameRect(frameRect, to: screen) }
        var frame = frameRect
        frame.size.width = min(frame.width, display.width)
        frame.size.height = min(frame.height, display.height)
        frame.origin.x = min(max(frame.minX, display.minX), display.maxX - frame.width)
        frame.origin.y = min(max(frame.minY, display.minY), display.maxY - frame.height)
        return frame
    }
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

@MainActor
final class CornerController: NSObject {
    let state: AppState
    let input: InputService
    let robot: RobotView
    let bin: DaBinPanel
    let board: DailyCapturePanel
    let captureHostingView: DailyCaptureHostingView
    let appFrame: RobotAppFrameView
    private(set) var robotLifecycle = RobotLifecycle()
    var onWillOpenBoard: (() -> Void)?
    var onDidCloseBoard: (() -> Void)?
    var onRobotInteractionBegan: (() -> Void)?
    var onRobotInteractionEnded: (() -> Void)?
    var onProjectRecordingChanged: ((String?, Bool) -> Void)?
    var onPointerSample: ((NSPoint) -> Void)?
    var companionRevealTarget: RobotRevealTarget { activeTarget }
    private var restoreBoardAfterDisplayLoss = false
    var isCaptureRobotVisible: () -> Bool = { false }
    var isTaskTimerRobotVisible: () -> Bool = { false }
    private let animateRobotTransitions: Bool
    private let robotReduceMotion: () -> Bool
    private var robotTransitionSerial: UInt64 = 0
    private var robotTransitionTarget: NSRect?
    private var robotTransitionSource: NSRect?
    private var robotTransitionTask: Task<Void, Never>?
    private struct RobotTransitionRecovery {
        let serial: UInt64
        let deadline: TimeInterval
        let opening: Bool
    }
    private var robotTransitionRecovery: RobotTransitionRecovery?
    private var idlePeekTask: Task<Void, Never>?
    private var orbitDwell = QuietOrbitPerchDwell()
    private var companionEncounter = RobotCompanionEncounter()
    private var companionEncounterActive = false
    private var idlePeeking = false
    private var timer: Timer?
    private(set) var isShutDown = false
    private var activeScreen: NSScreen?
    private var activeTarget: RobotRevealTarget = .corner(.bottomRight)
    private var dragActive = false
    private var saving = false
    private var lastInteraction = Date.distantPast
    private var feedbackUntil = Date.distantPast
    private var keyboardHold = false
    private var hoverFocus = false
    private var focusPoint = NSPoint.zero
    private var suppressUntilExit = false
    private var escapeMonitor: Any?
    private var localPointerMonitor: Any?
    private var globalPointerMonitor: Any?
    private var message: NSPopover?
    private var messageExpiry: Task<Void, Never>?
    private var layoutSubscription: AnyCancellable?
    private var placementSubscription: AnyCancellable?
    private var appearanceSubscription: AnyCancellable?
    private var tooltipSubscription: AnyCancellable?
    private var projectRecordingSubscription: AnyCancellable?
    private var recordingInteractionActive = false
    private struct RecordingSignState: Equatable {
        let project: String?
        let colorHex: String?
        let enabled: Bool
        let paused: Bool
        let status: String?
    }
    private var recordingSignState: RecordingSignState?
    var hasPersistentProjectRecording: Bool { robot.recordingProjectName != nil }
    private var emittedCapturePause: Bool?
    private var isRobotPresentationPaused: Bool { emittedCapturePause ?? state.autoCapture.settings.isPaused }
    private let appearanceSettings: ThemeSettings
    private let placementDefaults: UserDefaults?
    private var boardTopLeft: NSPoint?
    private var boardDragStartFrame: NSRect?
    private var boardInteractionTimer: Timer?
    private var boardIsResizing = false
    private var userBoardSize: CGSize?
    private var workspaceZoomGeometry: WorkspaceZoomGeometry?
    private var workspaceZoomChangedGeometry = false
    private var workspaceZoomOwnsNormalSize = false
    private var frameBeforeExpansion: NSRect?
    /// Week automatically borrows the expanded presentation. Other routes
    /// retain their normal geometry when that temporary presentation ends.
    private var expansionBelongsToWeek = false
    private var workingApplication: NSRunningApplication?
    private var applyingBoardFrame = false
    private var lastAppliedBoardFrame: NSRect?
    private(set) var boardFrameApplicationCount = 0
    private var lastLayoutRoute: BoardRoute?
    private var lastLayoutFilter: CaptureFilter?
    private var weeklyDirection: WeeklyExpansionDirection?
    /// A Week stretch is temporary and must not replace the user's normal
    /// window size. Choosing other dates reopens full view; changing captures
    /// or filtering cards keeps the chosen geometry.
    private var weeklyUserSize: CGSize?
    private struct WeeklyLayoutKey: Equatable {
        let selectedDays: [Date]
    }
    private var lastWeeklyLayoutKey: WeeklyLayoutKey?
    private var boardFrameAnimation: Timer?
    private var boardAnimationTarget: NSRect?
    private enum BoardFrameAnimationKind: Equatable { case weekly, filter }
    private var boardAnimationKind: BoardFrameAnimationKind?
    static let filterResizeDuration: TimeInterval = 0.38
    static let boardPlacementKey = "DaBin.boardTopLeft.v1"
    static let boardSizeKey = "DaBin.boardUserSize.v1"
    static let boardZoomSizeKey = "DaBin.boardWorkspaceZoomSized.v1"

    init(state: AppState, input: InputService, placementDefaults: UserDefaults? = .standard,
         theme: ThemeSettings? = nil, animateRobotTransitions: Bool = true,
         robotReduceMotion: @escaping () -> Bool = { NSWorkspace.shared.accessibilityDisplayShouldReduceMotion }) {
        self.state = state; self.input = input
        self.animateRobotTransitions = animateRobotTransitions
        let motionPreference = { robotReduceMotion() || state.quickAccessSettings.quietMode }
        self.robotReduceMotion = motionPreference
        robot = RobotView(frame: NSRect(x: 0, y: 0, width: 72, height: 88), reduceMotion: motionPreference)
        let appearanceSettings = theme ?? ThemeSettings()
        self.appearanceSettings = appearanceSettings
        captureHostingView = DailyCaptureHostingView(state: state, theme: appearanceSettings)
        appFrame = RobotAppFrameView(contentView: captureHostingView)
        self.placementDefaults = placementDefaults
        if let point = placementDefaults?.array(forKey: Self.boardPlacementKey) as? [Double],
           point.count == 2, point.allSatisfy({ $0.isFinite }) {
            boardTopLeft = NSPoint(x: point[0], y: point[1])
        }
        if let size = placementDefaults?.array(forKey: Self.boardSizeKey) as? [Double],
           size.count == 2, size.allSatisfy({ $0.isFinite && $0 > 0 }) {
            userBoardSize = CGSize(width: max(BoardResizeGeometry.minimumSize.width, size[0]),
                                   height: max(BoardResizeGeometry.minimumSize.height, size[1]))
        }
        workspaceZoomOwnsNormalSize = userBoardSize != nil
            && (placementDefaults?.bool(forKey: Self.boardZoomSizeKey) ?? false)
        bin = DaBinPanel(contentRect: NSRect(x: 0, y: 0, width: 72, height: 88), styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        board = DailyCapturePanel(contentRect: NSRect(x: 0, y: 0, width: 380, height: 500), styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        super.init()
        configure(bin, shadow: false)
        configure(board, shadow: true)
        bin.title = "DaBin robot"
        board.title = "DaBin Daily"
        bin.contentView = robot
        let hosting = captureHostingView
        board.captureHostingView = hosting
        board.contentView = appFrame
        appFrame.autoresizingMask = [.width, .height]
        board.minSize = BoardResizeGeometry.minimumSize
        appFrame.onResizeStarted = { [weak self] in self?.beginBoardResize() }
        appFrame.onResize = { [weak self] frame in self?.resizeBoardFromUser(to: frame) }
        appFrame.onResizeEnded = { [weak self] in self?.finishBoardResize() }
        appFrame.onToggleExpanded = { [weak self] in self?.toggleExpandedWindow() }
        state.workspaceZoom.onInteractionBegan = { [weak self] in self?.beginWorkspaceZoom() ?? false }
        state.workspaceZoom.onFactorChanged = { [weak self] factor in self?.applyWorkspaceZoom(factor) }
        state.workspaceZoom.onInteractionEnded = { [weak self] in self?.finishWorkspaceZoom() }
        state.workspaceZoom.onCouplingChanged = { [weak self] in self?.rebaseWorkspaceZoom() }
        appFrame.onDragStarted = { [weak self] in self?.beginBoardDrag() }
        appFrame.onDragEnded = { [weak self] point in
            self?.finishBoardDragIfReleased(pressedMouseButtons: 0, pointer: point)
        }
        // A hosting view nested in the robot frame is not the window root.
        // SwiftUI's preferredColorScheme alone does not update the AppKit
        // appearance in this arrangement, including native text/date controls.
        appearanceSubscription = appearanceSettings.$darkModeEnabled.sink { [weak self] dark in
            guard let self else { return }
            Self.applyBoardAppearance(darkMode: dark, to: self.board,
                                      frame: self.appFrame, hosting: self.captureHostingView)
        }
        tooltipSubscription = appearanceSettings.$showTooltips.sink { [weak self] enabled in
            self?.robot.showTooltips = enabled
        }
        hosting.onPaste = { [weak self] in self?.receiveOnDaily(.general) }
        hosting.onDrop = { [weak self] pasteboard in self?.receiveOnDaily(pasteboard) }
        hosting.onDragState = { [weak state] active in
            if active { state?.workspaceZoom.finishInteraction() }
            if state?.isDailyDropTargeted != active { state?.isDailyDropTargeted = active }
        }
        robot.onPaste = { [weak self] in self?.input.paste() }
        robot.onDaily = { [weak self] in self?.openFromRobot() }
        robot.onDrop = { [weak self] pasteboard in self?.input.receive(pasteboard) }
        robot.onDragState = { [weak self] active in
            self?.dragActive = active
            if active { self?.companionEncounter.reset(); self?.companionEncounterActive = false }
            if active, let self { self.orbitDwell.reset(to: self.robot.orbitPerch) }
            self?.lastInteraction = Date()
            self?.updateHoverFocus(at: NSEvent.mouseLocation, pressedMouseButtons: NSEvent.pressedMouseButtons)
        }
        robot.onHoverChange = { [weak self] in
            self?.updateHoverFocus(at: NSEvent.mouseLocation, pressedMouseButtons: NSEvent.pressedMouseButtons)
        }
        robot.onFocus = { [weak self] in
            self?.beginProjectRecordingInteraction()
            self?.keyboardHold = true; self?.focusPoint = NSEvent.mouseLocation; self?.lastInteraction = Date()
        }
        input.onBusy = { [weak self] busy in
            self?.saving = busy; self?.robot.isSaving = busy
            if busy { self?.companionEncounter.reset(); self?.companionEncounterActive = false }
            if busy, let self { self.orbitDwell.reset(to: self.robot.orbitPerch) }
        }
        input.onResult = { [weak self] captures, errors in self?.received(captures, errors: errors) }
        state.onDismiss = { [weak self] in self?.dismiss() }
        board.onRequestClose = { [weak self] in self?.dismiss() }
        state.onBoardDragStarted = { [weak self] in self?.beginBoardDrag() }
        state.onBoardDragEnded = { [weak self] point in
            self?.finishBoardDragIfReleased(pressedMouseButtons: 0, pointer: point)
        }
        layoutSubscription = state.objectWillChange.debounce(for: .milliseconds(40), scheduler: RunLoop.main).sink { [weak self] _ in
            MainActor.assumeIsolated { self?.resizeBoard() }
        }
        placementSubscription = state.robotPlacement.$home.dropFirst().sink { [weak self] _ in
            MainActor.assumeIsolated { self?.robotHomeChanged() }
        }
        // Published values announce before the write. Read the settled project,
        // runtime and preferences on the next main run-loop delivery.
        projectRecordingSubscription = state.objectWillChange.receive(on: RunLoop.main).sink { [weak self] _ in
            MainActor.assumeIsolated { self?.refreshProjectRecording() }
        }
        state.reminders.onOpenCapture = { [weak self] id in
            self?.state.openCapture(id); self?.showBoard()
        }
        NotificationCenter.default.addObserver(self, selector: #selector(screensChanged), name: NSApplication.didChangeScreenParametersNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(boardMoved), name: NSWindow.didMoveNotification, object: board)
        NotificationCenter.default.addObserver(self, selector: #selector(boardResignedKey), name: NSWindow.didResignKeyNotification, object: board)
        NotificationCenter.default.addObserver(self, selector: #selector(updateBoardVisibility), name: NSWindow.didChangeOcclusionStateNotification, object: board)
        NotificationCenter.default.addObserver(self, selector: #selector(updateBoardVisibility), name: NSApplication.didHideNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateBoardVisibility), name: NSApplication.didUnhideNotification, object: nil)
        NSWorkspace.shared.notificationCenter.addObserver(self, selector: #selector(accessibilityDisplayOptionsChanged),
            name: NSWorkspace.accessibilityDisplayOptionsDidChangeNotification, object: nil)
        escapeMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            if event.keyCode == 53, event.window === self?.board || event.window === self?.bin {
                // Let native popovers/pickers handle their own Escape first.
                if self?.state.onTutorialEscape?() == true { return nil }
                self?.dismiss(); return nil
            }
            return event
        }
    }

    static func applyBoardAppearance(darkMode: Bool, to window: NSWindow,
                                     frame: RobotAppFrameView, hosting: NSView) {
        let appearance = NSAppearance(named: darkMode ? .darkAqua : .aqua)
        window.appearance = appearance
        frame.appearance = appearance
        hosting.appearance = appearance
    }

    private func configure(_ panel: NSPanel, shadow: Bool) {
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = shadow
        panel.level = .floating
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        panel.hidesOnDeactivate = false
        panel.isReleasedWhenClosed = false
        panel.isMovableByWindowBackground = false
        panel.animationBehavior = .none
        panel.sharingType = .none
        panel.becomesKeyOnlyIfNeeded = false
    }

    func start(pointerPosition: @escaping () -> NSPoint = { NSEvent.mouseLocation }) {
        guard timer == nil, !isShutDown else { return }
        refreshProjectRecording()
        // Native movement updates the small input region before the next click;
        // the slower clock remains responsible for animation and retreat time.
        // Mouse-only monitors need no access to other applications' keystrokes.
        localPointerMonitor = NSEvent.addLocalMonitorForEvents(matching: [.mouseMoved, .leftMouseDragged, .leftMouseDown]) { [weak self] event in
            MainActor.assumeIsolated { self?.sampleCompanionPointer(at: pointerPosition()) }
            return event
        }
        globalPointerMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.mouseMoved, .leftMouseDragged]) { [weak self] _ in
            MainActor.assumeIsolated { self?.sampleCompanionPointer(at: pointerPosition()) }
        }
        // Global pointer position needs no global key monitor, clipboard poll or Accessibility grant.
        let timer = Timer(timeInterval: 0.10, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.pollPointer(at: pointerPosition()) }
        }
        timer.tolerance = 0.025
        RunLoop.main.add(timer, forMode: .common)
        self.timer = timer
    }

    func sampleCompanionPointer(at point: NSPoint) {
        guard !isShutDown else { return }
        onPointerSample?(point)
        updatePointerAcceptance(at: point)
    }

    /// One-way disposal removes every native event source owned by this session.
    func shutdown() {
        guard !isShutDown else { return }
        state.workspaceZoom.finishInteraction()
        isShutDown = true
        timer?.invalidate(); timer = nil
        boardInteractionTimer?.invalidate(); boardInteractionTimer = nil
        stopBoardAnimation()
        robotTransitionSerial &+= 1
        robotTransitionTask?.cancel(); robotTransitionTask = nil
        robotTransitionRecovery = nil
        idlePeekTask?.cancel(); idlePeekTask = nil
        robotLifecycle.send(.interrupt(toward: .hidden))
        appFrame.cancelTransition(open: false)
        appFrame.setVisible(false)
        appFrame.onResizeStarted = nil; appFrame.onResize = nil
        appFrame.onResizeEnded = nil; appFrame.onToggleExpanded = nil
        appFrame.onDragStarted = nil; appFrame.onDragEnded = nil
        appFrame.cancelWindowInteraction()
        onWillOpenBoard = nil; onDidCloseBoard = nil
        onRobotInteractionBegan = nil; onRobotInteractionEnded = nil
        onProjectRecordingChanged = nil
        onPointerSample = nil
        layoutSubscription?.cancel(); layoutSubscription = nil
        placementSubscription?.cancel(); placementSubscription = nil
        appearanceSubscription?.cancel(); appearanceSubscription = nil
        tooltipSubscription?.cancel(); tooltipSubscription = nil
        projectRecordingSubscription?.cancel(); projectRecordingSubscription = nil
        if let escapeMonitor { NSEvent.removeMonitor(escapeMonitor) }
        escapeMonitor = nil
        if let localPointerMonitor { NSEvent.removeMonitor(localPointerMonitor) }
        if let globalPointerMonitor { NSEvent.removeMonitor(globalPointerMonitor) }
        localPointerMonitor = nil; globalPointerMonitor = nil
        NotificationCenter.default.removeObserver(self)
        NSWorkspace.shared.notificationCenter.removeObserver(self)
        dismissMessage()
        captureHostingView.clearDropTarget()
        captureHostingView.onPaste = nil; captureHostingView.onDrop = nil; captureHostingView.onDragState = nil
        robot.onPaste = nil; robot.onDaily = nil; robot.onDrop = nil
        robot.onDragState = nil; robot.onHoverChange = nil; robot.onFocus = nil
        robot.stopFeedback()
        input.onBusy = nil; input.onResult = nil
        state.onDismiss = nil; state.onBoardDragStarted = nil; state.onBoardDragEnded = nil
        state.workspaceZoom.onInteractionBegan = nil
        state.workspaceZoom.onFactorChanged = nil
        state.workspaceZoom.onInteractionEnded = nil
        state.workspaceZoom.onCouplingChanged = nil
        state.navigationWindowInteractionBlocked = false
        state.reminders.onOpenCapture = nil
        board.orderOut(nil); bin.orderOut(nil)
        state.isBoardVisible = false; state.isDailyDropTargeted = false
        board.onRequestClose = nil
        board.contentView = nil; bin.contentView = nil
        board.close(); bin.close()
    }

    func pollPointer(at simulatedPoint: NSPoint? = nil, now: Date = Date(), pressedMouseButtons: Int = NSEvent.pressedMouseButtons) {
        if state.quickAccessSettings.quietMode { cancelIdlePeek() }
        guard !isShutDown else { return }
        if let recovery = robotTransitionRecovery, recovery.serial == robotTransitionSerial,
           robotTransitionTarget != nil, ProcessInfo.processInfo.systemUptime >= recovery.deadline {
            settleRobotTransition(open: recovery.opening)
            if recovery.opening { resizeBoard() }
        }
        if isRobotPresentationPaused { cancelIdlePeek() }
        ensureProjectRecordingRobot()
        let point = simulatedPoint ?? NSEvent.mouseLocation
        sampleCompanionPointer(at: point)
        // A persistent timer acknowledgement owns the island. Hover must not
        // reveal a second robot over its clickable clock/sign surface.
        if isTaskTimerRobotVisible() { cancelIdlePeek(); return }
        if state.isBoardVisible, let screen = activeScreen {
            appFrame.updatePointer(screenPoint: screen.frame.contains(point) ? point : nil, displayFrame: screen.frame)
        }
        guard robotTransitionTarget == nil else { return }
        if !hasPersistentProjectRecording, !board.isVisible, !saving, !dragActive,
           pressedMouseButtons == 0, !keyboardHold, now > feedbackUntil,
           !isCaptureRobotVisible(), !suppressUntilExit,
           pollCompanion(at: point, now: now) { return }
        let target = NSScreen.screens.compactMap { screen -> (NSScreen, RobotRevealTarget)? in
            guard let target = CornerGeometry.revealTarget(at: point, on: screen,
                                                           home: state.robotPlacement.home) else { return nil }
            return (screen, target)
        }.first
        if target == nil && companionApproachTarget(at: point) == nil { suppressUntilExit = false }
        // Pause suppresses unsolicited recording/receipt artwork, but the
        // deliberate approach above remains an available way to open DaBin.
        // An accepted manual drop keeps its native destination until AppKit
        // concludes it; it must not turn into a paused save celebration.
        if isRobotPresentationPaused {
            if !companionEncounterActive && !dragActive { hideRobot(force: true) }
            return
        }
        if isCaptureRobotVisible(), target == nil {
            cancelIdlePeek()
            return
        }
        // A file or text drag can reach the robot while the board stays open.
        // Moving DaBin's own header must not reveal a second surface.
        let draggingTowardCorner = pressedMouseButtons & 1 != 0 && boardDragStartFrame == nil
        if let (screen, target) = target, !suppressUntilExit,
           (!board.isVisible || draggingTowardCorner), !saving, !dragActive {
            keyboardHold = false
            reveal(on: screen, target: target, pointer: point)
            updateOrbitPerch(at: point, now: now)
            updateHoverFocus(at: point, pressedMouseButtons: pressedMouseButtons)
            lastInteraction = now
            return
        }
        guard bin.isVisible, !idlePeeking else { return }
        updateOrbitPerch(at: point, now: now)
        updateHoverFocus(at: point, pressedMouseButtons: pressedMouseButtons)
        var corridor = bin.convertToScreen(robot.convert(robot.interactionBounds, to: nil)).insetBy(dx: -12, dy: -12)
        if let screen = activeScreen {
            switch activeTarget {
            case .corner(let corner):
                let cornerPoint = NSPoint(x: corner.isRight ? screen.frame.maxX : screen.frame.minX,
                                          y: corner.isTop ? screen.frame.maxY : screen.frame.minY)
                corridor = corridor.union(NSRect(x: cornerPoint.x - 9, y: cornerPoint.y - 9, width: 18, height: 18))
            case .cameraIsland:
                if let trigger = CornerGeometry.cameraIslandTriggerFrame(on: screen) {
                    corridor = corridor.union(trigger)
                }
            }
        }
        if corridor.contains(point) || dragActive || saving {
            lastInteraction = now; return
        }
        if keyboardHold && bin.isKeyWindow && hypot(point.x - focusPoint.x, point.y - focusPoint.y) < 4 { return }
        keyboardHold = false
        // The grace interval lets the pointer cross menu-bar / Dock insets onto the robot.
        if now > feedbackUntil, now.timeIntervalSince(lastInteraction) > 0.8 {
            if !hasPersistentProjectRecording { hideRobot(animated: true) }
            else if recordingInteractionActive {
                recordingInteractionActive = false
                onRobotInteractionEnded?()
            }
        }
    }

    private func companionProximity(at point: NSPoint, screen: NSScreen,
                                    target: RobotRevealTarget) -> CGFloat? {
        guard screen.frame.contains(point) else { return nil }
        switch target {
        case .cameraIsland:
            guard let housing = CornerGeometry.cameraIslandRect(on: screen) else { return nil }
            return RobotCompanionProximity.island(point, housing: housing)
        case .corner(let corner):
            return RobotCompanionProximity.corner(point, anchor: CGPoint(
                x: corner.isRight ? screen.frame.maxX : screen.frame.minX,
                y: corner.isTop ? screen.frame.maxY : screen.frame.minY))
        }
    }

    private func companionApproachTarget(at point: NSPoint) -> (NSScreen, RobotRevealTarget, CGFloat)? {
        for screen in NSScreen.screens where screen.frame.contains(point) {
            let targets: [RobotRevealTarget] = state.robotPlacement.home == .cameraIsland
                ? [CornerGeometry.cameraIslandRect(on: screen) == nil ? .corner(.topRight) : .cameraIsland]
                : ScreenCorner.allCases.map(RobotRevealTarget.corner)
            for target in targets {
                if let proximity = companionProximity(at: point, screen: screen, target: target) {
                    return (screen, target, proximity)
                }
            }
        }
        return nil
    }

    /// The entry perch remains fixed until this encounter finishes. The cursor
    /// moves his gaze and free hand, rather than moving his native click target.
    private func pollCompanion(at point: NSPoint, now: Date) -> Bool {
        if !companionEncounterActive {
            guard let (screen, target, _) = companionApproachTarget(at: point) else { return false }
            reveal(on: screen, target: target, pointer: point, companion: true)
            companionEncounterActive = true
        }
        guard let screen = activeScreen else { return false }
        let local = robot.convert(bin.convertPoint(fromScreen: point), from: nil)
        let bounds = robot.interactionBounds
        let pointer = CGPoint(x: bounds.width > 0 ? (local.x - bounds.midX) / (bounds.width / 2) : 0,
                              y: bounds.height > 0 ? (bounds.midY - local.y) / (bounds.height / 2) : 0)
        let proximity = robot.containsInteraction(local) ? 1
            : companionProximity(at: point, screen: screen, target: activeTarget)
        let snapshot = companionEncounter.update(proximity: proximity, pointer: pointer,
            at: now.timeIntervalSinceReferenceDate, expressionOnly: robotReduceMotion())
        robot.updateCompanion(snapshot)
        updateHoverFocus(at: point, pressedMouseButtons: 0)
        if !snapshot.isVisible { hideRobot() }
        return true
    }

    /// The sign describes actual monitoring, rather than the stored preference.
    /// Pause hides the recording robot and sign without changing the selected
    /// project. A later deliberate approach can reveal the signless companion.
    func setCapturePaused(_ paused: Bool) {
        // Published values arrive before their stored setting changes. Latch
        // the emitted value before receipt/timer hide callbacks can reenter us.
        emittedCapturePause = paused
        refreshProjectRecording()
    }

    func refreshProjectRecording() {
        guard !isShutDown else { return }
        let settings = state.autoCapture.settings
        let paused = isRobotPresentationPaused
        let normalized = state.libraryProject?.trimmingCharacters(in: .whitespacesAndNewlines)
            .precomposedStringWithCanonicalMapping
        let project = normalized.flatMap { $0.isEmpty ? nil : String($0.prefix(180)) }
        let colorHex = project.flatMap { state.workspace.projectColorHex(for: $0) }
        let isRecording = settings.isEnabled && !paused
            && state.autoCapture.isRunning && settings.status == .monitoring
        let showsStatus = isRecording
        let status: String? = isRecording ? "Capturing to" : nil
        let next = RecordingSignState(project: project, colorHex: colorHex,
                                      enabled: showsStatus, paused: paused, status: status)
        guard next != recordingSignState else {
            if paused && !companionEncounterActive && !dragActive { hidePausedRobot() }
            else { ensureProjectRecordingRobot() }
            return
        }
        let enteringPause = paused && recordingSignState?.paused != true
        recordingSignState = next
        let color = colorHex.map { ProjectColorChoice.nsColor(for: $0) }
        let wasEnabled = hasPersistentProjectRecording
        robot.setProjectRecording(projectName: project, color: color, isEnabled: showsStatus,
                                  isPaused: paused, statusText: status)
        appFrame.setProjectRecording(projectName: project, color: color, isEnabled: showsStatus,
                                     isPaused: paused, statusText: status)
        onProjectRecordingChanged?(showsStatus ? project : nil, paused)
        if paused {
            if enteringPause || (!companionEncounterActive && !dragActive) { hidePausedRobot() }
            return
        }
        if !hasPersistentProjectRecording {
            if wasEnabled { hideRobot() }
            return
        }
        ensureProjectRecordingRobot()
    }

    private func ensureProjectRecordingRobot() {
        guard !isRobotPresentationPaused, hasPersistentProjectRecording, !isShutDown, !NSApp.isHidden,
              !board.isVisible, robotTransitionTarget == nil else { return }
        if isTaskTimerRobotVisible() || isCaptureRobotVisible() {
            if bin.isVisible { hideRobot() }
            return
        }
        cancelIdlePeek()
        guard let screen = activeScreen.flatMap({ old in NSScreen.screens.first { $0 == old } })
                ?? AutoCaptureRobotGeometry.livePrimaryScreen().flatMap({ primary in
                    NSScreen.screens.first {
                        ($0.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)?.uint32Value == primary.displayID
                    }
                }) ?? NSScreen.main else { return }
        let target: RobotRevealTarget
        if state.robotPlacement.home == .cameraIsland,
           CornerGeometry.cameraIslandRect(on: screen) != nil { target = .cameraIsland }
        else if state.robotPlacement.home == .corners, bin.isVisible,
                case .corner = activeTarget { target = activeTarget }
        else { target = .corner(.topRight) }
        let changed = activeScreen != screen || activeTarget != target
        activeScreen = screen
        activeTarget = target
        let frame = projectRecordingFrame(target: target, on: screen)
        let entering = !bin.isVisible || changed || robot.isOrbitRetreating || bin.frame != frame
        bin.cameraStageDisplayFrame = target == .cameraIsland ? screen.frame : nil
        if entering {
            if bin.frame != frame { bin.setFrame(frame, display: true) }
            bin.alphaValue = 1
            if target == .cameraIsland,
               let island = CornerGeometry.cameraIslandRect(on: screen),
               let layout = QuietOrbitLayout(cameraIsland: island, displayFrame: screen.frame) {
                robot.cornerCharacterFrame = nil
                robot.orbitContentOffset = CGPoint(x: layout.panelFrame.minX - frame.minX,
                                                  y: layout.panelFrame.minY - frame.minY)
                orbitDwell.reset(to: .bottom)
                robot.revealOrbit(in: layout, at: .bottom)
            } else {
                robot.cornerCharacterFrame = CGRect(x: (frame.width - 72) / 2,
                    y: RobotProjectSignView.preferredSize.height - 4, width: 72, height: 88)
                robot.orbitContentOffset = .zero
                robot.present(from: .top)
            }
            bin.orderFrontRegardless()
        }
        if entering {
            robot.needsLayout = true
            robot.layoutSubtreeIfNeeded()
        }
        updatePointerAcceptance(at: NSEvent.mouseLocation)
    }

    private func projectRecordingFrame(target: RobotRevealTarget, on screen: NSScreen) -> NSRect {
        if target == .cameraIsland {
            let original = CornerGeometry.robotFrame(target: target, on: screen)
            let lower = max(screen.frame.minY, original.minY - RobotProjectSignView.preferredSize.height)
            return CGRect(x: original.minX, y: lower, width: original.width, height: original.maxY - lower)
                .intersection(screen.frame)
        }
        let visible = screen.visibleFrame
        let size = CGSize(width: min(144, visible.width),
                          height: min(88 + RobotProjectSignView.preferredSize.height, visible.height))
        let corner: ScreenCorner
        if case .corner(let value) = target { corner = value } else { corner = .topRight }
        return CGRect(x: corner.isRight ? visible.maxX - size.width - 3 : visible.minX + 3,
                      y: corner.isTop ? visible.maxY - size.height - 3 : visible.minY + 3,
                      width: size.width, height: size.height)
    }

    private func updateHoverFocus(at point: NSPoint, pressedMouseButtons: Int) {
        updatePointerAcceptance(at: point)
        let localPoint = robot.convert(bin.convertPoint(fromScreen: point), from: nil)
        let hovering = bin.isVisible && !idlePeeking && !board.isVisible && !dragActive && pressedMouseButtons == 0
            && robot.hoverBounds.contains(localPoint) && robot.containsInteraction(localPoint)
        if hovering {
            guard !hoverFocus else { return }
            beginProjectRecordingInteraction()
            hoverFocus = true
            // A nonactivating panel accepts keys without activating DaBin or
            // observing other applications' keyboard events.
            bin.makeKey()
            bin.makeFirstResponder(robot)
        } else {
            releaseHoverFocus()
        }
    }

    private func updatePointerAcceptance(at point: NSPoint) {
        let ignoresPointer: Bool
        if idlePeeking {
            ignoresPointer = true
        } else if (activeTarget != .cameraIsland && !hasPersistentProjectRecording) || dragActive {
            // AppKit owns an accepted transfer until its conclusion callback.
            // Do not withdraw the whole destination window during that transfer.
            ignoresPointer = false
        } else {
            let localPoint = robot.convert(bin.convertPoint(fromScreen: point), from: nil)
            ignoresPointer = !robot.containsInteraction(localPoint)
        }
        if bin.ignoresMouseEvents != ignoresPointer { bin.ignoresMouseEvents = ignoresPointer }
    }

    private func releaseHoverFocus() {
        // Ordering the destination out in a drag callback can cancel AppKit's
        // transfer. Release any previous hover focus after the drag ends.
        guard !dragActive else { return }
        guard hoverFocus else { return }
        hoverFocus = false
        guard !keyboardHold, bin.isVisible, bin.isKeyWindow else { return }
        // Ordering out releases a nonactivating panel's keyboard focus. Bring
        // the peek back without key status for the existing retreat grace.
        // NSWindow.resignKey() is an override hook, not a callable focus API.
        bin.orderOut(nil)
        bin.orderFrontRegardless()
    }

    private func beginProjectRecordingInteraction() {
        guard hasPersistentProjectRecording, !recordingInteractionActive else { return }
        recordingInteractionActive = true
        onRobotInteractionBegan?()
    }

    func reveal(on screen: NSScreen, corner: ScreenCorner, focus: Bool = false) {
        reveal(on: screen, target: .corner(corner), focus: focus)
    }

    func reveal(on screen: NSScreen, target: RobotRevealTarget, focus: Bool = false, pointer: NSPoint? = nil,
                companion: Bool = false) {
        guard !isShutDown, (!isRobotPresentationPaused || companion), robotTransitionTarget == nil else { return }
        if !companion { companionEncounter.reset(); companionEncounterActive = false }
        let initializingCompanion = companion && !companionEncounterActive
        cancelIdlePeek()
        if hasPersistentProjectRecording { beginProjectRecordingInteraction() }
        else { onRobotInteractionBegan?() }
        let frame = hasPersistentProjectRecording ? projectRecordingFrame(target: target, on: screen)
            : CornerGeometry.robotFrame(target: target, on: screen)
        let changed = activeScreen != screen || activeTarget != target
        if changed { releaseHoverFocus() }
        // A new drop corner must not relocate an already-open board when the
        // incoming capture resizes it. This is only an in-memory anchor; the
        // user's saved placement still changes exclusively through header drag.
        if board.isVisible, boardTopLeft == nil {
            boardTopLeft = NSPoint(x: board.frame.minX, y: board.frame.maxY)
        }
        activeScreen = screen; activeTarget = target
        robot.cornerCharacterFrame = hasPersistentProjectRecording && target != .cameraIsland
            ? CGRect(x: (frame.width - 72) / 2, y: RobotProjectSignView.preferredSize.height - 4,
                     width: 72, height: 88) : nil
        let original = CornerGeometry.robotFrame(target: target, on: screen)
        robot.orbitContentOffset = hasPersistentProjectRecording && target == .cameraIsland
            ? CGPoint(x: original.minX - frame.minX, y: original.minY - frame.minY) : .zero
        if !bin.isVisible || changed || robot.isOrbitRetreating || initializingCompanion {
            let entering = !bin.isVisible
            bin.cameraStageDisplayFrame = target == .cameraIsland ? screen.frame : nil
            bin.setFrame(frame, display: true)
            bin.alphaValue = 1
            bin.orderFrontRegardless()
            if entering || changed || robot.isOrbitRetreating || initializingCompanion {
                let entrance: RobotEntrance
                switch target {
                case .corner(let corner): entrance = corner.isRight ? .right : .left
                case .cameraIsland: entrance = .top
                }
                if target == .cameraIsland,
                   let island = CornerGeometry.cameraIslandRect(on: screen),
                   let layout = QuietOrbitLayout(cameraIsland: island, displayFrame: screen.frame) {
                    let perch: QuietOrbitPerch = hasPersistentProjectRecording ? .bottom
                        : layout.perch(at: pointer ?? NSEvent.mouseLocation)
                    orbitDwell = QuietOrbitPerchDwell(current: perch)
                    if companion { robot.presentCompanion(from: entrance, orbit: layout, perch: perch) }
                    else { robot.revealOrbit(in: layout, at: perch) }
                }
                else if companion { robot.presentCompanion(from: entrance) }
                else { robot.present(from: entrance) }
            }
        }
        updatePointerAcceptance(at: NSEvent.mouseLocation)
        if focus {
            keyboardHold = true
            focusPoint = NSEvent.mouseLocation
            NSApp.activate(ignoringOtherApps: true)
            bin.makeKeyAndOrderFront(nil)
            bin.makeFirstResponder(robot)
        }
    }

    private func updateOrbitPerch(at point: NSPoint, now: Date) {
        guard !companionEncounterActive else { return }
        guard !hasPersistentProjectRecording else { orbitDwell.cancel(); return }
        guard let layout = robot.orbitLayout, !saving, !dragActive,
              !robot.isOrbitRetreating, now > feedbackUntil,
              layout.panelFrame.contains(point) else { orbitDwell.cancel(); return }
        if let perch = orbitDwell.observe(layout.perch(at: point), at: now.timeIntervalSinceReferenceDate) {
            robot.relocateOrbit(to: perch)
        }
    }

    func focusRobot() {
        guard !isShutDown else { return }
        if isRobotPresentationPaused { showBoard(immediate: true); return }
        guard let screen = NSScreen.screens.first(where: { $0.frame.contains(NSEvent.mouseLocation) }) ?? NSScreen.main else { return }
        if hasPersistentProjectRecording { beginProjectRecordingInteraction() }
        else { onRobotInteractionBegan?() }
        settleRobotTransition(open: false)
        let target: RobotRevealTarget = state.robotPlacement.home == .cameraIsland
            && CornerGeometry.cameraIslandRect(on: screen) != nil ? .cameraIsland : .corner(.topRight)
        reveal(on: screen, target: target, focus: true)
        lastInteraction = Date()
    }

    // Opening the buddy resumes the current work; the Activity command is the
    // explicit way to reset to today's receipt timeline.
    func openDaily() { showBoard() }
    func openSearch() { state.performSearchCommand(); showBoard(immediate: true) }

    func celebrateTaskCompletion() {
        guard !isShutDown else { return }
        if board.isVisible && !NSApp.isHidden && board.occlusionState.contains(.visible) {
            appFrame.celebrateTaskCompletion(reduceMotion: robotReduceMotion())
        }
    }

    /// Expands within the current display's safe area, preserving the current
    /// Space. The second invocation restores the user's exact prior geometry.
    func toggleExpandedWindow() {
        guard board.isVisible, let screen = boardScreen(), !isShutDown else { return }
        state.workspaceZoom.finishInteraction()
        if robotTransitionTarget != nil { settleRobotTransition(open: true) }
        stopBoardAnimation()
        let target: NSRect
        if let previous = frameBeforeExpansion {
            target = BoardResizeGeometry.fitted(previous, visible: screen.visibleFrame,
                                                minimum: userBoardSize == nil ? .zero : nil)
            frameBeforeExpansion = nil
            expansionBelongsToWeek = false
            // Automatic layouts retain their compact anchor, even when the
            // route changed while expanded from a left-opening Week.
            if state.route == .weekly {
                weeklyUserSize = target.size
            } else if userBoardSize != nil {
                userBoardSize = target.size
                boardTopLeft = NSPoint(x: target.minX, y: target.maxY)
            }
        } else {
            frameBeforeExpansion = board.frame
            expansionBelongsToWeek = state.route == .weekly
            target = screen.visibleFrame
        }
        setBoardFrame(target)
        rebaseWorkspaceZoom()
        // Expansion is a temporary presentation. Keep the normal geometry on
        // disk so a relaunch or a display change always has a usable restore.
    }

    /// An explicit global shortcut can reopen the existing route without
    /// losing a draft. Hidden windows open expanded; visible windows restore
    /// or expand using the same geometry as the header control.
    func toggleExpandedWindowFromShortcut() {
        guard !isShutDown, !state.isTutorialPresented, boardDragStartFrame == nil,
              !boardIsResizing, board.attachedSheet == nil, NSApp.modalWindow == nil else { return }
        let wasVisible = board.isVisible && !NSApp.isHidden
        showBoard(immediate: true)
        guard board.isVisible else { return }
        if wasVisible || frameBeforeExpansion == nil { toggleExpandedWindow() }
    }

    /// Pause/resume never changes the selected capture sources or project.
    /// An unconfigured source opens the existing setup after navigation safety
    /// checks; pausing remains available even while a draft is invalid.
    func toggleRecordingFromShortcut() {
        guard !isShutDown, !state.isTutorialPresented else { return }
        let needsSetup = !state.autoCapture.settings.isEnabled
        if needsSetup {
            guard !state.isNavigationBlocked, board.attachedSheet == nil, NSApp.modalWindow == nil,
                  (board.firstResponder as? NSTextView)?.hasMarkedText() != true else { return }
        }
        state.toggleAutoCaptureFromHeader()
        if needsSetup, state.route == .settings { showBoard(immediate: true) }
    }

    private func beginBoardResize() {
        state.workspaceZoom.finishInteraction()
        if robotTransitionTarget != nil { settleRobotTransition(open: true) }
        stopBoardAnimation()
        boardIsResizing = true
        updateNavigationInteractionState()
        frameBeforeExpansion = nil
        expansionBelongsToWeek = false
        startBoardInteractionWatchdog()
    }

    func resizeBoardFromUser(to frame: NSRect) {
        guard !isShutDown, board.isVisible, let screen = boardScreen() else { return }
        let fitted = BoardResizeGeometry.fitted(frame, visible: screen.visibleFrame)
        frameBeforeExpansion = nil
        expansionBelongsToWeek = false
        if state.route == .weekly {
            weeklyUserSize = fitted.size
            let normalWidth = normalBoardFrame(on: screen).width
            boardTopLeft = CornerGeometry.compactTopLeft(weeklyFrame: fitted, compactWidth: normalWidth,
                                                         direction: weeklyDirection ?? .right)
        } else {
            userBoardSize = fitted.size
            boardTopLeft = NSPoint(x: fitted.minX, y: fitted.maxY)
        }
        setBoardFrame(fitted)
    }

    func finishBoardResize() {
        if boardIsResizing { cancelNativeBoardInteraction() }
        boardInteractionTimer?.invalidate(); boardInteractionTimer = nil
        boardIsResizing = false
        updateNavigationInteractionState()
        rebaseWorkspaceZoom()
        persistBoardSize()
        rememberBoardPosition()
    }

    /// This lifecycle deliberately never calls beginBoardResize: pinching an
    /// expanded board must not discard its saved Restore frame.
    private func beginWorkspaceZoom() -> Bool {
        guard !isShutDown, board.isVisible, robotTransitionTarget == nil,
              boardDragStartFrame == nil, !boardIsResizing,
              board.attachedSheet == nil, NSApp.modalWindow == nil,
              let _ = boardScreen() else { return false }
        stopBoardAnimation()
        workspaceZoomChangedGeometry = false
        if workspaceZoomGeometry == nil || !workspaceZoomOwnsNormalSize { rebaseWorkspaceZoom() }
        WorkspaceZoomViewport.begin(in: board, anchorInWindow: state.workspaceZoom.anchorInWindow)
        return true
    }

    private func applyWorkspaceZoom(_ factor: CGFloat) {
        guard state.workspaceZoom.isInteracting,
              state.workspaceZoom.resizeWindowWithZoom,
              frameBeforeExpansion == nil, !board.styleMask.contains(.fullScreen),
              let screen = boardScreen(),
              let frame = workspaceZoomGeometry?.frame(at: factor, visible: screen.visibleFrame) else { return }
        workspaceZoomChangedGeometry = true
        if state.route == .weekly {
            weeklyUserSize = frame.size
            boardTopLeft = CornerGeometry.compactTopLeft(weeklyFrame: frame,
                compactWidth: normalBoardFrame(on: screen).width, direction: weeklyDirection ?? .right)
        } else {
            workspaceZoomOwnsNormalSize = true
            userBoardSize = frame.size
            boardTopLeft = CGPoint(x: frame.minX, y: frame.maxY)
        }
        activeScreen = screen
        setBoardFrame(frame)
    }

    private func finishWorkspaceZoom() {
        WorkspaceZoomViewport.end(in: board)
        state.workspaceZoom.anchorInWindow = nil
        guard workspaceZoomChangedGeometry else { return }
        workspaceZoomChangedGeometry = false
        if state.route == .weekly {
            rememberBoardPosition()
            return
        }
        persistBoardSize()
        placementDefaults?.set(true, forKey: Self.boardZoomSizeKey)
        if let point = boardTopLeft {
            placementDefaults?.set([Double(point.x), Double(point.y)], forKey: Self.boardPlacementKey)
        }
        // Preserve the original reference through clamping. Replacing it with
        // this fitted endpoint would make 100 → 200 → 100 drift on every cycle.
    }

    private func rebaseWorkspaceZoom() {
        workspaceZoomGeometry = WorkspaceZoomGeometry(frame: frameBeforeExpansion ?? board.frame,
                                                       factor: state.workspaceZoom.factor)
    }

    @objc private func boardResignedKey() { cancelBoardInteraction() }

    private func updateNavigationInteractionState() {
        let blocked = boardDragStartFrame != nil || boardIsResizing || robotTransitionTarget != nil
        if state.navigationWindowInteractionBlocked != blocked {
            state.navigationWindowInteractionBlocked = blocked
        }
    }

    private func persistBoardSize() {
        guard let size = userBoardSize else { return }
        placementDefaults?.set([Double(size.width), Double(size.height)], forKey: Self.boardSizeKey)
    }

    private func openFromRobot() {
        // An explicit interaction wins over a position saved on another display.
        if let screen = activeScreen, let topLeft = boardTopLeft,
           !screen.frame.contains(NSPoint(x: topLeft.x + 20, y: topLeft.y - 20)) {
            boardTopLeft = nil
        }
        showBoard()
    }

    func showBoard(immediate: Bool = false) {
        guard !isShutDown, boardDragStartFrame == nil, let screen = boardScreen() else { return }
        cancelIdlePeek()
        onWillOpenBoard?()
        if (immediate || state.quickAccessSettings.quietMode), robotTransitionTarget != nil {
            settleRobotTransition(open: true)
        }
        if let destination = robotTransitionTarget {
            if robotLifecycle.state == .collapsingApp {
                let source = robotTransitionSource ?? transitionRobotBodyFrame(on: screen)
                robotLifecycle.send(.openRequested)
                beginRobotTransition(source: source, destination: destination, opening: true)
            }
            return
        }
        let wasVisible = board.isVisible
        if !wasVisible, let frontmost = NSWorkspace.shared.frontmostApplication,
           frontmost.processIdentifier != ProcessInfo.processInfo.processIdentifier {
            workingApplication = frontmost
        }
        if activeTarget == .cameraIsland, CornerGeometry.cameraIslandRect(on: screen) == nil {
            activeTarget = .corner(.topRight)
        }
        if !wasVisible, !bin.isVisible, state.robotPlacement.home == .cameraIsland {
            activeTarget = CornerGeometry.cameraIslandRect(on: screen) == nil ? .corner(.topRight) : .cameraIsland
        }
        activeScreen = screen
        layoutBoard(on: screen)
        if !wasVisible { stopBoardAnimation() }
        let destination = board.frame
        let source = bin.isVisible
            ? bin.convertToScreen(robot.convert(robot.transitionBodyBounds, to: nil))
            : transitionRobotBodyFrame(on: screen)
        hideRobot()
        bin.orderOut(nil)
        onRobotInteractionEnded?()
        robotLifecycle.send(.openRequested)
        NSApp.activate(ignoringOtherApps: true)
        if wasVisible || !animateRobotTransitions || immediate || state.quickAccessSettings.quietMode {
            robotLifecycle.send(.interrupt(toward: .fullScreen))
            appFrame.cancelTransition(open: true)
            board.makeKeyAndOrderFront(nil)
            updateBoardVisibility()
            if state.route == .search { state.globalSearchFocusRequest &+= 1 }
            return
        }
        beginRobotTransition(source: source, destination: destination, opening: true)
    }

    /// The native panel temporarily covers both endpoints and the robot's
    /// overshoot. Its live content keeps its final size; only GPU layers
    /// transform, without per-frame layout.
    private func beginRobotTransition(source: NSRect, destination: NSRect, opening: Bool) {
        state.workspaceZoom.finishInteraction()
        let reusingStage = robotTransitionTarget != nil
        robotTransitionSerial &+= 1
        robotTransitionTask?.cancel(); robotTransitionTask = nil
        let serial = robotTransitionSerial
        robotTransitionTarget = destination
        updateNavigationInteractionState()
        robotTransitionSource = source
        if !reusingStage {
            let union = destination.union(source)
                .insetBy(dx: -RobotAppFrameView.transitionStageOutset,
                         dy: -RobotAppFrameView.transitionStageOutset).integral
            let stage = NSView(frame: NSRect(origin: .zero, size: union.size))
            stage.wantsLayer = true
            stage.layer?.masksToBounds = false
            appFrame.removeFromSuperview()
            board.contentView = stage
            setBoardFrame(union)
            appFrame.autoresizingMask = []
            appFrame.frame = NSRect(x: destination.minX - union.minX, y: destination.minY - union.minY,
                                   width: destination.width, height: destination.height)
            stage.addSubview(appFrame)
            appFrame.layoutSubtreeIfNeeded()
        }
        board.makeKeyAndOrderFront(nil)
        appFrame.setVisible(true)
        updateBoardVisibility()
        let reduced = robotReduceMotion()
        // Layer visibility/cancellation can invalidate its completion task.
        // The existing pointer clock owns a bounded endpoint recovery, so a
        // missing callback cannot strand the panel or its navigation blocker.
        let duration = reduced ? RobotAppFrameView.reducedDuration
            : (opening ? RobotAppFrameView.openDuration : RobotAppFrameView.closeDuration)
        robotTransitionRecovery = RobotTransitionRecovery(serial: serial,
            deadline: ProcessInfo.processInfo.systemUptime + duration + 0.35, opening: opening)
        let completion = { [weak self] in
            guard let self, self.robotTransitionSerial == serial, !self.isShutDown else { return }
            self.settleRobotTransition(open: opening)
            if opening { self.resizeBoard() }
        }
        if opening {
            robotTransitionTask = Task { @MainActor [weak self] in
                try? await Task.sleep(for: .seconds(reduced ? 0.06 : RobotAppFrameView.openingExpansionDelay))
                guard let self, !Task.isCancelled, self.robotTransitionSerial == serial else { return }
                self.robotLifecycle.send(.advance(to: .expandingToApp, generation: self.robotLifecycle.generation))
            }
            appFrame.animateOpen(from: source, island: activeTarget == .cameraIsland,
                                 sourceMirrored: robot.orbitLayout != nil && robot.orbitPerch.isMirrored,
                                 reduceMotion: reduced, completion: completion)
        } else {
            appFrame.animateClose(to: source, island: activeTarget == .cameraIsland,
                                  sourceMirrored: robot.orbitLayout != nil && robot.orbitPerch.isMirrored,
                                  reduceMotion: reduced, completion: completion)
        }
    }

    private func settleRobotTransition(open: Bool) {
        robotTransitionSerial &+= 1
        robotTransitionTask?.cancel(); robotTransitionTask = nil
        robotTransitionRecovery = nil
        let target = robotTransitionTarget
        robotTransitionTarget = nil
        updateNavigationInteractionState()
        robotTransitionSource = nil
        appFrame.cancelTransition(open: open)
        if target != nil {
            appFrame.removeFromSuperview()
            board.contentView = appFrame
            appFrame.autoresizingMask = [.width, .height]
            if let target { setBoardFrame(target) }
        }
        robotLifecycle.send(.interrupt(toward: open ? .fullScreen : .hidden))
        if !open {
            board.orderOut(nil)
            appFrame.setVisible(false)
            state.isBoardVisible = false
            onDidCloseBoard?()
            restoreWorkingApplication()
            ensureProjectRecordingRobot()
        } else {
            updateBoardVisibility()
            // The opening animation reparents the hosting view. Its former
            // native field editor may have lost focus during that move.
            if state.route == .search { state.globalSearchFocusRequest &+= 1 }
        }
    }

    func captureAnimationWillAppear() {
        cancelIdlePeek()
        hideRobot()
    }

    private func restoreWorkingApplication() {
        defer { workingApplication = nil }
        guard let previous = workingApplication, !previous.isTerminated,
              NSWorkspace.shared.frontmostApplication?.processIdentifier == ProcessInfo.processInfo.processIdentifier else { return }
        previous.activate(options: [])
    }

    private func cancelIdlePeek() {
        idlePeekTask?.cancel(); idlePeekTask = nil
        guard idlePeeking else { return }
        idlePeeking = false
        bin.ignoresMouseEvents = false
        robot.hideCharacter()
        bin.orderOut(nil)
        robotLifecycle.send(.interrupt(toward: .hidden))
    }

    private var lastCaptureLayoutRevision: UInt = 0

    private var boardHeight: CGFloat { contentHeight + RobotAppFrameView.extraHeight }

    private var contentHeight: CGFloat {
        let extra: CGFloat = state.notificationMessage != nil ? 45 : 0
        switch state.route {
        case .inbox: return 590 + extra
        case .weekly: return state.weeklyVisibleDays.isEmpty ? 380 + extra : 560
        case .daily: return max(380, CornerGeometry.dailyPanelHeight(for: state))
        case .library: return 620
        case .trash: return 500
        case .newNote: return 420 + extra
        case .search:
            // Date paging and optional previews need a stable workspace. Query
            // and filter changes must not collapse the panel around the field.
            return 560 + extra
        case .detail, .searchNote: return 620
        case .newTask: return (state.newTaskDraft.reminderEnabled ? 500 : 440) + extra
        case .settings: return 620
        case .reminders:
            let count = state.currentTodayCaptures.count + state.followUpCaptures.count
            return count == 0 ? 380 + extra : min(560, max(450, 220 + CGFloat(count) * 170 + extra))
        }
    }

    private func resizeBoard() {
        guard board.isVisible, robotTransitionTarget == nil, boardDragStartFrame == nil,
              !boardIsResizing, !state.workspaceZoom.isInteracting, let screen = boardScreen() else { return }
        activeScreen = screen
        layoutBoard(on: screen)
    }

    private func boardScreen() -> NSScreen? {
        if let topLeft = boardTopLeft {
            // A point inside the header avoids ambiguous shared display edges.
            let headerPoint = NSPoint(x: topLeft.x + 20, y: topLeft.y - 20)
            // While a header is being released just beyond a display edge, its
            // remembered point may temporarily belong to no screen. Keep the
            // board on its active display instead of jumping to whichever
            // display macOS currently calls main.
            return NSScreen.screens.first { $0.frame.contains(headerPoint) }
                ?? activeScreen.flatMap { old in NSScreen.screens.first { $0 == old } }
                ?? NSScreen.main
        }
        return activeScreen.flatMap { old in NSScreen.screens.first { $0 == old } } ?? NSScreen.main
    }

    private func normalBoardFrame(on screen: NSScreen) -> NSRect {
        guard let userBoardSize else { return compactBoardFrame(on: screen) }
        let origin = boardTopLeft ?? NSPoint(x: board.frame.minX, y: board.frame.maxY)
        return BoardResizeGeometry.fitted(NSRect(x: origin.x, y: origin.y - userBoardSize.height,
                                                 width: userBoardSize.width, height: userBoardSize.height),
                                          visible: screen.visibleFrame)
    }

    private func compactBoardFrame(on screen: NSScreen) -> NSRect {
        if board.isVisible, lastLayoutRoute == state.route, state.route == .daily || state.route == .search {
            // Reuse the intended endpoint during rapid filter changes. The
            // animation itself always starts from the currently visible frame.
            return CornerGeometry.filterPanelFrame(current: boardAnimationTarget ?? board.frame,
                                                    visible: screen.visibleFrame, preferredHeight: boardHeight)
        }
        if let topLeft = boardTopLeft {
            return CornerGeometry.movedPanelFrame(topLeft: topLeft, visible: screen.visibleFrame, preferredHeight: boardHeight)
        }
        let robotFrame = robotBodyFrame(on: screen)
        return CornerGeometry.panelFrame(robot: robotFrame, visible: screen.visibleFrame,
                                         target: activeTarget, preferredHeight: boardHeight)
    }

    private func robotBodyFrame(on screen: NSScreen) -> NSRect {
        if activeTarget == .cameraIsland,
           let island = CornerGeometry.cameraIslandRect(on: screen),
           let layout = QuietOrbitLayout(cameraIsland: island, displayFrame: screen.frame) {
            return layout.visibleRobotFrame(for: robot.orbitPerch)
        }
        return CornerGeometry.robotBodyFrame(in: CornerGeometry.robotFrame(target: activeTarget, on: screen),
                                     target: activeTarget)
    }

    /// Transition endpoints use the actual artwork, while board positioning
    /// retains the established interaction-body geometry above.
    private func transitionRobotBodyFrame(on screen: NSScreen) -> NSRect {
        if activeTarget == .cameraIsland,
           let island = CornerGeometry.cameraIslandRect(on: screen),
           let layout = QuietOrbitLayout(cameraIsland: island, displayFrame: screen.frame) {
            return RobotCharacterView.transitionArtworkFrame(in: layout.robotFrame(for: robot.orbitPerch),
                mirrored: robot.orbitPerch.isMirrored)
        }
        let renderer = CornerGeometry.robotFrame(target: activeTarget, on: screen).insetBy(dx: 4, dy: 4)
        return RobotCharacterView.transitionArtworkFrame(in: renderer)
    }

    private func layoutBoard(on screen: NSScreen) {
        let previousRoute = lastLayoutRoute
        let previousFilter = lastLayoutFilter
        let weeklyKey = WeeklyLayoutKey(selectedDays: state.weeklyDays)
        let weeklyDaysChanged = state.route == .weekly && lastWeeklyLayoutKey != weeklyKey
        let enteringWeek = state.route == .weekly && (previousRoute == .daily || previousRoute == .inbox)
        if weeklyDaysChanged || enteringWeek { weeklyUserSize = nil }
        if expansionBelongsToWeek && state.route != .weekly {
            frameBeforeExpansion = nil
            expansionBelongsToWeek = false
        }
        if state.route == .weekly {
            if weeklyDirection == nil || enteringWeek {
                // A rapid re-open uses the compact animation endpoint. A
                // manually expanded Daily already has its own Restore frame.
                let compact = frameBeforeExpansion ?? boardAnimationTarget
                    ?? (board.isVisible ? board.frame : normalBoardFrame(on: screen))
                boardTopLeft = NSPoint(x: compact.minX, y: compact.maxY)
                weeklyDirection = CornerGeometry.weeklyExpansionDirection(compact: compact, visible: screen.visibleFrame)
            }
            let direction = weeklyDirection ?? .right
            if state.weeklyExpansionDirection != direction { state.weeklyExpansionDirection = direction }
            if frameBeforeExpansion == nil && weeklyUserSize == nil {
                // Fill this display's safe area, using the same presentation
                // as Expand. Keep the compact size and anchor off disk.
                frameBeforeExpansion = enteringWeek
                    ? (boardAnimationTarget ?? (board.isVisible ? board.frame : normalBoardFrame(on: screen)))
                    : normalBoardFrame(on: screen)
                expansionBelongsToWeek = true
            }
        }
        let frame: NSRect
        if frameBeforeExpansion != nil {
            frame = screen.visibleFrame
        } else if workspaceZoomOwnsNormalSize && state.route != .weekly {
            // A coupled zoom remains the normal size beneath Week's
            // temporary full view.
            frame = normalBoardFrame(on: screen)
        } else if state.route == .weekly {
            let direction = weeklyDirection ?? .right
            let normal = normalBoardFrame(on: screen)
            if let weeklyUserSize {
                let x = direction == .left ? normal.maxX - weeklyUserSize.width : normal.minX
                frame = BoardResizeGeometry.fitted(NSRect(x: x, y: normal.maxY - weeklyUserSize.height,
                    width: weeklyUserSize.width, height: weeklyUserSize.height), visible: screen.visibleFrame,
                    minimum: userBoardSize == nil ? .zero : nil)
            } else {
                frame = screen.visibleFrame
            }
        } else {
            frame = normalBoardFrame(on: screen)
            if state.route == .daily {
                let direction = CornerGeometry.weeklyExpansionDirection(compact: frame, visible: screen.visibleFrame)
                if state.weeklyExpansionDirection != direction { state.weeklyExpansionDirection = direction }
            }
        }
        if state.route == .weekly { lastWeeklyLayoutKey = weeklyKey }
        lastLayoutRoute = state.route
        lastLayoutFilter = state.filter
        board.title = state.route == .weekly ? "DaBin Week" : "DaBin Daily"
        let reduceMotion = NSWorkspace.shared.accessibilityDisplayShouldReduceMotion
        let weeklyTransition = CornerGeometry.shouldAnimateWeeklyTransition(from: previousRoute, to: state.route,
            visible: board.isVisible, reduceMotion: reduceMotion)
        let weeklyContentTransition = board.isVisible && !reduceMotion && state.route == .weekly
            && previousRoute == .weekly && (weeklyDaysChanged || boardAnimationKind == .weekly)
        let filterTransition = CornerGeometry.shouldAnimateFilterTransition(from: previousRoute, to: state.route,
            previousFilter: previousFilter, filter: state.filter, visible: board.isVisible, reduceMotion: reduceMotion)
        // Preview/status updates arriving during a filter animation may change
        // its target height; continue smoothly instead of snapping to that size.
        let continuingFilterTransition = boardAnimationKind == .filter && !reduceMotion && board.isVisible
            && previousRoute == state.route && (state.route == .daily || state.route == .search)
        let captureResize = state.captureLayoutRevision != lastCaptureLayoutRevision
            && previousRoute == state.route && state.route == .daily
            && board.isVisible && !reduceMotion
        lastCaptureLayoutRevision = state.captureLayoutRevision
        let animation: BoardFrameAnimationKind? = weeklyTransition || weeklyContentTransition ? .weekly
            : (filterTransition || continuingFilterTransition || captureResize ? .filter : nil)
        if reduceMotion { stopBoardAnimation() }
        applyBoardFrame(frame, animation: animation)
    }

    private func setBoardFrame(_ frame: NSRect) {
        lastAppliedBoardFrame = frame
        guard board.frame != frame else { return }
        applyingBoardFrame = true
        board.setFrame(frame, display: true)
        applyingBoardFrame = false
        boardFrameApplicationCount += 1
    }

    private func applyBoardFrame(_ frame: NSRect, animation: BoardFrameAnimationKind? = nil) {
        if boardFrameAnimation != nil, boardAnimationTarget == frame { return }
        stopBoardAnimation()
        guard let animation, board.frame != frame else { setBoardFrame(frame); return }
        let start = board.frame
        let started = ProcessInfo.processInfo.systemUptime
        let duration = animation == .filter ? Self.filterResizeDuration : 0.28
        boardAnimationTarget = frame
        boardAnimationKind = animation
        let timer = Timer(timeInterval: 1.0 / 60.0, repeats: true) { [weak self] timer in
            MainActor.assumeIsolated {
                guard let self else { timer.invalidate(); return }
                let progress = min(1, (ProcessInfo.processInfo.systemUptime - started) / duration)
                let eased = CGFloat(progress * progress * (3 - 2 * progress))
                let next = NSRect(x: start.minX + (frame.minX - start.minX) * eased,
                                  y: start.minY + (frame.minY - start.minY) * eased,
                                  width: start.width + (frame.width - start.width) * eased,
                                  height: start.height + (frame.height - start.height) * eased)
                self.setBoardFrame(progress == 1 ? frame : next)
                if progress == 1 { self.stopBoardAnimation() }
            }
        }
        boardFrameAnimation = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    private func stopBoardAnimation() {
        boardFrameAnimation?.invalidate()
        boardFrameAnimation = nil
        boardAnimationTarget = nil
        boardAnimationKind = nil
    }

    func beginBoardDrag(pointer: CGPoint? = nil) {
        state.workspaceZoom.finishInteraction()
        if robotTransitionTarget != nil { settleRobotTransition(open: true) }
        stopBoardAnimation()
        if let previous = frameBeforeExpansion, let screen = boardScreen() {
            let pointer = pointer ?? NSEvent.mouseLocation
            let fraction = min(1, max(0, (pointer.x - board.frame.minX) / max(1, board.frame.width)))
            var restored = previous
            restored.origin = NSPoint(x: pointer.x - previous.width * fraction,
                                     y: pointer.y - previous.height + 42)
            // Moving restores the existing sizing policy. An automatic Week
            // must still fold back to a compact board after the drag, and an
            // automatically short board must not gain the manual resize minimum.
            restored = BoardResizeGeometry.fitted(restored, visible: screen.visibleFrame,
                                                   minimum: userBoardSize == nil ? .zero : nil)
            frameBeforeExpansion = nil
            expansionBelongsToWeek = false
            if state.route == .weekly {
                weeklyUserSize = restored.size
            } else if userBoardSize != nil { userBoardSize = restored.size }
            setBoardFrame(restored)
            rebaseWorkspaceZoom()
        }
        boardDragStartFrame = board.frame
        updateNavigationInteractionState()
        startBoardInteractionWatchdog()
    }

    private func startBoardInteractionWatchdog() {
        boardInteractionTimer?.invalidate()
        // Keep layout updates paused until the pointer is released, including
        // a missing mouse-up outside the app. Both resize and header movement
        // use this one timer, which exists only while a gesture is active.
        let timer = Timer(timeInterval: 0.05, repeats: true) { [weak self] timer in
            MainActor.assumeIsolated {
                guard let self else { timer.invalidate(); return }
                guard NSEvent.pressedMouseButtons & 1 == 0 else { return }
                if self.boardIsResizing { self.finishBoardResize() }
                else { self.finishBoardDragIfReleased(pointer: NSEvent.mouseLocation) }
            }
        }
        RunLoop.main.add(timer, forMode: .common)
        boardInteractionTimer = timer
    }

    func finishBoardDragIfReleased(pressedMouseButtons: Int = NSEvent.pressedMouseButtons,
                                   pointer: CGPoint? = nil) {
        guard pressedMouseButtons & 1 == 0 else { return }
        guard let initial = boardDragStartFrame else { return }
        boardInteractionTimer?.invalidate()
        boardInteractionTimer = nil
        cancelNativeBoardInteraction()
        boardDragStartFrame = nil
        updateNavigationInteractionState()
        if board.frame.origin != initial.origin {
            let screens = NSScreen.screens
            if let index = BoardResizeGeometry.destinationDisplay(for: board.frame, pointer: pointer,
                                                                  displays: screens.map(\.frame)) {
                let destination = screens[index]
                activeScreen = destination
                // Fit only after release, so crossing the display boundary is
                // continuous and a partly overlapping window stays where held.
                // Automatic empty/filter layouts can legitimately be shorter
                // than the manual resize minimum. Moving must keep their size.
                setBoardFrame(BoardResizeGeometry.fitted(board.frame, visible: destination.visibleFrame, minimum: .zero))
            }
            rememberBoardPosition()
            if board.frame.size == initial.size {
                workspaceZoomGeometry?.move(to: CGPoint(x: board.frame.minX, y: board.frame.maxY))
            } else { rebaseWorkspaceZoom() }
        }
        if state.route == .daily || state.route == .search, let screen = boardScreen() {
            let compactWidth = CornerGeometry.panelFrame(robot: .zero, visible: screen.visibleFrame,
                                                         corner: .bottomLeft).width
            // A user drag can leave the header off screen, or interrupt a
            // weekly fold at an intermediate width. Recover normal geometry
            // before applying fixed-top resizing to subsequent filter changes.
            if !screen.visibleFrame.contains(board.frame) || abs(board.frame.width - compactWidth) > 0.5 {
                lastLayoutRoute = nil
            }
        }
        resizeBoard()
    }

    @objc private func boardMoved() {
        guard board.isVisible, robotTransitionTarget == nil, !applyingBoardFrame, boardFrameAnimation == nil,
              !state.workspaceZoom.isInteracting, board.frame != lastAppliedBoardFrame else { return }
        rememberBoardPosition(persist: boardDragStartFrame == nil)
        if boardDragStartFrame == nil {
            workspaceZoomGeometry?.move(to: CGPoint(x: board.frame.minX, y: board.frame.maxY))
        }
    }

    private func rememberBoardPosition(persist: Bool = true) {
        guard frameBeforeExpansion == nil else { return }
        let point: NSPoint
        if lastLayoutRoute == .weekly, let direction = weeklyDirection {
            let visible = NSScreen.screens.first { $0.frame.contains(NSPoint(x: board.frame.midX, y: board.frame.maxY - 20)) }
                ?? boardScreen()
            let compactWidth = visible.map { normalBoardFrame(on: $0).width } ?? 400
            point = CornerGeometry.compactTopLeft(weeklyFrame: board.frame, compactWidth: compactWidth, direction: direction)
        } else {
            point = NSPoint(x: board.frame.minX, y: board.frame.maxY)
        }
        guard point.x.isFinite, point.y.isFinite else { return }
        boardTopLeft = point
        if persist { placementDefaults?.set([Double(point.x), Double(point.y)], forKey: Self.boardPlacementKey) }
        if state.route == .daily, let screen = boardScreen() {
            let direction = CornerGeometry.weeklyExpansionDirection(compact: board.frame, visible: screen.visibleFrame)
            if state.weeklyExpansionDirection != direction { state.weeklyExpansionDirection = direction }
        }
    }

    func dismiss() {
        guard !isShutDown else { return }
        state.endSearchSession()
        cancelBoardInteraction()
        stopBoardAnimation()
        cancelIdlePeek()
        captureHostingView.clearDropTarget()
        dismissMessage()
        keyboardHold = false
        suppressUntilExit = true
        hideRobot()
        guard board.isVisible else { ensureProjectRecordingRobot(); return }
        if robotLifecycle.state == .collapsingApp {
            if !appFrame.isTransitioning { settleRobotTransition(open: false) }
            return
        }
        let destination = robotTransitionTarget ?? board.frame
        let ongoingSource = robotTransitionSource
        robotLifecycle.send(.closeRequested)
        guard animateRobotTransitions, let screen = boardScreen() else {
            settleRobotTransition(open: false)
            return
        }
        let source = ongoingSource ?? transitionRobotBodyFrame(on: screen)
        beginRobotTransition(source: source, destination: destination, opening: false)
    }

    private func hidePausedRobot() {
        cancelIdlePeek()
        dismissMessage()
        feedbackUntil = .distantPast
        hideRobot(force: true)
    }

    private func hideRobot(animated: Bool = false, force: Bool = false) {
        guard force || (!saving && !dragActive) else { return }
        companionEncounter.reset()
        companionEncounterActive = false
        recordingInteractionActive = false
        if animated, animateRobotTransitions, robot.orbitLayout != nil {
            guard !robot.isOrbitRetreating else { return }
            releaseHoverFocus()
            robot.retreatOrbit { [weak self] in
                guard let self else { return }
                self.bin.orderOut(nil)
                self.keyboardHold = false
                self.onRobotInteractionEnded?()
            }
            return
        }
        hoverFocus = false
        orbitDwell.cancel()
        robot.hideCharacter()
        bin.orderOut(nil)
        keyboardHold = false
        onRobotInteractionEnded?()
    }

    private func received(_ captures: [Capture], errors: [String]) {
        companionEncounter.reset(); companionEncounterActive = false
        orbitDwell.reset(to: robot.orbitPerch)
        keyboardHold = false
        feedbackUntil = Date().addingTimeInterval(errors.isEmpty ? 1.3 : 4)
        if !isRobotPresentationPaused { robot.digest(success: !captures.isEmpty, partial: !errors.isEmpty) }
        state.reportCaptureResult(captures, errors: errors)
        if !errors.isEmpty {
            if let summary = state.notificationMessage?.text { showMessage(summary) }
        }
    }

    private func receiveOnDaily(_ pasteboard: NSPasteboard) {
        if state.route == .detail, let task = state.selectedCapture, task.isTask {
            state.pasteAttachments(to: task, from: pasteboard)
            return
        }
        if state.route == .inbox || (state.route == .library && state.workspace.mode == .collection) {
            state.pasteClipboard(from: pasteboard); return
        }
        guard state.route == .daily || state.route == .reminders else { return }
        let captureRoute = state.route
        let navigationRevision = state.captureNavigationRevision
        input.receive(pasteboard, completion: { [weak self] captures, _ in
            // Reveal a successful capture on its receipt day, even if the
            // board was showing an older date or an incompatible filter.
            // A slow import must never pull the user out of a later action.
            guard let self, let first = captures.first, self.board.isVisible,
                  self.state.route == captureRoute,
                  self.state.captureNavigationRevision == navigationRevision else { return }
            if captureRoute == .reminders {
                self.state.refreshCurrentDay()
                return
            }
            self.state.openDaily()
            self.state.selectedDay = first.capturedAt
            self.state.dailyScrollID = self.state.feedID(for: first, on: self.state.selectedDay)
        })
    }

    private func showMessage(_ text: String) {
        guard !isShutDown, bin.isVisible else { return }
        dismissMessage()
        let popover = NSPopover()
        popover.behavior = .transient
        popover.animates = false
        popover.contentViewController = NSHostingController(rootView:
            Text(text).font(.system(size: 12)).padding(12).frame(width: 245).fixedSize(horizontal: false, vertical: true)
        )
        let edge: NSRectEdge
        switch activeTarget {
        case .corner(let corner): edge = corner.isRight ? .minX : .maxX
        case .cameraIsland: edge = .minY
        }
        popover.show(relativeTo: robot.bounds, of: robot, preferredEdge: edge)
        message = popover
        messageExpiry = Task { [weak self, weak popover] in
            do { try await Task.sleep(for: TransientMessagePolicy.maximumDisplayDuration) }
            catch { return }
            guard !Task.isCancelled, let self, let popover, self.message === popover else { return }
            self.dismissMessage()
        }
    }

    private func dismissMessage() {
        messageExpiry?.cancel()
        messageExpiry = nil
        message?.close()
        message = nil
    }

    @objc private func screensChanged() {
        cancelBoardInteraction()
        stopBoardAnimation()
        cancelIdlePeek()
        let intendedOpen = robotLifecycle.isOpening || robotLifecycle.isAppVisible || restoreBoardAfterDisplayLoss
        guard !NSScreen.screens.isEmpty else {
            restoreBoardAfterDisplayLoss = intendedOpen
            robotLifecycle.send(.displayChanged(hasDisplay: false))
            settleRobotTransition(open: false)
            hideRobot()
            return
        }
        if robotTransitionTarget != nil { settleRobotTransition(open: intendedOpen) }
        robotLifecycle.send(.displayChanged(hasDisplay: true))
        lastLayoutRoute = nil
        if intendedOpen, let screen = boardScreen() {
            onWillOpenBoard?()
            activeScreen = screen
            if activeTarget == .cameraIsland, CornerGeometry.cameraIslandRect(on: screen) == nil {
                activeTarget = .corner(.topRight)
            }
            layoutBoard(on: screen)
            rebaseWorkspaceZoom()
            robotLifecycle.send(.interrupt(toward: .fullScreen))
            appFrame.cancelTransition(open: true)
            // Hardware changes are not user activation. Keep the user's current
            // keyboard focus and Space while moving the existing passive panel.
            if restoreBoardAfterDisplayLoss { board.orderFrontRegardless() }
            updateBoardVisibility()
        } else { hideRobot(); ensureProjectRecordingRobot() }
        restoreBoardAfterDisplayLoss = false
    }

    private func cancelNativeBoardInteraction() {
        appFrame.cancelWindowInteraction()
        func cancelHeaderDrags(in view: NSView) {
            (view as? WindowDragHandleView)?.cancelWindowInteraction()
            view.subviews.forEach { cancelHeaderDrags(in: $0) }
        }
        cancelHeaderDrags(in: captureHostingView)
    }

    private func cancelBoardInteraction() {
        state.workspaceZoom.finishInteraction()
        cancelNativeBoardInteraction()
        boardInteractionTimer?.invalidate()
        boardInteractionTimer = nil
        if boardDragStartFrame != nil { rememberBoardPosition(); rebaseWorkspaceZoom() }
        boardDragStartFrame = nil
        if boardIsResizing { finishBoardResize() }
        updateNavigationInteractionState()
    }

    private func robotHomeChanged() {
        suppressUntilExit = false
        guard !saving, !dragActive else { return }
        hideRobot()
        // The home publisher is willSet; the session refresh uses its new value.
        DispatchQueue.main.async { [weak self] in self?.ensureProjectRecordingRobot() }
    }

    @objc private func accessibilityDisplayOptionsChanged() {
        robot.refreshMotionPreference()
        if robotTransitionTarget != nil {
            settleRobotTransition(open: robotLifecycle.state != .collapsingApp)
        }
        appFrame.setVisible(false)
        updateBoardVisibility()
    }

    @objc private func updateBoardVisibility() {
        let visible = board.isVisible && !NSApp.isHidden && board.occlusionState.contains(.visible)
        if !visible { state.workspaceZoom.finishInteraction() }
        if state.isBoardVisible != visible { state.isBoardVisible = visible }
        // Occlusion pauses decoration work, never the content itself. Hiding a
        // transparent window's content on occlusion can keep it occluded forever.
        if robotTransitionTarget == nil { appFrame.setVisible(board.isVisible && !NSApp.isHidden) }
    }
}
