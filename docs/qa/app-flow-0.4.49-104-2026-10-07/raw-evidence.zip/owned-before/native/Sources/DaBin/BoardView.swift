import SwiftUI

@MainActor
struct BoardView: View {
    static let searchPlaceholder = "Search everything saved in DaBin"
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var colorSchemeContrast
    @ObservedObject var state: AppState
    @StateObject private var theme: ThemeSettings
    @StateObject private var dayExportController: DayExportActionController
    @StateObject private var tooltipController: TimelineTooltipController
    @StateObject private var tutorial = DaBinTutorialController()
    @State private var showCalendar = false
    @State private var iconHover: Set<String> = []
    @FocusState private var searchFocused: Bool
    @FocusState private var weeklySearchFocused: Bool

    init(state: AppState, theme: ThemeSettings? = nil,
         dayExportController: DayExportActionController? = nil,
         tooltipController: TimelineTooltipController? = nil) {
        self.state = state
        _theme = StateObject(wrappedValue: theme ?? ThemeSettings())
        _dayExportController = StateObject(wrappedValue: dayExportController ?? .live())
        _tooltipController = StateObject(wrappedValue: tooltipController ?? TimelineTooltipController())
    }

    private var accent: Color { theme.accent }
    private var isTimeline: Bool { state.route == .daily || state.route == .weekly }
    private var isPrimary: Bool { isTimeline || state.route == .inbox || state.route == .library || state.route == .reminders }

    var body: some View {
        VStack(spacing: 0) {
            header
            if let message = state.notificationMessage {
                statusBanner(message)
            }
            if state.canUndoRemoval { undoBanner }
            if let error = state.draftPersistenceError {
                Text(error).font(.system(size: 11)).foregroundStyle(Palette.task).padding(8)
            }
            routeContent
                .workspaceZoomEnvironment(state.workspaceZoom, isEnabled: state.route != .settings)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .daBinTutorialAnchor(.routeBody)
            BoardCaptureStatus(state: state, service: state.autoCapture, settings: state.autoCapture.settings)
        }
        .foregroundStyle(Palette.foreground).tint(accent).environment(\.daBinAccent, accent)
        .environment(\.daBinTooltipsEnabled, theme.showTooltips)
        .environment(\.timelineTooltipController, tooltipController)
        .environment(\.hoverTooltipActiveID, tooltipController.visible?.id)
        .environment(\.daBinTutorialTargets, tutorial.isPresented ? Set(tutorial.step.targetCandidates) : [])
        .background(WorkspaceInputRegion())
        .background(Palette.background.opacity(ThemeSettings.effectiveBoardOpacity(
            preferred: theme.boardOpacity, reduceTransparency: reduceTransparency || colorSchemeContrast == .increased)))
        .preferredColorScheme(theme.darkModeEnabled ? .dark : .light)
        .clipShape(BoardWindowChrome.shape)
        .overlay(BoardWindowChrome.shape.strokeBorder(Palette.line, lineWidth: 1))
        .overlayPreferenceValue(HoverTooltipAnchorKey.self) { anchors in
            HoverTooltipOverlay(controller: tooltipController, anchors: anchors, isEnabled: theme.showTooltips)
        }
        .overlay {
            if state.isDailyDropTargeted && (state.route == .daily || state.route == .inbox || state.route == .reminders
                || (state.route == .detail && state.selectedCapture?.isTask == true)) {
                BoardWindowChrome.shape.fill(accent.opacity(0.06))
                    .overlay(BoardWindowChrome.shape.strokeBorder(accent, lineWidth: 2))
                    .allowsHitTesting(false).accessibilityHidden(true)
            }
        }
        .daBinTutorialPresentation(tutorial: tutorial, state: state)
        .alert("Move this capture to Recently Deleted?", isPresented: Binding(
            get: { state.pendingRemoval != nil }, set: { if !$0 { state.pendingRemoval = nil } }
        ), presenting: state.pendingRemoval) { capture in
            Button("Cancel", role: .cancel) { state.pendingRemoval = nil }
            Button("Move to Recently Deleted", role: .destructive) {
                state.pendingRemoval = nil
                Task { await state.removeCapture(capture) }
            }
        } message: { _ in
            Text("You can restore it from Recently Deleted. Files at their original locations are kept.")
        }
        .alert("Delete these notes?", isPresented: Binding(
            get: { state.pendingScratchpadRemoval != nil },
            set: { if !$0 { state.pendingScratchpadRemoval = nil } }
        ), presenting: state.pendingScratchpadRemoval) { note in
            Button("Cancel", role: .cancel) { state.pendingScratchpadRemoval = nil }
            Button("Delete notes", role: .destructive) { state.confirmScratchpadRemoval(note) }
        } message: { _ in
            Text("The notes move to Recently Deleted, where you can restore them. Saved copies and other project items are kept.")
        }
        .onExitCommand {
            if tutorial.isPresented { tutorial.finish(in: state) }
            else if searchFocused { searchFocused = false }
            else if weeklySearchFocused { weeklySearchFocused = false }
            else { state.onDismiss?() }
        }
        .onChange(of: state.route) { _, route in
            tooltipController.dismiss()
            if route != .weekly { weeklySearchFocused = false }
            guard tutorial.isPresented else {
                searchFocused = route == .search
                return
            }
            searchFocused = false
            if route != tutorial.step.destination {
                Task { @MainActor in
                    guard tutorial.isPresented, state.route != tutorial.step.destination else { return }
                    tutorial.restoreCurrentStep(in: state)
                }
            }
        }
        .onChange(of: theme.showTooltips, initial: true) { _, enabled in tooltipController.setEnabled(enabled) }
        .onAppear { [weak state, weak tutorial] in
            tooltipController.setPresentationActive(true)
            state?.onTutorialEscape = { [weak state, weak tutorial] in
                guard let state, let tutorial, tutorial.isPresented else { return false }
                tutorial.finish(in: state)
                return true
            }
        }
        .onChange(of: state.isBoardVisible) { _, visible in
            tooltipController.setPresentationActive(visible)
        }
        .onDisappear {
            tooltipController.setPresentationActive(false)
            if tutorial.isPresented { tutorial.finish(in: state) }
            state.onTutorialEscape = nil
        }
        .onChange(of: dayExportController.feedbackRevision) { _, _ in
            guard let feedback = dayExportController.visibleFeedback else { return }
            if case .failed = feedback { state.reportFailure(feedback.message) }
            else { state.status = AppStatusMessage(text: feedback.message, severity: .success) }
        }
        .onChange(of: state.notifications.revision) { _, _ in
            if let message = state.notificationMessage { AccessibilityAnnouncement.post(message.text) }
        }
        .background {
            Group {
                Button("Search captures") { state.performSearchCommand(); searchFocused = true }
                    .keyboardShortcut("k", modifiers: .command)
                Button("Open Tasks") { state.showReminders() }
                    .keyboardShortcut("d", modifiers: [.command, .shift])
            }.frame(width: 0, height: 0).opacity(0).accessibilityHidden(true)
        }
    }

    @ViewBuilder private var routeContent: some View {
        switch state.route {
        case .inbox: InboxScreen(state: state)
        case .daily: DailyScreen(state: state)
        case .weekly: WeeklyScreen(state: state)
        case .library: LibraryScreen(state: state)
        case .search: SearchScreen(state: state)
        case .searchNote: ScratchpadView(state: state, workspace: state.workspace, noteContext: state.selectedSearchNote)
        case .newTask: NewTaskScreen(state: state, draft: state.newTaskDraft)
        case .newNote: NewNoteScreen(state: state)
        case .detail:
            if let capture = state.selectedCapture, let draft = state.selectedDraft {
                DetailScreen(state: state, capture: capture, draft: draft).id(capture.id)
            } else {
                EmptyMessage(symbol: "tray", title: "Capture unavailable", message: "Open Projects to browse your saved captures.")
            }
        case .reminders: TodayPlanningScreen(state: state)
        case .settings:
            SettingsScreen(state: state, theme: theme, runTutorial: { tutorial.start(in: state) },
                dayExportController: dayExportController, exportDay: Self.exportDay(for: state),
                exportContextIsWeekly: state.settingsReturnRoute == .weekly,
                exportContextAllowsTimelineActions: state.settingsReturnRoute != .library,
                tutorialTarget: tutorial.isPresented ? tutorial.step.targetCandidates.first : nil)
        case .trash: TrashScreen(state: state)
        }
    }

    private var header: some View {
        VStack(spacing: 4) {
            HStack(spacing: 3) {
                if state.route == .library {
                    ExplorerProjectPicker(state: state, workspace: state.workspace)
                        .frame(minWidth: 124, idealWidth: 160, maxWidth: 240).layoutPriority(1)
                } else {
                    Button { state.openLibrary() } label: {
                        DaBinLogo(variant: .compact).frame(width: 68, height: 28, alignment: .leading)
                            .contentShape(Rectangle())
                    }.buttonStyle(.plain).disabled(state.isNavigationBlocked)
                        .accessibilityElement(children: .ignore).accessibilityLabel("Open Projects")
                        .accessibilityRemoveTraits(.isHeader).accessibilityAddTraits(.isButton)
                        .accessibilityIdentifier("board-logo-projects")
                        .buddyHelp("Open Projects")
                }
                AutoCaptureHeaderButton(service: state.autoCapture, weekly: state.route == .weekly,
                    statusText: state.autoCapture.overallStatusText, isVisible: state.isBoardVisible) { state.toggleAutoCaptureFromHeader() }
                WindowDragHandle(onDragStarted: { state.onBoardDragStarted?() },
                                 onDragEnded: { state.onBoardDragEnded?($0) })
                    .frame(minWidth: 0, maxWidth: .infinity).frame(height: 28).layoutPriority(-1)
                    .accessibilityHidden(true)
                newTaskButton
                if state.route != .search {
                    BuddyIconButton(symbol: "magnifyingglass", title: "Search captures", tooltipID: "board-search-tooltip", interfaceArtwork: true) {
                        state.performSearchCommand(); searchFocused = true
                    }.accessibilityIdentifier("board-search")
                        .disabled(state.isNavigationBlocked)
                }
                BuddyIconButton(symbol: "gearshape", title: "Settings", tooltipID: "board-settings-tooltip", interfaceArtwork: true) { state.showSettings() }
                    .background(state.route == .settings ? accent.opacity(0.10) : .clear,
                                in: RoundedRectangle(cornerRadius: 8))
                    .accessibilityAddTraits(state.route == .settings ? [.isSelected] : [])
                    .accessibilityIdentifier("board-settings")
                    .disabled(state.isNavigationBlocked)
                BuddyIconButton(symbol: "arrow.up.left.and.arrow.down.right", title: "Expand or restore window",
                                tooltipID: "window-expand-tooltip", interfaceArtwork: true) {
                    state.onToggleExpandedWindow?()
                }.accessibilityIdentifier("window-expand")
                SmallIcon(symbol: "xmark", label: "Hide DaBin", size: 28) { state.onDismiss?() }
                    .accessibilityIdentifier("window-close")
            }
            if state.route == .search {
                HStack(spacing: 6) {
                    historyControls
                    searchField
                }
            } else if isPrimary {
                HStack(spacing: 4) {
                    historyControls
                    navigationButton("Projects", symbol: "folder", selected: state.route == .library,
                                     identifier: "primary-workspace") { state.openLibrary() }
                    navigationButton("Tasks", symbol: "dabin.task", selected: state.route == .reminders,
                                     identifier: "primary-today") { state.showReminders() }
                    navigationButton("Captions", symbol: "tray", selected: state.isInboxRoute,
                                     identifier: "primary-inbox") { state.openInbox() }
                }.accessibilityElement(children: .contain).accessibilityLabel("Main views")
            } else if state.route != .settings {
                HStack(spacing: 8) {
                    historyControls
                    Text(routeTitle).font(.system(size: 14, weight: .semibold)).accessibilityAddTraits(.isHeader)
                    Spacer(minLength: 0)
                }.frame(minHeight: 28)
            }
            if state.isInboxRoute { timelineControls }
        }.padding(.horizontal, 12).padding(.vertical, 6)
            .fixedSize(horizontal: false, vertical: true)
            .background(Palette.surface)
            .overlay(alignment: .bottom) { Rectangle().fill(Palette.line).frame(height: 1) }
    }

    private var historyControls: some View {
        HStack(spacing: 1) {
            Button { state.back() } label: {
                DaBinIcon(name: .left, baseSize: 12, tint: accent, hovered: iconHover.contains("back")).frame(width: 12, height: 12).font(.system(size: 12, weight: .semibold))
                    .frame(width: 26, height: 28).contentShape(Rectangle())
            }.disabled(!state.canGoBack || state.isNavigationBlocked)
                .onHover { if $0 { iconHover.insert("back") } else { iconHover.remove("back") } }
                .buddyHelp("Back (⌘[)").accessibilityLabel("Back")
                .accessibilityIdentifier("board-back")
            Button { state.forward() } label: {
                DaBinIcon(name: .right, baseSize: 12, tint: accent, hovered: iconHover.contains("forward")).frame(width: 12, height: 12).font(.system(size: 12, weight: .semibold))
                    .frame(width: 26, height: 28).contentShape(Rectangle())
            }.disabled(!state.canGoForward || state.isNavigationBlocked)
                .onHover { if $0 { iconHover.insert("forward") } else { iconHover.remove("forward") } }
                .buddyHelp("Forward (⌘])").accessibilityLabel("Forward")
                .accessibilityIdentifier("board-forward")
        }.buttonStyle(.plain).foregroundStyle(accent)
            .accessibilityElement(children: .contain).accessibilityLabel("View history")
    }

    private var searchField: some View {
        HStack(spacing: 7) {
                DaBinIcon(name: .search, baseSize: 14, tint: Palette.muted).frame(width: 14, height: 14).foregroundStyle(Palette.muted).accessibilityHidden(true)
                TextField(Self.searchPlaceholder, text: Binding(
                    get: { state.route == .search ? state.query : "" },
                    set: { state.updateGlobalSearch($0) }))
                    .textFieldStyle(.plain).font(.system(size: 13)).focused($searchFocused)
                    .accessibilityLabel("Search everything saved in DaBin, \(state.searchScopeTitle)").accessibilityIdentifier("global-search")
                    .onSubmit { state.submitSearch() }
                    .task(id: state.globalSearchFocusRequest) {
                        // Reopening can detach the native editor while SwiftUI
                        // still remembers this field as focused. Retry an actual
                        // focus transition after the editor is attached again.
                        searchFocused = false
                        await Task.yield()
                        guard !Task.isCancelled, state.route == .search else { return }
                        searchFocused = true
                    }
                if state.route == .search && !state.query.isEmpty {
                    Button {
                        state.updateGlobalSearch("")
                        state.globalSearchFocusRequest &+= 1
                    } label: { DaBinIcon(systemName: "xmark.circle.fill").daBinInterfaceGlyphMotion(baseSize: 13, hovered: iconHover.contains("search-clear")) }
                        .buttonStyle(.plain).foregroundStyle(Palette.muted)
                        .onHover { if $0 { iconHover.insert("search-clear") } else { iconHover.remove("search-clear") } }
                        .buddyHelp("Clear search").accessibilityLabel("Clear search")
                }
            }.padding(7).background(Palette.surface, in: RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(Palette.line))
                .daBinTutorialAnchor(.searchField)
    }

    private var weeklySearchField: some View {
        HStack(spacing: 7) {
            Button(action: submitWeeklySearch) {
                DaBinIcon(name: .search, baseSize: 14, tint: Palette.muted,
                          hovered: iconHover.contains("weekly-search-submit"))
                    .frame(width: 14, height: 14).frame(width: 24, height: 28).contentShape(Rectangle())
            }.buttonStyle(.plain).accessibilityLabel("Search this week")
                .accessibilityIdentifier("weekly-search-submit")
                .onHover { if $0 { iconHover.insert("weekly-search-submit") } else { iconHover.remove("weekly-search-submit") } }
                .buddyHelp("Search all dates in the displayed week")
            TextField("Search this week", text: Binding(
                get: { state.weeklySearchQuery }, set: { state.updateWeeklySearch($0) }))
                .textFieldStyle(.plain).font(.system(size: 13)).focused($weeklySearchFocused)
                .accessibilityLabel("Search this week").accessibilityIdentifier("weekly-search")
                .buddyHelp("Search this week as you type. Return opens the full search view.")
                .onSubmit(submitWeeklySearch)
            if !state.weeklySearchQuery.isEmpty {
                Button { state.updateWeeklySearch(""); weeklySearchFocused = true } label: {
                    DaBinIcon(systemName: "xmark.circle.fill")
                        .daBinInterfaceGlyphMotion(baseSize: 13, hovered: iconHover.contains("weekly-search-clear"))
                        .frame(width: 24, height: 28).contentShape(Rectangle())
                }.buttonStyle(.plain).foregroundStyle(Palette.muted)
                    .onHover { if $0 { iconHover.insert("weekly-search-clear") } else { iconHover.remove("weekly-search-clear") } }
                    .accessibilityLabel("Clear week search").accessibilityIdentifier("weekly-search-clear")
                    .buddyHelp("Clear week search")
            }
        }.padding(7).background(Palette.surface, in: RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(Palette.line))
            .disabled(state.isNavigationBlocked)
    }

    private func submitWeeklySearch() {
        guard state.route == .weekly, !state.isNavigationBlocked else { return }
        weeklySearchFocused = false
        state.openSearch(week: state.weeklyDays, query: state.weeklySearchQuery)
    }

    private func navigationButton(_ title: String, symbol: String, selected: Bool,
                                  identifier: String? = nil, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label { Text(title) } icon: {
                DaBinIcon(name: symbol == "folder" ? .folder : symbol == "dabin.task" ? .task : .all,
                          baseSize: 12, tint: selected ? Palette.foreground : Palette.muted,
                          surface: Palette.surface, hovered: iconHover.contains(title))
                    .frame(width: 12, height: 12)
            }.font(.system(size: 12, weight: selected ? .semibold : .medium))
                .lineLimit(1).fixedSize(horizontal: true, vertical: false)
                .frame(maxWidth: .infinity).frame(minHeight: 32)
                .overlay(alignment: .bottom) { if selected { Capsule().fill(accent).frame(height: 2).padding(.horizontal, 5) } }
                .contentShape(Rectangle())
        }.buttonStyle(.plain).foregroundStyle(selected ? Palette.foreground : Palette.muted)
            .disabled(state.isNavigationBlocked)
            .onHover { if $0 { iconHover.insert(title) } else { iconHover.remove(title) } }
            .accessibilityAddTraits(selected ? [.isSelected] : [])
            .accessibilityIdentifier(identifier ?? "primary-\(title.lowercased())")
    }

    private var newTaskButton: some View {
        Button {
            state.openNewTask()
        } label: { DaBinIcon(name: .plus, baseSize: 16, tint: accent, hovered: iconHover.contains("add")).frame(width: 16, height: 16).font(.system(size: 16, weight: .semibold)).frame(width: 28, height: 32) }
        .buttonStyle(.plain).fixedSize().buddyHelp("New task", id: "primary-tooltip-add")
        .background(accent.opacity(0.13), in: RoundedRectangle(cornerRadius: 8))
        .onHover { if $0 { iconHover.insert("add") } else { iconHover.remove("add") } }
        .accessibilityLabel("New task").accessibilityIdentifier("timeline-action-add")
        .disabled(state.isNavigationBlocked)
    }

    static func exportDay(for state: AppState) -> Date {
        let route = state.route == .settings ? state.settingsReturnRoute : state.route
        if route == .weekly { return state.weeklyActionDay }
        guard route == .reminders else { return state.selectedDay }
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: state.currentDayKey) ?? Date()
    }
    private var timelineControls: some View {
        VStack(spacing: 4) {
            HStack(spacing: 4) {
                if isTimeline {
                    SmallIcon(symbol: "chevron.left", label: state.route == .weekly ? "Previous week" : "Previous day", size: 26) { moveTimeline(-1) }
                        .disabled(state.isNavigationBlocked)
                    Button { showCalendar.toggle() } label: {
                        HStack(spacing: 5) {
                            DaBinIcon(name: .calendar, baseSize: 14, tint: accent, hovered: iconHover.contains("date")).frame(width: 14, height: 14).foregroundStyle(accent)
                            Text(timelineDateLabel).lineLimit(1)
                            DaBinIcon(name: .down, baseSize: 8, tint: Palette.muted, hovered: iconHover.contains("date")).frame(width: 8, height: 8).font(.system(size: 8, weight: .semibold)).foregroundStyle(Palette.muted)
                        }.font(.system(size: 12, weight: .medium))
                            .frame(maxWidth: .infinity, minHeight: 30)
                            .background(accent.opacity(0.07), in: RoundedRectangle(cornerRadius: 7))
                            .contentShape(RoundedRectangle(cornerRadius: 7))
                    }.buttonStyle(.plain).accessibilityLabel("Choose date, \(timelineDateLabel)").accessibilityIdentifier("timeline-date")
                        .onHover { if $0 { iconHover.insert("date") } else { iconHover.remove("date") } }
                        .disabled(state.isNavigationBlocked)
                        .popover(isPresented: $showCalendar, arrowEdge: .bottom) {
                            TimelineCalendarPicker(state: state, weekly: state.route == .weekly) { showCalendar = false }
                                .environment(\.daBinAccent, accent)
                                .preferredColorScheme(theme.darkModeEnabled ? .dark : .light)
                                .hoverTooltips()
                        }
                    SmallIcon(symbol: "chevron.right", label: state.route == .weekly ? "Next week" : "Next day", size: 26) { moveTimeline(1) }
                        .disabled(state.isNavigationBlocked || Calendar.current.isDateInToday(state.route == .weekly ? state.weekEndingDay : state.selectedDay))
                }
                if isTimeline && !Calendar.current.isDateInToday(state.route == .weekly ? state.weekEndingDay : state.selectedDay) {
                    Button {
                        if state.route == .weekly { state.showCurrentWeek() } else { state.openDaily() }
                    } label: { DaBinIcon(systemName: "arrow.uturn.backward").frame(width: 22, height: 28) }
                    .buttonStyle(.plain).font(.system(size: 11)).foregroundStyle(accent)
                        .accessibilityLabel("Return to today").buddyHelp("Return to today")
                        .disabled(state.isNavigationBlocked)
                }
            }
            if state.route == .weekly { weeklySearchField }
            HStack(spacing: 6) {
                timelineModeToggle
                CaptureFilterStrip(selection: $state.filter, spacing: 2)
                Spacer(minLength: 0)
            }
            .accessibilityElement(children: .contain)
            .accessibilityLabel("Captions views and type filters")
            .accessibilityIdentifier("captions-toolbar")
        }
    }

    private var timelineModeToggle: some View {
        HStack(spacing: 2) {
            ForEach([BoardTimelineMode.daily, .weekly], id: \.self) { mode in
                let selected = isTimeline && state.timelineMode == mode
                Button { state.selectTimelineMode(mode) } label: {
                    Text(mode == .daily ? "Day" : "Week")
                        .font(.system(size: 12, weight: .semibold))
                        .frame(width: 38, height: 32)
                        .contentShape(RoundedRectangle(cornerRadius: 7))
                }.buttonStyle(.plain)
                    .foregroundStyle(selected ? accent : Palette.muted)
                    .background(selected ? accent.opacity(0.15) : Color.clear,
                                in: RoundedRectangle(cornerRadius: 7))
                    .accessibilityLabel(mode == .daily ? "Daily view" : "Weekly view")
                    .accessibilityAddTraits(selected ? .isSelected : [])
                    .accessibilityIdentifier(mode == .daily ? "timeline-mode-daily" : "timeline-mode-weekly")
                    .disabled(state.isNavigationBlocked)
                    .buddyHelp(mode == .daily ? "Captures for the selected day" : "Choose up to seven days with activity",
                               id: "timeline-mode-tooltip-\(mode == .daily ? "daily" : "weekly")")
            }
        }.padding(2).background(Palette.soft, in: RoundedRectangle(cornerRadius: 9))
            .accessibilityElement(children: .contain).accessibilityLabel("Captions calendar view")
            .daBinTutorialAnchor(.timelineModes)
    }

    private var timelineDateLabel: String {
        if state.route == .weekly, state.isCustomWeekSelection {
            let count = state.weeklyDays.count
            return count == 1 ? state.weeklyDays[0].formatted(.dateTime.month(.abbreviated).day()) : "\(count) selected days"
        }
        if state.route == .weekly, let first = state.weeklyDays.first {
            return "\(first.formatted(.dateTime.month(.abbreviated).day()))–\(state.weekEndingDay.formatted(.dateTime.month(.abbreviated).day()))"
        }
        return state.selectedDay.formatted(.dateTime.weekday(.abbreviated).month(.abbreviated).day())
    }
    private func moveTimeline(_ amount: Int) {
        if state.route == .weekly { state.moveWeek(amount) } else { state.moveDay(amount) }
    }
    private var routeTitle: String {
        switch state.route {
        case .search: return "Search"
        case .searchNote: return "Notes"
        case .newTask: return "New task"
        case .newNote: return "New note"
        case .detail: return state.selectedCapture?.isTask == true ? "Task" : "Capture"
        case .settings: return "Settings"
        case .trash: return "Recently Deleted"
        default: return "DaBin"
        }
    }
    private var undoBanner: some View {
        HStack {
            Text("Moved to Recently Deleted").font(.system(size: 12))
            Spacer(minLength: 4)
            Button("Undo") { Task { await state.undoLastRemoval() } }.buttonStyle(.plain).foregroundStyle(accent)
                .accessibilityIdentifier("card-delete-undo")
        }.padding(9).background(Palette.soft).accessibilityElement(children: .contain)
    }
    private func statusBanner(_ message: AppStatusMessage) -> some View {
        HStack(alignment: .top, spacing: 8) {
            DaBinIcon(systemName: message.symbol).foregroundStyle(message.severity == .error ? Palette.task : accent)
            Text(message.text).font(.system(size: 12)).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            Button { state.dismissNotification() } label: { DaBinIcon(name: .close, baseSize: 10, tint: Palette.foreground, hovered: iconHover.contains("dismiss")).frame(width: 10, height: 10).font(.system(size: 10)) }
                .buttonStyle(.plain).onHover { if $0 { iconHover.insert("dismiss") } else { iconHover.remove("dismiss") } }.buddyHelp("Dismiss message").accessibilityLabel("Dismiss message")
        }.padding(10).background(Palette.soft, in: RoundedRectangle(cornerRadius: 11))
            .padding(.horizontal, 14).padding(.vertical, 6)
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("app-notification-banner")
    }
}

@MainActor
struct CaptureFilterMenu: View {
    @Binding var selection: CaptureFilter
    var body: some View {
        Menu {
            Picker("Capture type", selection: $selection) {
                ForEach(CaptureFilter.allCases) { filter in Label(filter.title, daBinSystemImage: filter.buddySymbol).tag(filter) }
            }
        } label: {
            Label(selection == .all ? "Filters" : selection.title, daBinSystemImage: "line.3.horizontal.decrease", iconSize: 11).font(.system(size: 11))
        }.menuStyle(.borderlessButton).fixedSize()
            .accessibilityLabel("Filters, \(selection == .all ? "all capture types" : selection.title)")
    }
}

@MainActor
private struct BoardCaptureStatus: View {
    @ObservedObject var state: AppState
    @ObservedObject var service: AutoCaptureService
    @ObservedObject var settings: AutoCaptureSettings
    @Environment(\.daBinAccent) private var accent
    var body: some View {
        HStack(spacing: 7) {
            DaBinIcon(systemName: settings.isPaused || !settings.isEnabled ? "pause.circle" : "circle.fill", size: 8)
                .font(.system(size: 8)).foregroundStyle(accent).accessibilityHidden(true)
            Text(service.overallStatusText).font(.system(size: 11)).foregroundStyle(Palette.muted)
                .lineLimit(2).fixedSize(horizontal: false, vertical: true)
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Auto Capture: \(service.overallStatusText)")
                .accessibilityIdentifier("auto-capture-status")
            Spacer(minLength: 0)
            if let project = state.libraryProject {
                Label("Destination: \(project)", daBinSystemImage: "folder.fill", iconSize: 11)
                    .font(.system(size: 11, weight: .medium)).foregroundStyle(accent).lineLimit(1)
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("Auto Capture destination: \(project)")
                    .accessibilityIdentifier("auto-capture-destination")
            } else {
                Label("Destination: Unfiled", daBinSystemImage: "tray", iconSize: 11)
                    .font(.system(size: 11, weight: .medium)).foregroundStyle(Palette.muted).lineLimit(1)
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("Auto Capture destination: Unfiled")
                    .accessibilityIdentifier("auto-capture-destination")
            }
        }.padding(.horizontal, 16).padding(.vertical, 9)
            .background(Palette.background)
            .overlay(alignment: .top) { Rectangle().fill(Palette.line).frame(height: 1) }
            .daBinTutorialAnchor(.captureDestination)
    }
}
