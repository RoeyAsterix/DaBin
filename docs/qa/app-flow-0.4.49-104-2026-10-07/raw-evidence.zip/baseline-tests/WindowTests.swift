import AppKit
import ApplicationServices
import Foundation

@MainActor
private final class WindowNotificationClient: ReminderNotificationClient {
    var permissionRequests = 0
    var additions = 0
    func authorization() async -> ReminderAuthorization { .undetermined }
    func requestAuthorization() async throws -> Bool { permissionRequests += 1; return false }
    func pending() async -> [ScheduledReminder] { [] }
    func add(_ reminder: ScheduledReminder) async throws { additions += 1 }
    func removePending(_ identifiers: [String]) { }
    func removeDelivered(_ identifiers: [String]) { }
}

@MainActor
private final class WindowCompositionEditor: NSTextView {
    private(set) var cancellationCommands = 0
    override func cancelOperation(_ sender: Any?) {
        cancellationCommands += 1
        if hasMarkedText() { unmarkText() }
        else { super.cancelOperation(sender) }
    }
}

/// Exercises real AppKit panels using injected pointer observations. It neither
/// moves the system cursor nor reads/writes the general pasteboard or other apps.
@main struct WindowTests {
    @MainActor private static var checks = 0
    @MainActor private static var failures: [String] = []

    @MainActor private static func expect(_ value: @autoclosure () -> Bool, _ message: String) throws {
        checks += 1
        if !value() {
            failures.append(message)
            fputs("FAIL: \(message)\n", stderr)
        }
    }

    private static func cornerPoint(_ corner: ScreenCorner, frame: NSRect) -> NSPoint {
        NSPoint(x: corner.isRight ? frame.maxX - 1 : frame.minX + 1,
                y: corner.isTop ? frame.maxY - 1 : frame.minY + 1)
    }

    @MainActor private struct HeaderNode {
        let object: NSObject
        func value(_ name: String) -> Any? {
            let selector = NSSelectorFromString(name)
            return object.responds(to: selector) ? object.perform(selector)?.takeUnretainedValue() : nil
        }
        var identifier: String? { value("accessibilityIdentifier") as? String }
        var role: String? { value("accessibilityRole") as? String }
        var label: String? { value("accessibilityLabel") as? String }
        var frame: NSRect {
            let selector = NSSelectorFromString("accessibilityFrame")
            guard object.responds(to: selector) else { return .zero }
            typealias FrameGetter = @convention(c) (AnyObject, Selector) -> NSRect
            return unsafeBitCast(object.method(for: selector), to: FrameGetter.self)(object, selector)
        }
        func press() -> Bool {
            let selector = NSSelectorFromString("accessibilityPerformPress")
            guard object.responds(to: selector) else { return false }
            typealias PressAction = @convention(c) (AnyObject, Selector) -> Bool
            return unsafeBitCast(object.method(for: selector), to: PressAction.self)(object, selector)
        }
    }

    private final class AccessibilityActivationResult: @unchecked Sendable {
        private let lock = NSLock()
        private var result: AXError?
        var value: AXError? { lock.lock(); defer { lock.unlock() }; return result }
        func complete(_ value: AXError) { lock.lock(); result = value; lock.unlock() }
    }

    @MainActor private static func verifyLogoProjectsControl(controller: CornerController) throws {
        let hosting = controller.captureHostingView
        let originalRoute = controller.state.route
        try expect(originalRoute == .daily, "Logo navigation is exercised from the existing Daily drag fixture")
        // SwiftUI materializes its virtual native AX tree on first request.
        // Request only our process from a worker, while AppKit services the
        // existing synchronous fixture's main runloop. The request is bounded.
        let activation = AccessibilityActivationResult()
        DispatchQueue.global(qos: .userInitiated).async {
            let process = AXUIElementCreateApplication(ProcessInfo.processInfo.processIdentifier)
            AXUIElementSetMessagingTimeout(process, 3)
            var windows: CFTypeRef?
            activation.complete(AXUIElementCopyAttributeValue(process, kAXWindowsAttribute as CFString, &windows))
        }
        let deadline = Date().addingTimeInterval(4)
        while activation.value == nil && Date() < deadline {
            RunLoop.main.run(until: Date().addingTimeInterval(0.01))
        }
        try expect(activation.value == .success, "The retained fixture activates its own native accessibility tree")
        hosting.layoutSubtreeIfNeeded()
        var nodes: [HeaderNode] = []
        var visited = Set<ObjectIdentifier>()
        func visit(_ candidate: Any, depth: Int) {
            guard depth < 40, let object = candidate as? NSObject,
                  visited.insert(ObjectIdentifier(object)).inserted else { return }
            nodes.append(HeaderNode(object: object))
            for name in ["accessibilityChildren", "accessibilityChildrenInNavigationOrder", "accessibilityContents"] {
                for child in HeaderNode(object: object).value(name) as? [Any] ?? [] { visit(child, depth: depth + 1) }
            }
            if let view = object as? NSView { view.subviews.forEach { visit($0, depth: depth + 1) } }
        }
        visit(hosting, depth: 0)
        NSAccessibility.unignoredChildren(from: [hosting]).forEach { visit($0, depth: 0) }
        guard let logo = nodes.first(where: { $0.identifier == "board-logo-projects" }) else {
            throw NSError(domain: "DaBinWindowTests", code: 5,
                userInfo: [NSLocalizedDescriptionKey: "The production header exposes board-logo-projects"])
        }
        try expect(logo.role == NSAccessibility.Role.button.rawValue && logo.label == "Open Projects",
                   "The logo is the native Open Projects AXButton rather than a decorative header")
        let logoFrame = logo.frame
        try expect(abs(logoFrame.width - 68) <= 0.5 && abs(logoFrame.height - 28) <= 0.5,
                   "The native logo button retains its complete 68-by-28 frame")
        try expect(controller.board.frame.contains(logoFrame), "The logo target fits the retained Daily panel")
        func handles(in view: NSView) -> [WindowDragHandleView] {
            ((view as? WindowDragHandleView).map { [$0] } ?? []) + view.subviews.flatMap { handles(in: $0) }
        }
        let dragHandles = handles(in: hosting).filter { !$0.isHiddenOrHasHiddenAncestor && !$0.bounds.isEmpty }
        func screenFrame(_ handle: NSView) -> NSRect {
            controller.board.convertToScreen(handle.convert(handle.bounds, to: nil))
        }
        guard let flexible = dragHandles.max(by: { $0.bounds.width < $1.bounds.width }) else {
            throw NSError(domain: "DaBinWindowTests", code: 6,
                userInfo: [NSLocalizedDescriptionKey: "The flexible native header drag grip remains mounted"])
        }
        let gripFrame = screenFrame(flexible)
        try expect(flexible.bounds.width >= 28 && flexible.bounds.height >= 28
                   && abs(gripFrame.midY - logoFrame.midY) <= 1 && gripFrame.minX >= logoFrame.maxX,
                   "The adjacent blank first-row area retains a separate visible native drag grip")
        try expect(!dragHandles.contains { screenFrame($0).intersects(logoFrame) },
                   "No native drag overlay covers the logo button's clickable frame")
        let accessiblePressAccepted = logo.press()
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        if !accessiblePressAccepted && controller.state.route == originalRoute {
            // Some own-process SwiftUI proxies return false from AXPress.
            // Keep action delivery native: resolve a real matching control, or
            // dispatch a normal click only inside this retained fixture window.
            let nativeButton = (logo.object as? NSButton) ?? (logo.object as? NSButtonCell).flatMap { cell in
                guard let button = cell.controlView as? NSButton, button.cell === cell else { return nil }
                return button
            }
            if let button = nativeButton {
                let ownsButton = button.window === controller.board && button.isEnabled
                    && !button.isHiddenOrHasHiddenAncestor
                try expect(ownsButton, "The actual logo control belongs to the retained visible fixture")
                guard ownsButton else {
                    throw NSError(domain: "DaBinWindowTests", code: 8,
                        userInfo: [NSLocalizedDescriptionKey: "Refusing to activate a logo control outside the visible fixture"])
                }
                button.performClick(nil)
                print("LOGO_DISPATCH: owning NSButton performClick; AX proxy=\(type(of: logo.object))")
            } else {
                let window = controller.board
                let application = NSApplication.shared
                application.activate(); window.makeKey()
                RunLoop.main.run(until: Date().addingTimeInterval(0.12))
                try expect(application.isActive && window.isKeyWindow,
                           "The own-window logo click starts from the active retained fixture")
                let point = window.convertPoint(fromScreen: NSPoint(x: logoFrame.midX, y: logoFrame.midY))
                try expect(window.contentView?.bounds.contains(point) == true && window.attachedSheet == nil,
                           "The logo click stays inside its own unobstructed fixture window")
                let timestamp = ProcessInfo.processInfo.systemUptime
                guard let down = NSEvent.mouseEvent(with: .leftMouseDown, location: point, modifierFlags: [],
                    timestamp: timestamp, windowNumber: window.windowNumber, context: nil,
                    eventNumber: 1, clickCount: 1, pressure: 1),
                      let up = NSEvent.mouseEvent(with: .leftMouseUp, location: point, modifierFlags: [],
                    timestamp: timestamp + 0.02, windowNumber: window.windowNumber, context: nil,
                    eventNumber: 2, clickCount: 1, pressure: 0) else {
                    throw NSError(domain: "DaBinWindowTests", code: 7,
                        userInfo: [NSLocalizedDescriptionKey: "Could not construct the own-window logo click"])
                }
                application.postEvent(up, atStart: true)
                window.sendEvent(down)
                if let remaining = application.nextEvent(matching: .leftMouseUp, until: Date(),
                                                         inMode: .default, dequeue: true) {
                    let ownsRemaining = remaining.windowNumber == window.windowNumber
                    try expect(ownsRemaining, "The remaining logo mouse-up belongs only to this fixture")
                    if ownsRemaining { window.sendEvent(remaining) }
                    else { application.postEvent(remaining, atStart: true) }
                }
                print("LOGO_DISPATCH: own-window native click; AX proxy=\(type(of: logo.object))")
            }
            RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        } else {
            print("LOGO_DISPATCH: AXPress accepted=\(accessiblePressAccepted); route=\(controller.state.route)")
        }
        try expect(controller.state.route == .library, "Native logo activation opens the existing Projects route")
        controller.state.back()
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        try expect(controller.state.route == originalRoute,
                   "Back restores the original Daily fixture before movement and persistence checks")
    }

    @MainActor private static func verifyExpandedAutomaticDragging(screen: NSScreen, root: URL) throws {
        let suite = "DaBinAutomaticDragTests.\(UUID().uuidString)"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = try CaptureStore(root: root.appendingPathComponent("AutomaticDragging"))
        let previews = PreviewService(store: store)
        defer { previews.cancelNetwork() }
        let state = AppState(store: store, previews: previews,
                             reminders: ReminderService(store: store, client: WindowNotificationClient()))
        let anchor = NSPoint(x: screen.visibleFrame.minX + 30, y: screen.visibleFrame.maxY - 35)
        defaults.set([Double(anchor.x), Double(anchor.y)], forKey: CornerController.boardPlacementKey)
        var controller = CornerController(state: state, input: InputService(store: store),
                                          placementDefaults: defaults, animateRobotTransitions: false)
        defer { controller.shutdown() }
        func freshController() {
            controller.shutdown()
            controller = CornerController(state: state, input: InputService(store: store),
                                          placementDefaults: defaults, animateRobotTransitions: false)
            state.openDaily()
            controller.showBoard(immediate: true)
            RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        }

        func handles(in view: NSView) -> [WindowDragHandleView] {
            ((view as? WindowDragHandleView).map { [$0] } ?? [])
                + view.subviews.flatMap { handles(in: $0) }
        }
        func event(_ type: NSEvent.EventType, screenPoint: NSPoint) -> NSEvent {
            NSEvent.mouseEvent(with: type, location: controller.board.convertPoint(fromScreen: screenPoint),
                              modifierFlags: [], timestamp: 30, windowNumber: controller.board.windowNumber,
                              context: nil, eventNumber: 3, clickCount: 1, pressure: 1)!
        }
        func dragExpanded(label: String, automaticRestoreFrame: NSRect? = nil) throws -> NSRect {
            let normal = automaticRestoreFrame ?? controller.board.frame
            if automaticRestoreFrame == nil { controller.toggleExpandedWindow() }
            RunLoop.main.run(until: Date().addingTimeInterval(0.12))
            guard let rootView = controller.board.contentView,
                  let handle = handles(in: rootView).max(by: { $0.bounds.width < $1.bounds.width }) else {
                throw NSError(domain: "DaBinWindowTests", code: 4,
                              userInfo: [NSLocalizedDescriptionKey: "Automatic expanded board retains its native drag handle"])
            }
            let pointer = NSPoint(x: controller.board.frame.midX, y: controller.board.frame.maxY - 42)
            // Own-view delivery uses the event's pointer, never the system cursor.
            let previousCallback = handle.onDragStarted
            defer { handle.onDragStarted = previousCallback }
            handle.onDragStarted = { controller.beginBoardDrag(pointer: pointer) }
            handle.mouseDown(with: event(.leftMouseDown, screenPoint: pointer))
            let restored = controller.board.frame
            try expect(restored.size == normal.size,
                       "\(label): starting an expanded drag retains its automatic normal dimensions")
            let requested = restored.offsetBy(dx: 12, dy: -24)
            let expected = BoardResizeGeometry.fitted(requested, visible: screen.visibleFrame, minimum: .zero)
            let release = NSPoint(x: pointer.x + expected.minX - restored.minX,
                                  y: pointer.y + expected.minY - restored.minY)
            handle.mouseDragged(with: event(.leftMouseDragged, screenPoint: release))
            handle.mouseUp(with: event(.leftMouseUp, screenPoint: release))
            controller.finishBoardDragIfReleased(pressedMouseButtons: 0, pointer: release)
            RunLoop.main.run(until: Date().addingTimeInterval(0.12))
            try expect(defaults.object(forKey: CornerController.boardSizeKey) == nil,
                       "\(label): moving an automatic board does not create a manual size preference")
            return controller.board.frame
        }

        state.openDaily()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        let short = controller.board.frame
        try expect(short.height < BoardResizeGeometry.minimumSize.height,
                   "Empty Daily exercises a valid automatic height below the manual resize minimum")
        let movedShort = try dragExpanded(label: "Empty Daily")
        try expect(movedShort.size == short.size,
                   "Dragging an expanded empty Daily preserves its short automatic frame after release")
        freshController()
        let shortBeforeRestore = controller.board.frame
        controller.toggleExpandedWindow()
        controller.toggleExpandedWindow()
        try expect(controller.board.frame == shortBeforeRestore,
                   "Expand and restore retains the exact short automatic Daily frame")
        let restoredShort = controller.board.frame
        state.showSettings()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        let expectedSettings = CornerGeometry.movedPanelFrame(topLeft: NSPoint(x: restoredShort.minX, y: restoredShort.maxY),
                                                             visible: screen.visibleFrame, preferredHeight: 670)
        try expect(controller.board.frame == expectedSettings,
                   "Restoring an automatic board retains content-driven sizing when opening Settings")

        for offset in -6...0 {
            let stamp = Calendar.current.date(byAdding: .day, value: offset, to: Date())!
            _ = try store.capture(text: "Isolated automatic Week drag fixture \(offset)", at: stamp)
        }
        freshController()
        let compact = controller.board.frame
        state.openWeekly()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.40))
        let direction = state.weeklyExpansionDirection
        try expect(state.weeklyVisibleDays.count == 7 && controller.board.frame == screen.visibleFrame,
                   "Automatic Week drag fixture opens all seven columns in the full display safe area")
        let movedWeek = try dragExpanded(label: "Populated Week", automaticRestoreFrame: compact)
        let compactAnchor = CornerGeometry.compactTopLeft(weeklyFrame: movedWeek, compactWidth: compact.width,
                                                         direction: direction)
        state.back()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.40))
        let expectedCompact = CornerGeometry.movedPanelFrame(topLeft: compactAnchor, visible: screen.visibleFrame,
                                                            preferredHeight: compact.height)
        try expect(state.route == .daily && controller.board.frame == expectedCompact,
                   "Back after dragging an expanded automatic Week restores the compact Daily frame at its moved anchor")
        freshController()
        let beforeWeekRestore = controller.board.frame
        state.openWeekly()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.40))
        let automaticWeek = controller.board.frame
        controller.toggleExpandedWindow()
        controller.toggleExpandedWindow()
        try expect(controller.board.frame == automaticWeek,
                   "Restore and expand returns to the exact automatic Week full view")
        state.back()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.40))
        try expect(state.route == .daily && controller.board.frame == beforeWeekRestore,
                   "Back after restoring and expanding Week retains content-driven compact Daily sizing")

        let rightAnchor = NSPoint(x: screen.visibleFrame.maxX - compact.width,
                                  y: screen.visibleFrame.maxY - 35)
        defaults.set([Double(rightAnchor.x), Double(rightAnchor.y)], forKey: CornerController.boardPlacementKey)
        freshController()
        let rightCompact = controller.board.frame
        state.openWeekly()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.40))
        let leftOpeningWeek = controller.board.frame
        try expect(state.weeklyExpansionDirection == .left && leftOpeningWeek == screen.visibleFrame,
                   "Right-side automatic Week fills the safe area and remembers its compact right anchor")
        controller.toggleExpandedWindow()
        controller.toggleExpandedWindow()
        try expect(controller.board.frame == leftOpeningWeek,
                   "Restore and expand retains the exact right-anchored Week full view")
        state.back()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.40))
        try expect(state.route == .daily && controller.board.frame == rightCompact,
                   "Back after restoring a left-opening automatic Week preserves the compact right-side anchor")

        state.openWeekly()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.40))
        state.showSettings()
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.40))
        let rightSettings = CornerGeometry.movedPanelFrame(topLeft: NSPoint(x: rightCompact.minX, y: rightCompact.maxY),
                                                          visible: screen.visibleFrame, preferredHeight: 670)
        try expect(state.route == .settings && controller.board.frame == rightSettings,
                   "Opening Settings from automatic Week full view restores the compact right-side anchor")
    }

    @MainActor private static func verifyCompositionEscape(root: URL) throws {
        let suite = "DaBinCompositionEscape.\(UUID().uuidString)"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = try CaptureStore(root: root.appendingPathComponent("CompositionEscape"), repairArchiveOnOpen: false)
        let previews = PreviewService(store: store, defaults: defaults)
        defer { previews.shutdown(); store.cancelArchiveRepair() }
        let pasteboard = NSPasteboard(name: .init(suite))
        defer { pasteboard.releaseGlobally() }
        let input = InputService(store: store)
        let autoCapture = AutoCaptureService(settings: AutoCaptureSettings(defaults: defaults), input: input,
            pasteboardProvider: { pasteboard }, sourceApplicationProvider: { nil })
        defer { autoCapture.shutdown() }
        let reminders = ReminderService(store: store, client: WindowNotificationClient())
        defer { reminders.shutdownPresentation() }
        let state = AppState(store: store, previews: previews, reminders: reminders, autoCapture: autoCapture,
            captureClipboard: CaptureClipboardService(pasteboard: pasteboard),
            folderOpener: { _ in fatalError("Composition QA must not open external files") })
        defer { state.focusSessions.shutdown() }
        let controller = CornerController(state: state, input: input,
            placementDefaults: defaults, animateRobotTransitions: false)
        defer { controller.shutdown() }
        state.openNewTask()
        state.newTaskDraft.text = "Retain this composition draft"
        controller.showBoard(immediate: true)
        NSApplication.shared.activate()
        controller.board.makeKey()
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        let editor = WindowCompositionEditor(frame: NSRect(x: 5, y: 5, width: 150, height: 30))
        controller.board.contentView!.addSubview(editor)
        defer { editor.removeFromSuperview() }
        try expect(controller.board.isKeyWindow && controller.board.makeFirstResponder(editor),
                   "Composition Escape uses the actual key panel and its own native editor")
        editor.setMarkedText("かな", selectedRange: NSRange(location: 2, length: 0),
                             replacementRange: NSRange(location: NSNotFound, length: 0))
        try expect(editor.hasMarkedText(), "Composition Escape starts with real native marked text")
        var tutorialEscapes = 0
        state.onTutorialEscape = { tutorialEscapes += 1; return false }
        defer { state.onTutorialEscape = nil }
        func escape() throws {
            guard let event = NSEvent.keyEvent(with: .keyDown, location: .zero, modifierFlags: [],
                timestamp: ProcessInfo.processInfo.systemUptime, windowNumber: controller.board.windowNumber,
                context: nil, characters: "\u{1b}", charactersIgnoringModifiers: "\u{1b}",
                isARepeat: false, keyCode: 53) else {
                throw NSError(domain: "DaBinWindowTests", code: 9,
                    userInfo: [NSLocalizedDescriptionKey: "Could not construct own-panel Escape"])
            }
            // Dispatch through NSApplication so the installed local monitor and
            // AppKit's native cancelOperation key binding both participate.
            NSApplication.shared.sendEvent(event)
        }
        try escape()
        try expect(editor.cancellationCommands == 1 && !editor.hasMarkedText(),
                   "Marked-text Escape reaches the editor's native cancellation command")
        try expect(controller.board.isVisible && controller.board.firstResponder === editor
                   && state.route == .newTask && state.newTaskDraft.text == "Retain this composition draft",
                   "Cancelling composition retains the same panel, editor, route and pending draft")
        try expect(tutorialEscapes == 0,
                   "A marked-text Escape reaches its editor before tutorial or window dismissal")
        try escape()
        try expect(!controller.board.isVisible && editor.cancellationCommands == 1 && tutorialEscapes == 1,
                   "The next ordinary Escape preserves existing window dismissal")
        try expect(state.route == .newTask && state.newTaskDraft.text == "Retain this composition draft"
                   && store.captures.isEmpty && !input.isBusy,
                   "Ordinary dismissal preserves the unsaved draft and produces no capture")
    }

    @MainActor private static func verifyGlobalShortcutActions(screen: NSScreen, root: URL) throws {
        let suite = "DaBinShortcutWindows.\(UUID().uuidString)"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = try CaptureStore(root: root.appendingPathComponent("ShortcutActions"))
        let previews = PreviewService(store: store, defaults: defaults)
        defer { previews.cancelNetwork() }
        let pasteboard = NSPasteboard(name: .init("DaBinShortcutWindows.\(UUID().uuidString)"))
        defer { pasteboard.releaseGlobally() }
        let settings = AutoCaptureSettings(defaults: defaults)
        let input = InputService(store: store)
        let autoCapture = AutoCaptureService(settings: settings, input: input,
            pasteboardProvider: { pasteboard }, sourceApplicationProvider: { nil })
        defer { autoCapture.shutdown() }
        let state = AppState(store: store, previews: previews,
            reminders: ReminderService(store: store, client: WindowNotificationClient()), autoCapture: autoCapture)
        let controller = CornerController(state: state, input: input,
            placementDefaults: defaults, animateRobotTransitions: false)
        defer { controller.shutdown() }
        state.openNewTask()
        state.newTaskDraft.text = "Keep this shortcut draft"
        controller.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        let normal = controller.board.frame
        controller.dismiss()
        controller.toggleExpandedWindowFromShortcut()
        try expect(controller.board.isVisible && controller.board.frame == screen.visibleFrame
                   && state.route == .newTask && state.newTaskDraft.text == "Keep this shortcut draft",
                   "The hidden full-screen shortcut opens expanded without losing the route or draft")
        controller.toggleExpandedWindowFromShortcut()
        try expect(controller.board.frame == normal,
                   "The full-screen shortcut restores the exact previous window geometry")
        try expect(defaults.object(forKey: CornerController.boardSizeKey) == nil,
                   "Temporary full-screen shortcuts never replace the saved normal window size")
        state.newTaskDraft.pendingChecklistText = String(repeating: "x", count: 501)
        state.newTaskDraft.validationFailed = true
        controller.toggleExpandedWindowFromShortcut()
        try expect(controller.board.frame == screen.visibleFrame && state.route == .newTask,
                   "An invalid draft can still expand without navigating away")
        controller.toggleExpandedWindowFromShortcut()
        controller.toggleRecordingFromShortcut()
        try expect(state.route == .newTask && !settings.isEnabled && !state.autoCaptureSetupRequested,
                   "Unconfigured recording respects draft validation before opening setup")
        state.newTaskDraft.pendingChecklistText = ""
        state.newTaskDraft.validationFailed = false
        let composition = NSTextView(frame: NSRect(x: 5, y: 5, width: 150, height: 30))
        controller.board.contentView!.addSubview(composition)
        try expect(controller.board.makeFirstResponder(composition),
                   "The shortcut fixture focuses its own native composition editor")
        composition.setMarkedText("かな", selectedRange: NSRange(location: 2, length: 0),
                                  replacementRange: NSRange(location: NSNotFound, length: 0))
        try expect(composition.hasMarkedText(), "The native composition fixture has active marked text")
        controller.toggleRecordingFromShortcut()
        try expect(state.route == .newTask && composition.hasMarkedText() && !settings.isEnabled,
                   "Unconfigured recording never leaves the current route during native text composition")
        settings.setClipboardEnabled(true)
        settings.setPaused(true)
        let exclusions = settings.excludedBundleIdentifiers
        controller.toggleRecordingFromShortcut()
        try expect(!settings.isPaused && autoCapture.isRunning && settings.isClipboardEnabled
                   && !settings.isScreenshotsEnabled && state.route == .newTask,
                   "Configured recording resumes during text composition without changing the current draft")
        state.newTaskDraft.pendingChecklistText = String(repeating: "x", count: 501)
        state.newTaskDraft.validationFailed = true
        controller.toggleRecordingFromShortcut()
        try expect(settings.isPaused && !autoCapture.isRunning
                   && settings.excludedBundleIdentifiers == exclusions && state.route == .newTask,
                   "Recording can always pause a configured channel while preserving exclusions and the draft")
        state.newTaskDraft.pendingChecklistText = ""
        state.newTaskDraft.validationFailed = false
        composition.unmarkText()
        controller.board.makeFirstResponder(nil)
        composition.removeFromSuperview()
        settings.setEnabled(false)
        state.openDaily(); controller.dismiss()
        controller.toggleRecordingFromShortcut()
        try expect(controller.board.isVisible && state.route == .settings && !settings.isEnabled
                   && !settings.isClipboardEnabled && !settings.isScreenshotsEnabled,
                   "Unconfigured recording reveals setup without silently enabling a source")
        try expect(store.captures.isEmpty && !input.isBusy,
                   "Shortcut fixtures produce no captures or paste operations")
    }

    @MainActor static func main() throws {
        let application = NSApplication.shared
        application.setActivationPolicy(.accessory)
        application.finishLaunching()
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("DaBinWindowTests-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: root) }
        let placementSuite = "DaBinWindowTests.\(UUID().uuidString)"
        let placementDefaults = UserDefaults(suiteName: placementSuite)!
        defer { placementDefaults.removePersistentDomain(forName: placementSuite) }
        let store = try CaptureStore(root: root)
        let notificationClient = WindowNotificationClient()
        let previews = PreviewService(store: store)
        let reminders = ReminderService(store: store, client: notificationClient)
        let robotPlacement = RobotPlacementSettings(defaults: placementDefaults)
        let state = AppState(store: store, previews: previews, reminders: reminders,
                             robotPlacement: robotPlacement)
        let input = InputService(store: store, stagingRoot: root.appendingPathComponent("Promises"))
        let theme = ThemeSettings(defaults: placementDefaults, systemDarkMode: false)
        let controller = CornerController(state: state, input: input, placementDefaults: placementDefaults,
                                          theme: theme, animateRobotTransitions: false)
        defer {
            controller.dismiss()
            controller.bin.orderOut(nil)
            controller.board.orderOut(nil)
            previews.cancelNetwork()
        }
        let ownedWindows = [controller.bin, controller.board]
        try expect(controller.board.appearance?.name == .aqua
                   && controller.captureHostingView.effectiveAppearance.bestMatch(from: [.aqua, .darkAqua]) == .aqua,
                   "The nested robot-frame host adopts the explicit light theme before presentation")
        theme.setDarkMode(true)
        try expect(controller.board.appearance?.name == .darkAqua
                   && controller.captureHostingView.effectiveAppearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua,
                   "Changing theme updates both native window and nested hosting view immediately")
        theme.setDarkMode(false)
        try expect(ownedWindows.filter(\.isVisible).isEmpty, "At launch both DaBin panels are hidden")
        try expect(application.windows.filter(\.isVisible).isEmpty, "Test process has zero visible windows at launch")
        try expect(controller.bin.backgroundColor == .clear && !controller.bin.isOpaque, "Robot panel has no opaque background")
        try expect(controller.bin.frame.width <= 72 && controller.bin.frame.height <= 88, "Hidden robot owns only its compact panel bounds")
        let screens = NSScreen.screens
        try expect(!screens.isEmpty, "Window checks require an attached screen")
        guard !screens.isEmpty else { exit(1) }
        var clock = Date().addingTimeInterval(10)

        for (screenIndex, screen) in screens.enumerated() {
            let away = NSPoint(x: screen.visibleFrame.midX, y: screen.visibleFrame.midY)
            for corner in ScreenCorner.allCases {
                controller.pollPointer(at: away, now: clock)
                let point = cornerPoint(corner, frame: screen.frame)
                clock = clock.addingTimeInterval(3)
                controller.pollPointer(at: point, now: clock)
                let label = "screen \(screenIndex), \(corner.rawValue)"
                try expect(controller.bin.isVisible, "\(label): corner reveals robot")
                try expect(!controller.board.isVisible, "\(label): corner does not open Daily")
                try expect(ownedWindows.filter(\.isVisible).count == 1, "\(label): only the robot is visible")
                let expected = CornerGeometry.robotFrame(corner: corner, visible: screen.visibleFrame)
                try expect(controller.bin.frame == expected, "\(label): robot appears at the matching visible-screen corner")

                // Deliberately take longer than the 0.8-second exit grace at each
                // sample. The protected path, including Dock/menu-bar insets, keeps it open.
                let target = NSPoint(x: controller.bin.frame.midX, y: controller.bin.frame.midY)
                for step in 1...6 {
                    let progress = CGFloat(step) / 6
                    let pointOnPath = NSPoint(x: point.x + (target.x - point.x) * progress,
                                              y: point.y + (target.y - point.y) * progress)
                    clock = clock.addingTimeInterval(2)
                    controller.pollPointer(at: pointOnPath, now: clock)
                    try expect(controller.bin.isVisible, "\(label): slow corner-to-robot path sample \(step) stays visible")
                    try expect(controller.bin.frame == expected, "\(label): corner-to-robot path does not reposition the target")
                }
                clock = clock.addingTimeInterval(3)
                controller.pollPointer(at: away, now: clock)
                try expect(ownedWindows.filter(\.isVisible).isEmpty, "\(label): pointer away for three seconds hides all DaBin UI")
            }
        }

        let syntheticFrame = NSRect(x: 2560, y: 458, width: 1512, height: 982)
        let syntheticVisible = NSRect(x: 2560, y: 458, width: 1512, height: 950)
        let syntheticLeft = NSRect(x: 2560, y: 1408, width: 663, height: 32)
        let syntheticRight = NSRect(x: 3408, y: 1408, width: 664, height: 32)
        let syntheticIsland = CornerGeometry.cameraIslandRect(frame: syntheticFrame, safeAreaTop: 32,
                                                              auxiliaryLeft: syntheticLeft,
                                                              auxiliaryRight: syntheticRight)
        try expect(syntheticIsland == NSRect(x: 3223, y: 1408, width: 185, height: 32),
                   "Camera island is derived from the gap between macOS auxiliary menu-bar areas")
        if let syntheticIsland {
            let islandRobot = CornerGeometry.robotFrame(cameraIsland: syntheticIsland, visible: syntheticVisible)
            try expect(syntheticVisible.contains(islandRobot) && abs(islandRobot.midX - syntheticIsland.midX) <= 0.5,
                       "Camera-island robot is centered immediately below the cutout and stays visible")
            try expect(islandRobot.size == NSSize(width: 232, height: 150)
                       && islandRobot.maxY == syntheticIsland.minY,
                       "Manual island choreography has a wide stage attached to the real underside")
            let islandInteraction = CornerGeometry.robotInteractionFrame(in: islandRobot, target: .cameraIsland)
            let islandBody = CornerGeometry.robotBodyFrame(in: islandRobot, target: .cameraIsland)
            try expect(islandInteraction.size == NSSize(width: 128, height: 130)
                       && islandInteraction.midX == islandRobot.midX
                       && islandInteraction.maxY == islandRobot.maxY
                       && islandRobot.contains(islandInteraction),
                       "Island clicks and drops use a central top-aligned target inside the swept stage")
            try expect(islandBody.size == NSSize(width: 88, height: 108)
                       && islandBody.maxY == islandRobot.maxY - 8
                       && islandInteraction.contains(islandBody),
                       "Board expansion starts at the visible central body rather than the full stage")
            let islandBoard = CornerGeometry.panelFrame(robot: islandRobot, visible: syntheticVisible,
                                                        target: .cameraIsland)
            try expect(syntheticVisible.contains(islandBoard) && abs(islandBoard.midX - syntheticIsland.midX) <= 0.5,
                       "Camera-island Daily opens below the centered robot and stays on screen")
        }
        let smallIslandStage = NSRect(x: -80, y: -40, width: 60, height: 70)
        try expect(CornerGeometry.robotInteractionFrame(in: smallIslandStage, target: .cameraIsland) == smallIslandStage
                   && smallIslandStage.contains(CornerGeometry.robotBodyFrame(in: smallIslandStage, target: .cameraIsland)),
                   "Constrained stages keep both hit and transition geometry within their bounds")
        try expect(CornerGeometry.cameraIslandRect(frame: syntheticFrame, safeAreaTop: 0,
                                                   auxiliaryLeft: nil, auxiliaryRight: nil) == nil,
                   "A display without safe-area and auxiliary data is not guessed to have an island")
        try expect(CornerGeometry.cameraIslandRect(frame: syntheticFrame, safeAreaTop: 32,
                                                   auxiliaryLeft: syntheticRight,
                                                   auxiliaryRight: syntheticLeft) == nil,
                   "Overlapping or reversed auxiliary regions cannot form a camera island")
        let negativeNotchFrame = NSRect(x: -1728, y: -200, width: 1728, height: 1117)
        let negativeNotchVisible = NSRect(x: -1728, y: -200, width: 1728, height: 1085)
        let negativeLeft = NSRect(x: -1728, y: 885, width: 770, height: 32)
        let negativeRight = NSRect(x: -770, y: 885, width: 770, height: 32)
        let negativeIsland = CornerGeometry.cameraIslandRect(frame: negativeNotchFrame, safeAreaTop: 32,
                                                             auxiliaryLeft: negativeLeft,
                                                             auxiliaryRight: negativeRight)
        try expect(negativeIsland == NSRect(x: -958, y: 885, width: 188, height: 32),
                   "Camera-island geometry supports displays with negative coordinates")
        if let negativeIsland {
            try expect(negativeNotchVisible.contains(CornerGeometry.robotFrame(cameraIsland: negativeIsland,
                                                                               visible: negativeNotchVisible)),
                       "Negative-coordinate island robot remains inside its display")
        }

        if let islandScreen = screens.first(where: { CornerGeometry.cameraIslandRect(on: $0) != nil }),
           let trigger = CornerGeometry.cameraIslandTriggerFrame(on: islandScreen) {
            robotPlacement.setHome(.cameraIsland)
            let islandAway = NSPoint(x: islandScreen.visibleFrame.minX + 40,
                                     y: islandScreen.visibleFrame.midY)
            controller.pollPointer(at: islandAway, now: clock.addingTimeInterval(1))
            controller.pollPointer(at: NSPoint(x: trigger.midX, y: trigger.minY + 2),
                                   now: clock.addingTimeInterval(2))
            try expect(controller.bin.isVisible, "Camera-island preference reveals the robot from the top center")
            try expect(controller.bin.frame == CornerGeometry.robotFrame(target: .cameraIsland, on: islandScreen),
                       "Live island reveal uses the detected cutout geometry")
            let transparentEdge = NSPoint(x: controller.bin.frame.minX + 3, y: controller.bin.frame.midY)
            controller.pollPointer(at: transparentEdge, now: clock.addingTimeInterval(2.1), pressedMouseButtons: 0)
            try expect(controller.bin.isVisible && controller.bin.ignoresMouseEvents && !controller.bin.isKeyWindow,
                       "The island animation margins pass clicks through and never take hover focus")
            let body = controller.robot.bodyBounds
            let islandBodyPoint = NSPoint(x: controller.bin.frame.minX + body.midX, y: controller.bin.frame.minY + body.midY)
            controller.pollPointer(at: islandBodyPoint, now: clock.addingTimeInterval(2.2), pressedMouseButtons: 0)
            try expect(!controller.bin.ignoresMouseEvents && controller.bin.isKeyWindow,
                       "The central island robot remains an immediate hover-paste target")
            controller.robot.onDragState?(true)
            controller.pollPointer(at: transparentEdge, now: clock.addingTimeInterval(2.3), pressedMouseButtons: 1)
            try expect(!controller.bin.ignoresMouseEvents && controller.bin.isVisible,
                       "An accepted drag retains its destination until AppKit finishes the transfer")
            controller.robot.onDragState?(false)
            controller.pollPointer(at: transparentEdge, now: clock.addingTimeInterval(2.4), pressedMouseButtons: 0)
            try expect(controller.bin.ignoresMouseEvents && !controller.bin.isKeyWindow,
                       "Ending a drag restores transparent island margins and releases hover focus")
            controller.dismiss()
            controller.pollPointer(at: islandAway, now: clock.addingTimeInterval(3))
        }
        if let external = screens.first(where: { CornerGeometry.cameraIslandRect(on: $0) == nil }) {
            robotPlacement.setHome(.cameraIsland)
            let externalCorner = cornerPoint(.topRight, frame: external.frame)
            controller.pollPointer(at: NSPoint(x: external.visibleFrame.midX, y: external.visibleFrame.midY),
                                   now: clock.addingTimeInterval(4))
            controller.pollPointer(at: externalCorner, now: clock.addingTimeInterval(5))
            try expect(controller.bin.isVisible,
                       "A display without an island keeps corner reveal while island mode is selected")
            try expect(controller.bin.frame == CornerGeometry.robotFrame(corner: .topRight,
                                                                          visible: external.visibleFrame),
                       "External-display fallback uses normal corner geometry")
        }
        robotPlacement.setHome(.corners)

        let screen = screens[0]
        let corner = ScreenCorner.bottomRight
        let point = cornerPoint(corner, frame: screen.frame)
        let away = NSPoint(x: screen.visibleFrame.midX, y: screen.visibleFrame.midY)
        clock = clock.addingTimeInterval(3)
        controller.pollPointer(at: away, now: clock.addingTimeInterval(-0.1))
        controller.pollPointer(at: point, now: clock)
        try expect(controller.bin.isVisible, "Robot visible before opening Daily")
        try expect(!controller.bin.ignoresMouseEvents && !controller.robot.isIslandStage,
                   "Returning to a normal corner restores the compact interactive destination")
        let hoverPoint = NSPoint(x: controller.bin.frame.midX, y: controller.bin.frame.midY)
        let frontmostBeforeHover = NSWorkspace.shared.frontmostApplication?.processIdentifier
        controller.pollPointer(at: hoverPoint, now: clock, pressedMouseButtons: 0)
        try expect(controller.bin.isKeyWindow, "Hover grants robot keyboard focus without a click")
        try expect(controller.bin.firstResponder === controller.robot, "Hovered robot is the paste responder")
        try expect(NSWorkspace.shared.frontmostApplication?.processIdentifier == frontmostBeforeHover,
                   "Hover preserves the frontmost application")
        let corridorPoint = NSPoint(x: controller.bin.frame.midX, y: controller.bin.frame.maxY + 2)
        controller.pollPointer(at: corridorPoint, now: clock, pressedMouseButtons: 0)
        try expect(controller.bin.isVisible && !controller.bin.isKeyWindow, "Leaving robot releases keys while retaining retreat grace")
        controller.pollPointer(at: hoverPoint, now: clock, pressedMouseButtons: 1)
        try expect(!controller.bin.isKeyWindow, "Pointer with a pressed mouse button cannot steal drag focus")
        controller.pollPointer(at: hoverPoint, now: clock, pressedMouseButtons: 0)
        try expect(controller.bin.isKeyWindow, "Returning to robot restores hover paste focus")
        controller.pollPointer(at: corridorPoint, now: clock, pressedMouseButtons: 0)
        controller.robot.onDragState?(true)
        controller.pollPointer(at: hoverPoint, now: clock, pressedMouseButtons: 0)
        try expect(!controller.bin.isKeyWindow, "Active file drag does not take keyboard focus")
        controller.robot.onDragState?(false)
        // Dispatch only to our own responder; never read the user's clipboard.
        let pasteHandler = controller.robot.onPaste
        var pasteCalls = 0
        controller.robot.onPaste = { pasteCalls += 1 }
        func shortcut(_ flags: NSEvent.ModifierFlags, time: TimeInterval, repeatKey: Bool = false,
                      characters: String = "v", ignoringModifiers: String = "v") -> NSEvent {
            NSEvent.keyEvent(with: .keyDown, location: .zero, modifierFlags: flags, timestamp: time,
                            windowNumber: controller.bin.windowNumber, context: nil, characters: characters,
                            charactersIgnoringModifiers: ignoringModifiers, isARepeat: repeatKey, keyCode: 9)!
        }
        let controlPaste = shortcut(.control, time: 1)
        controller.robot.keyDown(with: controlPaste)
        try expect(pasteCalls == 1, "Control V routes to paste without a robot click")
        try expect(controller.robot.performKeyEquivalent(with: controlPaste) && pasteCalls == 1,
                   "One event routed through both responder methods captures only once")
        let commandPaste = shortcut(.command, time: 2)
        try expect(controller.robot.performKeyEquivalent(with: commandPaste) && pasteCalls == 2,
                   "Command V remains supported")
        try expect(controller.robot.handlePasteShortcut(shortcut(.control, time: 3, repeatKey: true)) && pasteCalls == 2,
                   "Holding paste does not create repeated captures")
        controller.robot.keyDown(with: shortcut([.control, .capsLock], time: 4, characters: "V", ignoringModifiers: "V"))
        try expect(pasteCalls == 3, "Caps Lock does not disable hover paste")
        controller.robot.keyDown(with: shortcut(.control, time: 5, characters: "\u{16}", ignoringModifiers: "\u{16}"))
        try expect(pasteCalls == 4, "Control character representation also pastes")
        for flags: NSEvent.ModifierFlags in [[], [.shift, .control], [.option, .command], [.command, .control]] {
            try expect(!RobotView.isPasteShortcut(shortcut(flags, time: 6)), "Unrelated modifier combination does not paste")
        }
        controller.robot.onPaste = pasteHandler
        // The Activity action selects Daily. Opening the buddy then resumes it.
        state.openDaily()
        controller.openDaily()
        try expect(controller.board.isVisible && !controller.bin.isVisible, "Double-click handler opens Daily and hides robot")
        try expect(state.route == .daily, "Opening the buddy preserves the explicitly selected Daily route")
        try expect(screen.visibleFrame.contains(controller.board.frame), "Daily panel is constrained to its active visible screen")
        controller.pollPointer(at: away, now: clock.addingTimeInterval(30))
        try expect(controller.board.isVisible && !controller.bin.isVisible, "Daily remains usable after pointer leaves its corner")
        controller.dismiss()
        try expect(ownedWindows.filter(\.isVisible).isEmpty, "Dismissal returns to zero visible DaBin windows")
        controller.pollPointer(at: point, now: clock.addingTimeInterval(31))
        try expect(!controller.bin.isVisible, "Dismissal suppresses reappearance until pointer exits the corner")
        controller.pollPointer(at: away, now: clock.addingTimeInterval(32))
        controller.pollPointer(at: point, now: clock.addingTimeInterval(33))
        try expect(controller.bin.isVisible, "Returning to the corner after exit reveals robot again")
        controller.dismiss()

        let negativeDisplay = NSRect(x: -1920, y: -300, width: 1920, height: 1080)
        let negativeVisible = NSRect(x: -1920, y: -280, width: 1920, height: 1040)
        for corner in ScreenCorner.allCases {
            let point = cornerPoint(corner, frame: negativeDisplay)
            try expect(CornerGeometry.corner(at: point, in: negativeDisplay) == corner, "Negative-screen coordinates detect \(corner.rawValue)")
            let robot = CornerGeometry.robotFrame(corner: corner, visible: negativeVisible)
            try expect(negativeVisible.contains(robot), "Negative-screen \(corner.rawValue) robot stays inside visible area")
            let panel = CornerGeometry.panelFrame(robot: robot, visible: negativeVisible, corner: corner)
            try expect(negativeVisible.contains(panel), "Negative-screen \(corner.rawValue) Daily stays inside visible area")
            let replacementDisplay = NSRect(x: 0, y: 24, width: 1280, height: 696)
            let recovered = CornerGeometry.panelFrame(robot: robot, visible: replacementDisplay, corner: corner)
            try expect(replacementDisplay.contains(recovered), "Removed-display \(corner.rawValue) geometry clamps to remaining screen")
        }
        try expect(CornerGeometry.corner(at: NSPoint(x: -1000, y: 200), in: negativeDisplay) == nil,
                   "Display interior does not activate a corner")
        try expect(CornerGeometry.corner(at: NSPoint(x: -3000, y: -300), in: negativeDisplay) == nil,
                   "A point outside a display does not activate that display")
        let tinyVisible = NSRect(x: -50, y: -50, width: 180, height: 180)
        let clamped = CornerGeometry.panelFrame(robot: NSRect(x: 9000, y: -9000, width: 72, height: 88),
                                                visible: tinyVisible, corner: .topRight, preferredHeight: 500)
        try expect(tinyVisible.contains(clamped), "Oversized/offscreen Daily geometry clamps to a small replacement display")

        // Exercise the same drag lifecycle used by the native header, without
        // synthesizing OS mouse events or changing the user's window preferences.
        controller.openDaily()
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        try verifyLogoProjectsControl(controller: controller)
        func dragSurfaces(in view: NSView) -> [WindowDragHandleView] {
            var result = view as? WindowDragHandleView == nil ? [] : [view as! WindowDragHandleView]
            for child in view.subviews { result.append(contentsOf: dragSurfaces(in: child)) }
            return result
        }
        let handles = controller.board.contentView.map(dragSurfaces(in:)) ?? []
        guard let flexibleHandle = handles.max(by: { $0.bounds.width < $1.bounds.width }) else {
            throw NSError(domain: "DaBinWindowTests", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "The flexible native header drag surface is mounted after logo navigation"])
        }
        try expect(flexibleHandle.bounds.width >= 28 && flexibleHandle.bounds.height >= 28,
                   "The blank first-row header area exposes a separate visible drag grip")
        func dragEvent(_ type: NSEvent.EventType, point: NSPoint) -> NSEvent {
            NSEvent.mouseEvent(with: type, location: point, modifierFlags: [], timestamp: 10,
                              windowNumber: controller.board.windowNumber, context: nil,
                              eventNumber: 1, clickCount: 1, pressure: 1)!
        }
        let chosenTopLeft = NSPoint(x: screen.visibleFrame.minX + 40, y: screen.visibleFrame.maxY - 35)
        let initialFrame = controller.board.frame
        let pointer = NSPoint(x: 50, y: initialFrame.height - 30)
        flexibleHandle.mouseDown(with: dragEvent(.leftMouseDown, point: pointer))
        flexibleHandle.mouseDragged(with: dragEvent(.leftMouseDragged,
            point: NSPoint(x: pointer.x + chosenTopLeft.x - initialFrame.minX,
                          y: pointer.y + chosenTopLeft.y - initialFrame.maxY)))
        let draggedFrame = controller.board.frame
        try expect(draggedFrame.minX == chosenTopLeft.x && draggedFrame.maxY == chosenTopLeft.y,
                   "Header mouse events move the actual native panel to the pointer destination")
        state.showSettings()
        controller.finishBoardDragIfReleased(pressedMouseButtons: 1)
        controller.showBoard()
        try expect(controller.board.frame == draggedFrame, "Content changes cannot snap the board during a native drag")
        flexibleHandle.mouseUp(with: dragEvent(.leftMouseUp, point: pointer))
        controller.finishBoardDragIfReleased(pressedMouseButtons: 0)
        try expect(state.route != .settings && controller.board.frame == draggedFrame,
                   "Release keeps the chosen position and never replays navigation rejected during a drag")
        state.showSettings()
        let settingsResizeDeadline = Date().addingTimeInterval(1.5)
        let expectedSettings = CornerGeometry.movedPanelFrame(topLeft: chosenTopLeft, visible: screen.visibleFrame, preferredHeight: 670)
        while controller.board.frame != expectedSettings && Date() < settingsResizeDeadline {
            RunLoop.main.run(until: Date().addingTimeInterval(0.02))
        }
        try expect(state.route == .settings && controller.board.frame == expectedSettings,
                   "A fresh Settings command after release resizes at the chosen position")
        try expect(placementDefaults.array(forKey: CornerController.boardPlacementKey) as? [Double] == [Double(chosenTopLeft.x), Double(chosenTopLeft.y)], "Manual board position is saved separately from captures")
        state.openNewTask()
        let taskComposerResizeDeadline = Date().addingTimeInterval(1.5)
        while controller.board.frame.height != 490 && Date() < taskComposerResizeDeadline {
            RunLoop.main.run(until: Date().addingTimeInterval(0.02))
        }
        try expect(controller.board.frame.minX == chosenTopLeft.x && controller.board.frame.maxY == chosenTopLeft.y, "Task composer preserves the moved header position")
        try expect(controller.board.frame.height == 490, "Moved task composer reserves 440 points of content plus its outer frame; actual=\(controller.board.frame)")
        state.newTaskDraft.reminderEnabled = true
        // The native resize follows a debounced model notification; wait for
        // that observable endpoint rather than assuming a fixed busy-run delay.
        let reminderResizeDeadline = Date().addingTimeInterval(1.5)
        while controller.board.frame.height != 550 && Date() < reminderResizeDeadline {
            RunLoop.main.run(until: Date().addingTimeInterval(0.02))
        }
        try expect(controller.board.frame.height == 550 && controller.board.frame.maxY == chosenTopLeft.y,
                   "Live reminder expansion resizes below the moved header without jumping to a corner; actual=\(controller.board.frame)")
        state.cancelNewTask()
        controller.dismiss()
        controller.openDaily()
        try expect(controller.board.frame.minX == chosenTopLeft.x && controller.board.frame.maxY == chosenTopLeft.y, "Hide and reopen retain the user position")
        controller.dismiss()

        let reopenedState = AppState(store: store, previews: previews, reminders: reminders)
        let reopened = CornerController(state: reopenedState, input: InputService(store: store), placementDefaults: placementDefaults, animateRobotTransitions: false)
        let reopenedOrigin = reopenedState.route
        reopened.openDaily()
        try expect(reopenedState.route == reopenedOrigin, "A new controller opens the current view without resetting navigation")
        try expect(reopened.board.frame.minX == chosenTopLeft.x && reopened.board.frame.maxY == chosenTopLeft.y, "A new controller restores placement from local preferences")
        if screens.count > 1 {
            let otherScreen = screens[1]
            let otherPoint = NSPoint(x: otherScreen.visibleFrame.minX + 40, y: otherScreen.visibleFrame.maxY - 35)
            reopenedState.onBoardDragStarted?()
            reopened.board.setFrameTopLeftPoint(otherPoint)
            reopened.finishBoardDragIfReleased(pressedMouseButtons: 0)
            reopenedState.showSettings()
            reopened.showBoard()
            try expect(otherScreen.visibleFrame.contains(reopened.board.frame), "Dragging to another display keeps subsequent routes on that display")
            try expect(reopened.board.frame.minX == otherPoint.x && reopened.board.frame.maxY == otherPoint.y, "Second-display placement preserves the header anchor")
        }
        reopened.dismiss()
        reopened.openDaily()
        let resizeScreen = reopened.board.screen ?? screen
        let chosenSize = NSSize(width: min(740, resizeScreen.visibleFrame.width), height: min(650, resizeScreen.visibleFrame.height))
        reopened.resizeBoardFromUser(to: NSRect(x: resizeScreen.visibleFrame.minX + 20,
            y: resizeScreen.visibleFrame.maxY - chosenSize.height, width: chosenSize.width, height: chosenSize.height))
        reopened.finishBoardResize()
        let userFrame = reopened.board.frame
        reopenedState.showSettings()
        reopened.showBoard(immediate: true)
        try expect(reopened.board.frame == userFrame,
                   "A manually stretched board keeps its chosen dimensions across routes")
        try expect(placementDefaults.array(forKey: CornerController.boardSizeKey) as? [Double]
                   == [Double(chosenSize.width), Double(chosenSize.height)],
                   "User-resized dimensions persist separately from the archive")
        RunLoop.main.run(until: Date().addingTimeInterval(0.05))
        let keyWindow = NSApp.keyWindow
        let presentedToUser = reopened.board.isVisible && !NSApp.isHidden
            && reopened.board.occlusionState.contains(.visible)
        let previousCelebrations = reopened.appFrame.taskCelebrationCount
        reopened.celebrateTaskCompletion()
        try expect(reopened.appFrame.taskCelebrationCount == previousCelebrations + (presentedToUser ? 1 : 0),
                   presentedToUser ? "A visible task completion celebrates in the existing frame"
                       : "An occluded task completion does not animate behind another surface or the lock screen")
        try expect(NSApp.keyWindow === keyWindow, "Task completion always preserves keyboard focus")
        let savedSizeBeforeExpansion = placementDefaults.array(forKey: CornerController.boardSizeKey) as? [Double]
        let savedPositionBeforeExpansion = placementDefaults.array(forKey: CornerController.boardPlacementKey) as? [Double]
        reopened.toggleExpandedWindow()
        try expect(reopened.board.frame == resizeScreen.visibleFrame,
                   "Expand fills the safe area on the interaction display without a new Space")
        try expect(placementDefaults.array(forKey: CornerController.boardSizeKey) as? [Double] == savedSizeBeforeExpansion
                   && placementDefaults.array(forKey: CornerController.boardPlacementKey) as? [Double] == savedPositionBeforeExpansion,
                   "Expansion never replaces the saved normal size or position with maximized geometry")
        reopenedState.openLibrary()
        reopenedState.libraryProject = "Window movement fixture"
        reopenedState.filter = .files
        reopened.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        try expect(reopened.board.frame == resizeScreen.visibleFrame,
                   "Changing routes and content filters keeps the expanded safe-area frame")
        reopenedState.performSearchCommand()
        reopenedState.query = "resume this client"
        reopenedState.searchProject = "Window movement fixture"
        reopenedState.filter = .text
        reopened.showBoard(immediate: true)
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        try expect(reopened.board.frame == resizeScreen.visibleFrame
                   && placementDefaults.array(forKey: CornerController.boardSizeKey) as? [Double] == savedSizeBeforeExpansion
                   && placementDefaults.array(forKey: CornerController.boardPlacementKey) as? [Double] == savedPositionBeforeExpansion,
                   "Expanded search updates preserve both the expanded frame and normal persisted geometry")
        reopened.toggleExpandedWindow()
        try expect(reopened.board.frame == userFrame,
                   "The second expand action restores the exact user frame even after route and filter changes")
        try expect(reopenedState.route == .search && reopenedState.query == "resume this client"
                   && reopenedState.searchProject == "Window movement fixture" && reopenedState.filter == .text,
                   "Expanding and restoring keeps the search, project and content filter")

        // Dragging a maximized board should restore normal dimensions under the
        // pointer before moving. These events are sent only to our own header.
        reopened.toggleExpandedWindow()
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        let expandedHandles = reopened.board.contentView.map(dragSurfaces(in:)) ?? []
        guard let expandedHandle = expandedHandles.max(by: { $0.bounds.width < $1.bounds.width }) else {
            throw NSError(domain: "DaBinWindowTests", code: 3,
                          userInfo: [NSLocalizedDescriptionKey: "Expanded board keeps its native header drag surface"])
        }
        func reopenedDragEvent(_ type: NSEvent.EventType, screenPoint: NSPoint) -> NSEvent {
            NSEvent.mouseEvent(with: type, location: reopened.board.convertPoint(fromScreen: screenPoint),
                              modifierFlags: [], timestamp: 20, windowNumber: reopened.board.windowNumber,
                              context: nil, eventNumber: 2, clickCount: 1, pressure: 1)!
        }
        // Inject the event's actual header location; the physical cursor may
        // belong to a different display while this isolated suite is running.
        let dragPointer = NSPoint(x: reopened.board.frame.midX, y: reopened.board.frame.maxY - 42)
        expandedHandle.onDragStarted = { reopened.beginBoardDrag(pointer: dragPointer) }
        expandedHandle.mouseDown(with: reopenedDragEvent(.leftMouseDown, screenPoint: dragPointer))
        let normalDragStart = reopened.board.frame
        try expect(normalDragStart.size == userFrame.size && normalDragStart != resizeScreen.visibleFrame,
                   "Starting a header drag restores the expanded board to its normal movable dimensions")
        let requestedMoved = NSRect(x: resizeScreen.visibleFrame.minX + 65,
                                   y: resizeScreen.visibleFrame.maxY - userFrame.height - 70,
                                   width: userFrame.width, height: userFrame.height)
        let expectedMoved = BoardResizeGeometry.fitted(requestedMoved, visible: resizeScreen.visibleFrame)
        let destinationPointer = NSPoint(x: dragPointer.x + expectedMoved.minX - normalDragStart.minX,
                                        y: dragPointer.y + expectedMoved.minY - normalDragStart.minY)
        expandedHandle.mouseDragged(with: reopenedDragEvent(.leftMouseDragged, screenPoint: destinationPointer))
        try expect(reopened.board.frame == expectedMoved,
                   "An expanded-window header drag moves the real normal-sized panel to a new location")
        expandedHandle.mouseUp(with: reopenedDragEvent(.leftMouseUp, screenPoint: destinationPointer))
        reopened.finishBoardDragIfReleased(pressedMouseButtons: 0)
        RunLoop.main.run(until: Date().addingTimeInterval(0.12))
        try expect(reopened.board.frame == expectedMoved
                   && placementDefaults.array(forKey: CornerController.boardPlacementKey) as? [Double]
                       == [Double(expectedMoved.minX), Double(expectedMoved.maxY)]
                   && placementDefaults.array(forKey: CornerController.boardSizeKey) as? [Double]
                       == [Double(userFrame.width), Double(userFrame.height)],
                   "Releasing an expanded-window drag persists the new normal position without snapping or saving full-screen size")
        reopened.dismiss()
        reopened.openDaily()
        try expect(reopened.board.frame == expectedMoved && reopenedState.route == .search
                   && reopenedState.query == "resume this client" && reopenedState.searchProject == "Window movement fixture"
                   && reopenedState.libraryProject == "Window movement fixture" && reopenedState.filter == .text,
                   "Reopening the buddy restores the moved window and the complete interrupted search/project context")
        reopened.dismiss()
        reopened.robot.onDaily?()
        try expect(reopened.board.frame == expectedMoved && reopenedState.route == .search
                   && reopenedState.query == "resume this client" && reopenedState.filter == .text,
                   "The actual robot open callback also resumes context instead of resetting to a corner or Daily")
        reopened.dismiss()
        let completedCelebrations = reopened.appFrame.taskCelebrationCount
        reopened.celebrateTaskCompletion()
        try expect(!reopened.board.isVisible && reopened.appFrame.taskCelebrationCount == completedCelebrations,
                   "A hidden completion never brings the board back")
        let recoveredPosition = CornerGeometry.movedPanelFrame(topLeft: NSPoint(x: -9000, y: 9000), visible: screen.visibleFrame, preferredHeight: 500)
        try expect(screen.visibleFrame.contains(recoveredPosition), "Removed-display saved coordinates recover onto an available screen")
        let smallMoved = CornerGeometry.movedPanelFrame(topLeft: NSPoint(x: 9000, y: -9000), visible: tinyVisible, preferredHeight: 500)
        try expect(tinyVisible.contains(smallMoved), "Saved position fits a small replacement display")
        placementDefaults.set(["invalid", "position"], forKey: CornerController.boardPlacementKey)
        let invalidState = AppState(store: store, previews: previews, reminders: reminders)
        let invalidPlacement = CornerController(state: invalidState, input: InputService(store: store), placementDefaults: placementDefaults, animateRobotTransitions: false)
        invalidPlacement.openDaily()
        try expect(screens.contains { $0.visibleFrame.contains(invalidPlacement.board.frame) }, "Malformed saved placement safely falls back to a visible corner")
        invalidPlacement.dismiss()
        try verifyExpandedAutomaticDragging(screen: screen, root: root)
        try verifyCompositionEscape(root: root)
        try verifyGlobalShortcutActions(screen: screen, root: root)
        try expect(store.captures.isEmpty && !input.isBusy, "Window testing creates no captures or paste operations")
        try expect(notificationClient.permissionRequests == 0 && notificationClient.additions == 0,
                   "Window testing requests no real or fake notification permission/schedules")
        try expect(ownedWindows.filter(\.isVisible).isEmpty, "Window checks finish with every owned panel hidden")
        if !failures.isEmpty {
            fputs("FAIL: \(failures.count) of \(checks) window checks failed across \(screens.count) real screen(s). All independent checks were attempted.\n", stderr)
            exit(1)
        }
        print("PASS: \(checks) window checks across \(screens.count) real screen(s); no cursor synthesis, clipboard access, network or notification permission.")
        // Launch Services does not forward the child's exit status. Only the
        // existing complete PASS path can write this owned fixture receipt.
        if let path = ProcessInfo.processInfo.environment["DABIN_QA_RESULT_PATH"] {
            let result: [String: Any] = ["passed": true, "checks": checks, "screens": screens.count]
            try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
                .write(to: URL(fileURLWithPath: path), options: .atomic)
        }
    }
}
